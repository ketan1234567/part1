<?php

class Regmodel extends CI_Model {



	public function reg_data($data)
	{
		return $this->db->insert('tbl_reg',$data);
	}

	public function login_valid($username,$password)
	{
		$query 	= $this->db->select('*')
		->where(['username' => $username, 'password' => $password])
		->where('is_active','1')
		->get('tbl_reg');
		return $query->row();
	}

	public function reg_loan($data)
	{
		$this->db->insert('tbl_loan',$data);
		
		return $last_id = $this->db->insert_id();
	}

	public function passbook_data($customer_id)
	{
		$query 	= $this->db->select('*')
		->where('id',$customer_id)
							//->where(['is_approve'=>0])
		->get('tbl_loan');
		return $query->result();
	}
	public function loan_data($loan_id)
	{
		$query 	= $this->db->select('*')
		->where('loan_id',$loan_id)
		->get('tbl_loan');
		return $query->row();
	}

	public function loan_data_update($loan_id,$loan_amt,$lenderamt)
	{
		$updatequery = $this->db->where('loan_id', $loan_id)
		->set('loanamt', $loan_amt)
		->set('lenderamt', $lenderamt)
		->update('tbl_loan');

		return $updatequery;
	} 
	public function app_cust_list()
	{

		$query  = $this->db->select('*')
		->from('tbl_loan')
		->where('tbl_loan.is_approve',1)
		->where('tbl_loan.is_active',0)
		->where('tbl_reg.is_coll_assign',$this->session->userdata('id'))
		->join('tbl_reg','tbl_reg.id=tbl_loan.id')
		->get();   
		return $query->result(); 
	}
	public function app_cust_list1()
	{
		if ($this->session->userdata('type')== 2) {
			$query  = $this->db->select('*')
			->from('tbl_loan')
			->where('tbl_loan.is_approve',1)
			->where('tbl_loan.is_active',1)
			->where('tbl_reg.is_coll_assign',$this->session->userdata('id'))
			->join('tbl_reg','tbl_reg.id=tbl_loan.id')
			->get();   
		}else{
			$query  = $this->db->select('*')
			->from('tbl_loan')
			->where('tbl_loan.is_approve',1)
			->where('tbl_loan.is_active',1)
							  //->where('tbl_reg.is_coll_assign',$this->session->userdata('id'))
			->join('tbl_reg','tbl_reg.id=tbl_loan.id')
			->get();   
		}

		
		return $query->result(); 
	}

	public function loan_amt_pay($amtdata)
	{
		return $this->db->insert('tbl_pay',$amtdata);
	}

	public function show_loan_amt_passbkentry($loan_id)
	{
		$query  = $this->db->select('*')
		->from('tbl_pay')
							  //->join('tbl_loan','tbl_loan.loan_id=tbl_pay.loan_id')
		->where('loan_id',$loan_id)
		->get();   
		return $query->result(); 
	}

	public  function show_loan_data($loan_id)
	{
		$query  = $this->db->select('*')
		->from('tbl_loan')
							  //->join('tbl_loan','tbl_loan.loan_id=tbl_pay.loan_id')
		->where('loan_id',$loan_id)
		->get();   
		return $query->row(); 
	}
	public function show_collector_data()
	{
		$query  = $this->db->select('*')
		->from('tbl_reg')
							  //->join('tbl_loan','tbl_loan.loan_id=tbl_pay.loan_id')
		->where('type',2)
		->get();   
		return $query->result(); 
	}
	public  function show_subtotal_data($loan_id)
	{
		$query  = $this->db->select_sum('pay_loan_amt')
		->where('loan_id',$loan_id)
		->get('tbl_pay');  
		return $query->row(); 
	}
	public  function lender_amt($loan_id)
	{
		$query  = $this->db->select('*')
		->where('loan_id',$loan_id)
		->get('tbl_loan');  
		return $query->row(); 
	}
	public function show_daily_collection()
	{
		$start_date = date("Y-m-d 00:00:00");
		$end_date = date("Y-m-d 23:59:59");
		//print_r($end_date); exit();
		$query  = $this->db->select('*')
		->from('tbl_pay')
		->where('timestamp >=', $start_date)
		->where('timestamp <=', $end_date)
		->where('collector_id',$this->session->userdata('id'))
		->get();   
		return $query->result(); 

		
	}
	public function collector_daily_collection()
	{
		$start_date = date("Y-m-d 00:00:00");
		$end_date = date("Y-m-d 23:59:59");
		$query  = $this->db->select_sum('pay_loan_amt')
		->from('tbl_pay')
		->where('timestamp >=', $start_date)
		->where('timestamp <=', $end_date)
		->where('collector_id',$this->session->userdata('id'))
		->get();
		return $query->row();

		
	}

	public function collector_all_collection()
	{
		$query  = $this->db->select_sum('pay_loan_amt')
		->from('tbl_pay')
		->where('collector_id',$this->session->userdata('id'))
		->get();
		return $query->row();
	}
	
	public function show_all_collection($collector_id)
	{
		
		$query  = $this->db->select('tbl_pay.*,tbl_loan.id,tbl_reg.fname,tbl_reg.lname')
		->from('tbl_pay')
		->join('tbl_loan','tbl_loan.loan_id=tbl_pay.loan_id')
		->join('tbl_reg','tbl_loan.id=tbl_reg.id')
		->order_by('tbl_pay.pay_id', 'desc')
		->where('tbl_pay.collector_id',$collector_id)
		->get();   
		return $query->result(); 

		
	}

	public function show_all_agents()
	{
		$query  = $this->db->select('*')
		->from('tbl_reg')
		->order_by('id','desc')
		->where('type',3)
		->where('is_delete',0)
		->get();   
		return $query->result(); 

	}
	public function show_all_coll()
	{
		$query  = $this->db->select('*')
		->from('tbl_reg')
		->order_by('id','desc')
		->where('type',2)
		->get();   
		return $query->result(); 
	}
	

	public function change_status($id,$val)
	{
		$updatequery = $this->db
		->set('is_active', $val)
		->where('id', $id)
		->update('tbl_reg');

		return $updatequery;
	}
	public function show_all_loan()
	{
		$query  = $this->db->select('tbl_loan.*,tbl_loan_type_amt.capital_amt,tbl_loan_type_amt.reinvest_amt')
		->from('tbl_loan')
		->join('tbl_loan_type_amt','tbl_loan_type_amt.loan_id = tbl_loan.loan_id ','left')//New 25-09-2019
		->where('tbl_loan.is_active',0)
		->order_by('tbl_loan.loan_id','desc')
		->get();   
		return $query->result(); 
	}
	public function change_approve($id,$val)
	{
		$updatequery = $this->db
		->set('is_approve', $val)
		->where('loan_id', $id)
		->update('tbl_loan');

		return $updatequery;
	}
	public function show_all_collector()
	{
		$query  = $this->db->select('*')
		->from('tbl_reg')
		->where('type',2)
		->get();   
		return $query->result(); 
	}

	public function agent_data($id)
	{
		$query  = $this->db->select('*')
		->from('tbl_reg')
		->where('id',$id)
		->get();   
		return $query->row(); 
	}
	public function store_report($data)
	{

		return $this->db->insert('tbl_universal_product_upload_sheet',$data);

	}
	public function ind_loan_data($id)
	{
		$query  = $this->db->select('*')
		->from('tbl_loan')
		->where('id',$id)
		->where('is_approve',1)
		->get();   
		return $query->result(); 
	}
	public function cust_upload_doc($id)
	{
		$query  = $this->db->select('*')
		->from('tbl_image')
		->where('id',$id)
								//->where('is_approve',1)
		->get();   
		return $query->result();
	}
	public function total_given_loan()
	{
		$query  = $this->db->select_sum('loanamt')
		->from('tbl_loan')
		->get();
		return $query->row();
	}
	public function total_receive_loan()
	{
		$query  = $this->db->select_sum('pay_loan_amt')
						->from('tbl_pay')
						->get();
		return $query->row();
	}

	public function total_active_loan()
	{

		$query = $this->db->where(['is_active'=>0])
		->where(['is_approve'=>1])
		->from("tbl_loan");
		return $query->count_all_results();
	}

	public function total_closed_loan()
	{
		$query = $this->db->where(['is_active'=>1])
		->where(['is_approve'=>1])
		->from("tbl_loan");
		return $query->count_all_results();
	}

	public function cust_active_loan()
	{
		$query = $this->db->where(['id'=> $this->session->userdata('id')])
		->where(['is_active'=>0])
		->where(['is_approve'=>1])
		->from("tbl_loan");
		return $query->count_all_results();
	}
	public function cust_inactive_loan()
	{
		$query = $this->db->where(['id'=> $this->session->userdata('id')])
		->where(['is_active'=>1])
		->where(['is_approve'=>1])
		->from("tbl_loan");
		return $query->count_all_results();
	}
	public function cust_pending_loan()
	{
		$query = $this->db->where(['id'=> $this->session->userdata('id')])
							//->where(['is_active'=>0])
		->where(['is_approve'=>0])
		->from("tbl_loan");
		return $query->count_all_results();
	}



	public function cust_details($id)
	{
		$query  = $this->db->select('*')
		->from('tbl_reg')
		->where('id',$id)
		->get();   
		return $query->row(); 
	}

	public function update_loan_status($loan_id)
	{
		$this->db->where('loan_id', $loan_id)
		->set('is_active', 1)
		->update('tbl_loan');
	}

	public function lender_all_collection()
	{
		$query  = $this->db->select_sum('lenderamt')
		->from('tbl_loan')
		->get();
		return $query->row();
	}

	public function get_last_reg_id()
	{
		$get_reg_id_query = $this->db->select(['id'])
		->from('tbl_reg')
		->order_by("id","DESC")
		->limit(1)
		->get();

		return $get_reg_id_query->row('id');
	}

	public function store_image($data)
	{
		return $this->db->insert('tbl_image',$data);
	}
	public function reset_pass($id,$pass)
	{
		$updatequery = $this->db->where('id', $id)
		->set('password', $pass)
		->update('tbl_reg');

		return $updatequery;
	}
	public function assign_coll($agents_id,$coll_id,$is_active)
	{
		$updatequery = $this->db->where('id', $agents_id)
		->set('is_coll_assign', $coll_id)
		->set('is_active',$is_active)
		->update('tbl_reg');

		return $updatequery;
	}
	public function update_agents($agents_id,$update_data)
	{
		$updatequery = $this->db->where('id', $agents_id)
		->update('tbl_reg',$update_data);

		return $updatequery;
	}
	public function delete_image($imgid)
	{
		$deletequery =	$this->db->where('imgid', $imgid)
		->delete('tbl_image');
		return $deletequery;
	}
	public function assign_loan($loan_id,$is_active,$loan_Type)
	{
		$updatequery = $this->db->where('loan_id', $loan_id)
		->set('is_approve', $is_active)
		->set('loan_Type',$loan_Type)
		->update('tbl_loan');

		return $updatequery;
	}

	public function insert_exp($data)
	{
		return $this->db->insert('tbl_exp',$data);
	}
	public function expenceses_data()
	{
		$query 	= $this->db->select('*')
		->order_by('tbl_exp_id', 'desc')
		->get('tbl_exp');
		return $query->result();
	}
	public function delete_exp($id)
	{
		$deletequery =	$this->db->where('tbl_exp_id', $id)
		->delete('tbl_exp');
		return $deletequery;
	}
	public function coll_applyloan_data($coll_id)
	{
		$query 	= $this->db->select('tbl_reg.fname,tbl_reg.lname,tbl_loan.loan_id,tbl_loan.loanamt')
		->from('tbl_reg')
		->join('tbl_loan','tbl_loan.id = tbl_reg.id')
		->where('tbl_reg.is_coll_assign', $coll_id)
		->where('.tbl_reg.is_active', 1)
		->where('.tbl_loan.is_approve', 1)
		->where('.tbl_loan.is_active', 0)
		->get();
		return $query->result();
	}
	public function loan_amt_data($loan_id)
	{
		$query 	= $this->db->select('loanamt')
		->where('loan_id', $loan_id)
		->get('tbl_loan');
		return $query->row();
	}
	
	
	public function col_assn_loan()
	{
		$query  = $this->db->select('*')
		->from('tbl_loan')
		->where('is_approve', 1)
		->where('is_active', 0)
		->get();   
		return $query->result(); 
	}
	
	
	public function loan_agent_data($loan_id)
	{
		$query 	= $this->db->select('id')
		->where('loan_id', $loan_id)
		->get('tbl_loan');
		return $query->row();
	}
	public function mail_name($id)
	{
		$query 	= $this->db->select('fname,lname')
		->where('id', $id)
		->get('tbl_reg');
		return $query->row();
	}
	public function reg_loan_masterdata($result,$data)
	{
		$insert_data = array(
			'date' => $data['loandate'],
			'custone_id ' => $data['id'],
			'customer_name' => $data['fname'],
			'loan_id ' => $result,
			'loan_amount ' => $data['loanamt'],
			'interest'	=> $data['lenderamt']-$data['loanamt']
		);
		return $this->db->insert('tbl_masterloanreport',$insert_data);

	}

	public function reg_loan_upcoming_report($result,$data)
	{
		$daily_amt = $data['loanamt'] * 0.01;
		$insert_data = array(
			'date' => $data['loandate'],
			'custone_id ' => $data['id'],
			'customer_name' => $data['fname'],
			'loan_id ' => $result,
			'loan_amount ' => $data['loanamt'],
			'interest'	=> $data['lenderamt']-$data['loanamt'],
			'daily_target ' => $daily_amt
		);
		return $this->db->insert('tbl_upcoming_report',$insert_data);

	}
	public function update_loan_Type_masterdatabase($loan_id,$loan_Type)
	{
		$updatequery = $this->db->where('loan_id', $loan_id)
		->set('loan_Type', $loan_Type)
		->update('tbl_masterloanreport');
		return $updatequery;

	}
	public function update_master_data($loan_id,$result1,$collector_id)
	{
		$updatequery = $this->db->where('loan_id', $loan_id)
		->set('assign_collector', $collector_id)
		->set('collected_amount', $result1->pay_loan_amt)
		->update('tbl_masterloanreport');

		$remaining_amount = $this->db->select('(loan_amount + interest - collected_amount) AS remaining_amount')
		->where('loan_id',$loan_id)
		->get('tbl_masterloanreport');
		$subquery = $remaining_amount->row();

		$update_remaining = $this->db->where('loan_id', $loan_id)
		->set('remaining_amount', $subquery->remaining_amount)
		->update('tbl_masterloanreport');
		return $update_remaining;
	}
	public function masterdata_report()
	{


		$query  = $this->db->select('tbl_masterloanreport.*,tbl_reg.*,tbl_loan_type_amt.*')
		->from('tbl_masterloanreport')
		->join('tbl_reg','tbl_masterloanreport.assign_collector=tbl_reg.id')
		->join('tbl_loan_type_amt','tbl_loan_type_amt.loan_id=tbl_masterloanreport.loan_id','left')
		->where('tbl_masterloanreport.remaining_amount !=', '' )
		->get();   
		return $query->result(); 

	}
	public function reinvest_loan()
	{
		$query  = $this->db->select_sum('reinvest_amt')
		->from('tbl_loan_type_amt')

		->get();
		return $query->row();

	}
	public function capital_loan()
	{
		$query  = $this->db->select_sum('capital_amt')
		->from('tbl_loan_type_amt')

		->get();
		return $query->row();

	}
	
	public function expenses()
	{
		$query  = $this->db->select_sum('amount')
		->from('tbl_exp')
		->get();
		return $query->row();
	}
	public function show_daily_collection1($coll_id)
	{
		$start_date = date("Y-m-d 00:00:00");
		$end_date = date("Y-m-d 23:59:59");

		$query  = $this->db->select('tbl_pay.*,tbl_pay.loandate,tbl_reg.fname,tbl_reg.lname')
		->from('tbl_pay')
		->join('tbl_loan','tbl_loan.loan_id=tbl_pay.loan_id')
		->join('tbl_reg','tbl_reg.id=tbl_loan.id')
		->where('tbl_pay.timestamp >=', $start_date)
		->where('tbl_pay.timestamp <=', $end_date)
		->where('tbl_pay.collector_id',$coll_id)
		->get();   
		return $query->result(); 


	}
	public function pay_data($pay_id)
	{
		$query 	= $this->db->select('*')
		->where('pay_id', $pay_id)
		->get('tbl_pay');
		return $query->row();
	}
	public function delete_pay($pay_id)
	{
		$deletequery =	$this->db->where('pay_id', $pay_id)
		->delete('tbl_pay');
		return $deletequery;
	}
	public function update_masterdata_after_delete($loan_id,$collected_amount)
	{
		$updatequery = $this->db->where('loan_id', $loan_id)
		->set('collected_amount', $collected_amount)
		->update('tbl_masterloanreport');


		$remaining_amount = $this->db->select('(loan_amount + interest - collected_amount) AS remaining_amount')
		->where('loan_id',$loan_id)
		->get('tbl_masterloanreport');
		$subquery = $remaining_amount->row();

		$update_remaining = $this->db->where('loan_id', $loan_id)
		->set('remaining_amount', $subquery->remaining_amount)
		->update('tbl_masterloanreport');
		return $update_remaining;
	}
	public function show_loanid($pay_id)
	{
		$query 	= $this->db->select('*')
		->where('pay_id', $pay_id)
		->get('tbl_pay');
		return $query->row();
	}
	public function edit_pay_amount($loan_id,$pay_id,$edit_amt,$loandate)
	{
		$updatequery_pay = $this->db->where('pay_id', $pay_id)
		->set('pay_loan_amt', $edit_amt)
		->set('loandate', $loandate)
		->update('tbl_pay');
	}
	public function assign_loan_type($loan_id,$loan_Type,$capital_amt,$reinvest_amt)
	{
// 		$data  = array('loan_id' => $loan_id,
// 			'loan_Type' => $loan_Type,
// 			'capital_amt' => $capital_amt,
// 			'reinvest_amt' => $reinvest_amt );

// 		return $this->db->insert('tbl_loan_type_amt',$data);
        $data  = array('loan_id' => $loan_id,
			'loan_Type' => $loan_Type,
			'capital_amt' => $capital_amt,
			'reinvest_amt' => $reinvest_amt );
		$check = $this->db->select('*')
							->where('loan_id',$loan_id)
							->get('tbl_loan_type_amt');
		$check1 = $check->row();
		//echo "<pre>"; print_r($check1);
		if ($check1) {
			$update = $this->db->where('loan_id', $loan_id)
					->set('loan_Type', $loan_Type)
					->set('capital_amt', $capital_amt)
					->set('reinvest_amt', $reinvest_amt)
					->update('tbl_loan_type_amt');
					return $update;
		}else{
			return $this->db->insert('tbl_loan_type_amt',$data);
		}
	}
	public function update_loanbreakup($loan_id,$loan_Type,$capital_amt,$reinvest_amt)
	{
		$update = $this->db->where('loan_id', $loan_id)
		->set('loan_Type', $loan_Type)
		->update('tbl_loan');

		$update = $this->db->where('loan_id', $loan_id)
		->set('loan_Type', $loan_Type)
		->set('capital_amt', $capital_amt)
		->set('reinvest_amt', $reinvest_amt)
		->update('tbl_loan_type_amt');

		$update = $this->db->where('loan_id', $loan_id)
		->set('loan_Type', $loan_Type)
		->update('tbl_masterloanreport');

		return $update;
	}
	public function upcoming_report()
	{
// 		$query 	= $this->db->select('*')
// 		->order_by("aprx_date asc")
// 		->get('tbl_upcoming_report');
// 		return $query->result();
    $query = 	$this->db->select('tbl_upcoming_report.*')
					->from('tbl_upcoming_report')
					->join('tbl_loan','tbl_upcoming_report.loan_id=tbl_loan.loan_id')
					->where('tbl_loan.is_active','0')
					->order_by("tbl_upcoming_report.aprx_date asc")
					->get();

		return $query->result();
	}

	public function projected_date()
	{
		$query 	= $this->db->select('project_2')
		->order_by("project_2 asc")
		->limit(1)
		->get('tbl_upcoming_report');
		return $query->row();
	}

	public function current_month_avg()
	{
		$query 	= $this->db->select('month_avg')
		->order_by("project_2 asc")
		->limit(1)
		->get('tbl_upcoming_report');
		return $query->row();
	}

	public function datewisereport()
	{
		$query = 	$this->db->select('loandate,SUM(pay_loan_amt) AS amount')
		->group_by("loandate")
		->order_by("loandate desc")
		->get('tbl_pay');

		return $query->result();
	}
	public function custperfreport()
	{
// 		$query = 	$this->db->select('*')

// 		->get('tbl_upcoming_report');

// 		return $query->result();
    $query = 	$this->db->select('tbl_upcoming_report.*')
					->from('tbl_upcoming_report')
					->join('tbl_loan','tbl_upcoming_report.loan_id=tbl_loan.loan_id')
					->where('tbl_loan.is_active','0')
					->get();

		return $query->result();
	}
	public function enddateprojreport()
	{
// 		$query = 	$this->db->select('*')
// 		->order_by("aprx_date asc")
// 		->get('tbl_upcoming_report');

// 		return $query->result();
    $query = 	$this->db->select('tbl_upcoming_report.*')
					->from('tbl_upcoming_report')
					->join('tbl_loan','tbl_upcoming_report.loan_id=tbl_loan.loan_id')
					->where('tbl_loan.is_active','0')
					->order_by("tbl_upcoming_report.aprx_date asc")
					->get();

		return $query->result();
	}

	public function grp_by_date()
	{
		$query = $this->db->select('loandate,SUM(pay_loan_amt) AS amount')
		->group_by("loandate")
		->order_by("loandate desc")
		->limit(7)
		->get('tbl_pay');
		return $query->result_array();
	}
	public function custperfreport1($loan_id)
	{
		$query = 	$this->db->select('*')
		->where('loan_id',$loan_id)
		->get('tbl_upcoming_report');

		return $query->row();
	}
	public function verifersearch_data($user_id)
	{
		$query 	= $this->db->select('tbl_loan.loan_id,tbl_reg.fname,tbl_reg.lname')
		->from('tbl_loan')
		->join('tbl_reg','tbl_reg.id=tbl_loan.id')
		->where('tbl_loan.id',$user_id)

		->get();   
		return $query->result();
	}
	public function insertaddcapital($data)
	{
		return $this->db->insert('tbl_addcapital',$data);
	}
	public function addcapital_data()
	{
		$query = 	$this->db->select('*')
							->get('tbl_addcapital');

			return $query->result();
	}
	public function delete_addcapital($id)
	{
		$query = 	$this->db->select('amount')
								->where('id',$id)
							->get('tbl_addcapital');

		$data = $query->row();

		$query1 = 	$this->db->select('total_amount')
							->get('tbl_total_addcapital');

		$data1 = $query1->row();
		// echo $data->amount;
		$updatequery = $this->db->where('id', 1)
								->set('total_amount', $data1->total_amount - $data->amount)
								->update('tbl_total_addcapital');
		
		$deletequery =	$this->db->where('id', $id)
							->delete('tbl_addcapital');
		return $deletequery;
	}
	public function unusedaddcapital_amt()
	{

		$query  = $this->db->select_sum('total_amount')
							->from('tbl_total_addcapital')

							->get();
		return $query->row();
	}
	public function totaladdcapital_amt()
	{
		$query = 	$this->db->select('*')
							->get('tbl_total_addcapital');

			return $query->row();
	}
	public function inserttotaladdcapital($amount)
	{
		$query = 	$this->db->select('total_amount')
							->get('tbl_total_addcapital');

		$data = $query->row();
			// echo $data->total_amount;
			// exit();
		$updatequery = $this->db->where('id', 1)
								->set('total_amount', $data->total_amount+$amount)
								->update('tbl_total_addcapital');

		return $updatequery;
	}

	public function delete_unused_exp($amount)
	{
		$query = 	$this->db->select('total_amount')
							->get('tbl_total_addcapital');

		$data = $query->row();
		$updatequery = $this->db->where('id', 1)
								->set('total_amount', $data->total_amount - $amount)
								->update('tbl_total_addcapital');

		return $updatequery;
	}
	public function delete_cashinbank_exp($amount)
	{
		$query = 	$this->db->select('cashinbank')
							->get('tbl_cashinbank');

		$data = $query->row();
		$updatequery = $this->db->where('id', 1)
								->set('cashinbank', $data->cashinbank - $amount)
								->update('tbl_cashinbank');

		return $updatequery;
	}
	public function cashinbank_amt()
	{
		$query  = $this->db->select_sum('cashinbank')
							->from('tbl_cashinbank')
							->get();
		return $query->row();
	}
	public function check_mob_no($mob)
	{
		$query 	= $this->db->select('*')
							->where('contact' , $mob)
							->get('tbl_reg');
		return $query->row();
	}
	
//19-12-2019
	public function insertexp_type($data)
	{
		return $this->db->insert('tbl_exp_type',$data);
	}
	public function expenceses_type()
	{
		$query 	= $this->db->select('*')
							->get('tbl_exp_type');
		return $query->result();
	}
	public function edit_exp_type($exp_type_id)
	{
		$query 	= $this->db->select('*')
							->where('id' , $exp_type_id)
							->get('tbl_exp_type');
		return $query->row();	
	}
	public function update_exp_type($id,$update_data)
	{
		$updatequery = $this->db->where('id', $id)
					->update('tbl_exp_type',$update_data);

		return $updatequery;
	}
	public function delete_exp_type($id)
	{
		$deletequery =	$this->db->where('id', $id)
						->delete('tbl_exp_type');
		return $deletequery;
	}
	public function get_contact()
	{
		$query 	= $this->db->select('fname,lname,contact')
							->where('type' , '3')
							->where('is_active','1')
							->get('tbl_reg');
		return $query->result();	
	}
	//19-12-2019
	public function delete_agent($agent_id)
	{
		$updatequery = $this->db->where('id', $agent_id)
								->set('is_delete', 1)
								->update('tbl_reg');

		return $updatequery;
	}
	//24-12-2019
	public function total_unusedaddcapital()
	{

		$query  = $this->db->select_sum('amount')
							->from('tbl_addcapital')
							->get();
		return $query->row();
	}
	//31-12-2019
	public function exp_capital_amt()
	{
		$query  = $this->db->select_sum('amount')
						->from('tbl_exp')
						//->where('tbl_exp_id !=','6')
						->where('exp_type !=','To Investor')
						->get();
		return $query->row();

	}
	//03-001-2020
	public function grp_by_month()
	{
		$lim = date('n', strtotime('month'));
		//echo $lim; exit();
		$query = $this->db->select('pay_id, year(loandate) as year , month(loandate) as month, sum(pay_loan_amt) as tot_amt')
		 ->group_by("month(loandate)")
		 ->group_by("year(loandate)")
		->order_by("year(loandate) ASC")
		->order_by("month(loandate) ASC")
		 //->limit(12,$lim) Add After 12 month Complete
		 ->limit(12)
		 ->get('tbl_pay');
		 return $query->result_array();
	}
	
	public function loanChart($loanid)
	{
		$query  = $this->db->select('tbl_pay.loanamt, sum(pay_loan_amt) as coll_amt,tbl_loan.lenderamt ')
							->from('tbl_pay')
							->join('tbl_loan','tbl_loan.loan_id=tbl_pay.loan_id')
							->where('tbl_pay.loan_id',$loanid)
							->get();
		return $query->row();
	}
	public function cron_hit()
	{
		// $sql = "SELECT tmlr.* FROM tbl_masterloanreport tmlr 
		// JOIN tbl_loan tl ON tl.loan_id = tmlr.loan_id
		// WHERE tl.is_active = 1";
		$sql = "SELECT * FROM tbl_masterloanreport";
		$result = $this->db->query($sql);
		$result = $result->result();
		foreach ($result as $row) 
		{ 
			$sku=$row->tbl_masterloanreport_id;
			$loan_id=$row->loan_id;
			$loan_amount=$row->loan_amount;
			$collected_amount=$row->collected_amount;
			$remaining_amount=$row->remaining_amount;
			$updatequery ="UPDATE tbl_upcoming_report SET collected_amount='$collected_amount',remaining_amount = '$remaining_amount'  WHERE loan_id='$loan_id'";
			$result1 = $this->db->query($updatequery);
			$updatequery1 ="UPDATE tbl_upcoming_report SET days_left = remaining_amount / daily_target WHERE loan_id='$loan_id'";
			$result11 =  $this->db->query($updatequery1);
			$select = "select days_left from tbl_upcoming_report WHERE loan_id='$loan_id'";
			$select_result =  $this->db->query($select);
			$row1=$select_result->row();
			$days_left=$row1->days_left;
			$days_left1 = round($days_left);
			$date1 = strtotime("+".$days_left1." day");
			$aprx_date = date('Y-m-d', $date1);
			$updatequery11 ="UPDATE tbl_upcoming_report SET aprx_date = '$aprx_date' WHERE loan_id='$loan_id'";
			$result111 =  $this->db->query($updatequery11);
		} 

		$sql2 =  "SELECT tbl_upcoming_report_id FROM tbl_upcoming_report ORDER BY aprx_date limit 1";
		$result2 = $this->db->query($sql2);
		$row2=$result2->row();
		$lowest_id=$row2->tbl_upcoming_report_id;
		$sql3 = "SELECT * FROM tbl_upcoming_report ORDER BY aprx_date";
		$result3 = $this->db->query($sql3); 
		foreach( $result3->result() as $row3 ) 
		{
			/*Total Receive Loan*/
			$total_receive_loan = "SELECT SUM(pay_loan_amt) AS payloanamt FROM tbl_pay";
			$resultfortotalreceiveloan = $this->db->query($total_receive_loan);
			$row=$resultfortotalreceiveloan->row();
			$total_receive_loan1=$row->payloanamt;
			//echo "test2 :";  echo $total_receive_loan1; echo "<br>"; //exit();
			/*Re-invest amt*/
			$re_invest_amt = "SELECT SUM(reinvest_amt) AS reinvestamt FROM tbl_loan_type_amt";
			$resultforreinvestamt =  $this->db->query($re_invest_amt);
			$row=$resultforreinvestamt->row();
			$re_invest_amt1=$row->reinvestamt;
			//echo "test3 :";  echo $re_invest_amt1; echo "<br>";// exit();
			/*Expenses*/
			//$expenses_amt = "SELECT SUM(amount) AS expamt FROM tbl_exp";
			$expenses_amt = "SELECT SUM(amount) AS expamt FROM tbl_exp where cap_type = '2'";
			$resultforexpamt = $this->db->query($expenses_amt);
			$row=$resultforexpamt->row();
			$expenses_amt1=$row->expamt;
			//echo "test4 :";  echo $expenses_amt1; echo "<br>";// exit();
			/*Cash in Bank*/
			$cash_in_bank = $total_receive_loan1 - $re_invest_amt1 - $expenses_amt1 ;
			$id=$row3->tbl_upcoming_report_id; 
			//echo "test5 :";  echo $cash_in_bank; echo "<br>"; echo $id; echo "<br>";// exit();

			/*To cash In bank*/
			if ($id == $lowest_id) {
				$updatequeryforcashinbank ="UPDATE tbl_upcoming_report SET cash_in_bank = '$cash_in_bank' WHERE tbl_upcoming_report_id='$id'";
				$resultforcashinbank =$this->db->query($updatequeryforcashinbank);
			}else{
				$updatequeryforcashinbank ="UPDATE tbl_upcoming_report SET cash_in_bank = 0 WHERE tbl_upcoming_report_id='$id'";
				$resultforcashinbank =$this->db->query($updatequeryforcashinbank);
			}	
			//echo "test6 :";   echo "<br>";  //exit();
			/*To Make up*/
			if ($id == $lowest_id) {
				$to_makeup = $row3->loan_amount - $cash_in_bank;
				$updatequeryfortomakeup ="UPDATE tbl_upcoming_report SET to_makeup = '$to_makeup' WHERE tbl_upcoming_report_id='$id'";
				$resultfortomakeup = $this->db->query($updatequeryfortomakeup);
			}else{
				$to_makeup = $row3->loan_amount - 0 ;
				$updatequeryfortomakeup ="UPDATE tbl_upcoming_report SET to_makeup = '$to_makeup' WHERE tbl_upcoming_report_id='$id'";
				$resultfortomakeup = $this->db->query($updatequeryfortomakeup);
			}
			//echo "test7 :";   echo "<br>"; // exit();
			/*For Currnt month sum data*/

			$currntmonthsumdata = "SELECT SUM(pay_loan_amt) AS sumdata FROM tbl_pay WHERE MONTH(loandate) = MONTH(CURRENT_DATE()) AND YEAR(loandate) = YEAR(CURRENT_DATE())";
			$resultforsumdata = $this->db->query($currntmonthsumdata);
			$row=$resultforsumdata->row();
			$currntmonthsumdata1=$row->sumdata;
			//echo "test8 :"; echo $currntmonthsumdata1;   echo "<br>"; // exit();
			/*For Currnt month date data*/
			$first_day_this_month = date('Y-m-01'); // hard-coded '01' for first day
			$last_day_this_month  = date('Y-m-t');
			$currentmonthdatedata = "SELECT CAST(loandate AS DATE) AS datecnt FROM tbl_pay WHERE loandate BETWEEN '$first_day_this_month' AND '$last_day_this_month' GROUP BY CAST(loandate AS DATE)";
			//echo "test9 :"; echo $currentmonthdatedata;   echo "<br>";  //exit();
			$resultfordatedata =$this->db->query($currentmonthdatedata);
			$cnt = 0;
			foreach( $resultfordatedata->result() as $row ) {
			$cnt++;
			}
			//echo "test10 :"; echo $cnt;   echo "<br>"; // exit();
			/*For Currnt month AVG data*/

			$currentmonthavgdata = $currntmonthsumdata1 / $cnt ;
			$roundof_value = round($currentmonthavgdata);
			$updatequeryforavgmonth ="UPDATE tbl_upcoming_report SET month_avg = '$roundof_value'";
			$resultforavgmonth = $this->db->query($updatequeryforavgmonth);

			/* Apox days to save*/
			$apox_days_to_save = $to_makeup / $roundof_value ;
			$roundof_apox_days_to_save = round($apox_days_to_save);
			$updatequeryfor_apoxsave ="UPDATE tbl_upcoming_report SET apox_days_to_save = '$roundof_apox_days_to_save' WHERE  tbl_upcoming_report_id='$id'";
			$result_updatequeryfor_apoxsave = $this->db->query($updatequeryfor_apoxsave);
			//echo "test11 :";   echo "<br>";  exit();
			}
			//echo "test12 :";   echo "<br>";  exit();
			/*For GAP*/
			$sql4 = "SELECT * FROM tbl_upcoming_report ORDER BY aprx_date";
			$result4 = $this->db->query($sql4);
			$temp = "1901-01-01";
			foreach( $result4->result() as $row4 )
			{
				$id=$row4->tbl_upcoming_report_id; 
				$same_date = $row4->aprx_date;
				$diff = strtotime($same_date) - strtotime($temp); 
				$gap = abs(round($diff / 86400)); // echo "<br>";
				$temp = $same_date;
				$updatequeryfogap ="UPDATE tbl_upcoming_report SET gap = '$gap' WHERE tbl_upcoming_report_id='$id'";
				$result_updatequeryfogap = $this->db->query($updatequeryfogap);

			}
			//echo "test13 :";   echo "<br>";  exit();
			/*For Project 1*/

			$sql5 = "SELECT * FROM tbl_upcoming_report ORDER BY aprx_date";
			$result5 = $this->db->query($sql5);
			foreach( $result5->result() as $row5 )
			{
				$id=$row5->tbl_upcoming_report_id; 
				
				$date = $row5->aprx_date;
				$projected1 = date('Y-m-d', strtotime($date.'-'. $row5->apox_days_to_save.'days'));

				$updatequeryfor_projected_1 ="UPDATE tbl_upcoming_report SET project_1 = '$projected1' WHERE tbl_upcoming_report_id='$id'";
				$result_updatequeryfor_projected_1 = $this->db->query($updatequeryfor_projected_1);
				
			}
			//echo "test14 :";   echo "<br>";  exit();

			/*For Project_1 constant date*/

			$sql6 =  "SELECT project_1 FROM tbl_upcoming_report ORDER BY aprx_date limit 1";
			$result6 = $this->db->query($sql6);
			$row6=$result6->row();
			$cons_date=$row6->project_1;
			//echo "test15 :"; echo $cons_date;   echo "<br>";  exit();

			/*For Project 2*/
			$sql7 = "SELECT * FROM tbl_upcoming_report ORDER BY aprx_date";
			$result7 = $this->db->query($sql7);
			foreach( $result7->result() as $row7 )
			{
				$id=$row7->tbl_upcoming_report_id; 
				
				$f_p2 = date('Y-m-d', strtotime($cons_date.'-'. $row7->apox_days_to_save.'days'));
				$s_p2 = date('Y-m-d', strtotime($f_p2.'+'. $row7->gap.'days'));

				if ($id == $lowest_id) {
					$updatequeryforproj2 ="UPDATE tbl_upcoming_report SET project_2 = '$cons_date' WHERE tbl_upcoming_report_id='$id'";
					$resultforproj2 = $this->db->query($updatequeryforproj2);
				}else{
					$updatequeryforproj2 ="UPDATE tbl_upcoming_report SET project_2 = '$s_p2' WHERE tbl_upcoming_report_id='$id'";
					$resultforproj2 = $this->db->query($updatequeryforproj2);
				}	


			}
			//echo "test16 :";  echo "<br>";  exit();
			/*Update cash bank in table "tbl_tbl_cashinbank"*/

			/*Total Receive Loan*/
			$total_receive_loan = "SELECT SUM(pay_loan_amt) AS payloanamt FROM tbl_pay";
			$resultfortotalreceiveloan = $this->db->query($total_receive_loan);
			$row=$resultfortotalreceiveloan->row();
			$total_receive_loan1=$row->payloanamt;
				//echo "test17 :"; echo $total_receive_loan1 ;  echo "<br>";  //exit();
			/*Re-invest amt*/
			$re_invest_amt = "SELECT SUM(reinvest_amt) AS reinvestamt FROM tbl_loan_type_amt";
			$resultforreinvestamt = $this->db->query($re_invest_amt);
			$row=$resultforreinvestamt->row();
			$re_invest_amt1=$row->reinvestamt;
				//echo "test18 :"; echo $re_invest_amt1 ;  echo "<br>";  //exit();
			/*Expenses*/
			$expenses_amt = "SELECT SUM(amount) AS expamt FROM tbl_exp where cap_type = 2";
				//$expenses_amt = "SELECT SUM(amount) AS expamt FROM tbl_exp";
			$resultforexpamt = $this->db->query($expenses_amt);
			$row=$resultforexpamt->row();
			$expenses_amt1=$row->expamt;

				//echo "test19 :"; echo $expenses_amt1 ;  echo "<br>"; // exit();

			/*Cash in Bank*/
			$cash_in_bank_new = $total_receive_loan1 - $re_invest_amt1 - $expenses_amt1 ;
				// echo"Cash In Bank  ="; echo $cash_in_bank_new = $total_receive_loan1 - $re_invest_amt1 - $expenses_amt1 ; echo "<br>";echo "==================="; echo "<br>";		
			$updatequerycib ="UPDATE tbl_cashinbank SET cashinbank='$cash_in_bank_new' WHERE id='1'";
			$result1 = $this->db->query($updatequerycib);	
				//echo "test20 :"; echo $cash_in_bank_new ;  echo "<br>";  exit();
			return;	

	}

	public function insertfine($data)
	{
		return $this->db->insert('tbl_fines',$data);
	}
	public function allfine()
	{
		$query 	= $this->db->select('*')
		->where('isActive',0)
		->get('tbl_fines');
		return $query->result();
	}
	public function del_fines($id)
	{
		$updatequery = $this->db->where('tbl_fines_id', $id)
		->set('isActive', 1)
		->update('tbl_fines');

		return $updatequery;
	}
	public function fines()
	{
		$query  = $this->db->select_sum('amount')
		->from('tbl_fines')
		->where('isActive',0)
		->get();
		return $query->row();
	}

}

?>