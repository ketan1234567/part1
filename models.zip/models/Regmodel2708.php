<?php

class Regmodel extends CI_Model {



	public function reg_data($data)
	{
		return $this->db->insert('tbl_reg',$data);
	}

	public function login_valid($username,$password)
	{
		$query 	= $this->db->select('*')
							->where(['username' => $username, 'password' => $password])
							->where('is_active','1')
							->get('tbl_reg');
		return $query->row();
	}

	public function reg_loan($data)
	{
		return $this->db->insert('tbl_loan',$data);
	}

	public function passbook_data($customer_id)
	{
		$query 	= $this->db->select('*')
							->where('id',$customer_id)
							//->where(['is_approve'=>0])
							->get('tbl_loan');
		return $query->result();
	}
	public function loan_data($loan_id)
	{
		$query 	= $this->db->select('*')
							->where('loan_id',$loan_id)
							->get('tbl_loan');
		return $query->row();
	}

	public function loan_data_update($loan_id,$loan_amt,$lenderamt)
	{
		$updatequery = $this->db->where('loan_id', $loan_id)
								->set('loanamt', $loan_amt)
								->set('lenderamt', $lenderamt)
								->update('tbl_loan');
					
		return $updatequery;
	} 
	public function app_cust_list()
	{

		$query  = $this->db->select('*')
							  ->from('tbl_loan')
							  ->where('tbl_loan.is_approve',1)
							   ->where('tbl_loan.is_active',0)
							  ->join('tbl_reg','tbl_reg.id=tbl_loan.id')
							  ->get();   
  		return $query->result(); 
	}
	public function app_cust_list1()
	{

		$query  = $this->db->select('*')
							  ->from('tbl_loan')
							  ->where('tbl_loan.is_approve',1)
							  ->where('tbl_loan.is_active',1)
							  ->join('tbl_reg','tbl_reg.id=tbl_loan.id')
							  ->get();   
  		return $query->result(); 
	}

	public function loan_amt_pay($amtdata)
	{
		return $this->db->insert('tbl_pay',$amtdata);
	}

	public function show_loan_amt_passbkentry($loan_id)
	{
		$query  = $this->db->select('*')
							  ->from('tbl_pay')
							  //->join('tbl_loan','tbl_loan.loan_id=tbl_pay.loan_id')
							  ->where('loan_id',$loan_id)
							  ->get();   
  		return $query->result(); 
	}

	public  function show_loan_data($loan_id)
	{
		$query  = $this->db->select('*')
							  ->from('tbl_loan')
							  //->join('tbl_loan','tbl_loan.loan_id=tbl_pay.loan_id')
							  ->where('loan_id',$loan_id)
							  ->get();   
  		return $query->row(); 
	}
	public function show_collector_data()
	{
		$query  = $this->db->select('*')
							  ->from('tbl_reg')
							  //->join('tbl_loan','tbl_loan.loan_id=tbl_pay.loan_id')
							  ->where('type',2)
							  ->get();   
  		return $query->result(); 
	}
	public  function show_subtotal_data($loan_id)
	{
		$query  = $this->db->select_sum('pay_loan_amt')
							->where('loan_id',$loan_id)
							->get('tbl_pay');  
			return $query->row(); 
	}
	public  function lender_amt($loan_id)
	{
		$query  = $this->db->select('*')
							->where('loan_id',$loan_id)
							->get('tbl_loan');  
			return $query->row(); 
	}
	public function show_daily_collection()
	{
		$start_date = date("Y-m-d 00:00:00");
		$end_date = date("Y-m-d 23:59:59");
		//print_r($end_date); exit();
		$query  = $this->db->select('*')
							  	->from('tbl_pay')
							 	->where('timestamp >=', $start_date)
								->where('timestamp <=', $end_date)
								->where('collector_id',$this->session->userdata('id'))
							  ->get();   
  		return $query->result(); 

		
	}
	public function collector_daily_collection()
	{
		$start_date = date("Y-m-d 00:00:00");
		$end_date = date("Y-m-d 23:59:59");
  		$query  = $this->db->select_sum('pay_loan_amt')
						    ->from('tbl_pay')
						    ->where('timestamp >=', $start_date)
							->where('timestamp <=', $end_date)
							->where('collector_id',$this->session->userdata('id'))
						    ->get();
		return $query->row();

		
	}

	public function collector_all_collection()
	{
		$query  = $this->db->select_sum('pay_loan_amt')
						    ->from('tbl_pay')
							->where('collector_id',$this->session->userdata('id'))
						    ->get();
		return $query->row();
	}
	
	public function show_all_collection($collector_id)
	{
		
		$query  = $this->db->select('*')
							  	->from('tbl_pay')
							 	/*->where('timestamp >=', $start_date)
								->where('timestamp <=', $end_date)*/
								->where('collector_id',$collector_id)
							  ->get();   
  		return $query->result(); 

		
	}

	public function show_all_agents()
	{
		$query  = $this->db->select('*')
							  	->from('tbl_reg')
								->where('type',3)
								->order_by('id','desc')
							  ->get();   
  		return $query->result(); 
	}

	public function change_status($id,$val)
	{
		$updatequery = $this->db
							->set('is_active', $val)
							->where('id', $id)
							->update('tbl_reg');
						
		return $updatequery;
	}
	public function show_all_loan()
	{
		$query  = $this->db->select('*')
							  	->from('tbl_loan')
							  	->where('is_active',0)
								->order_by('loan_id','desc')
							  ->get();   
  		return $query->result(); 
	}
	public function change_approve($id,$val)
	{
		$updatequery = $this->db
							->set('is_approve', $val)
							->where('loan_id', $id)
							->update('tbl_loan');
						
		return $updatequery;
	}
	public function show_all_collector()
	{
		$query  = $this->db->select('*')
							  	->from('tbl_reg')
								->where('type',2)
							  ->get();   
  		return $query->result(); 
	}

	public function agent_data($id)
	{
		$query  = $this->db->select('*')
							  	->from('tbl_reg')
								->where('id',$id)
							  ->get();   
  		return $query->row(); 
	}
	public function store_report($data)
	{

	   return $this->db->insert('tbl_universal_product_upload_sheet',$data);
		
	}
	public function ind_loan_data($id)
	{
		$query  = $this->db->select('*')
							  	->from('tbl_loan')
								->where('id',$id)
								->where('is_approve',1)
							  ->get();   
  		return $query->result(); 
	}
	public function total_given_loan()
	{
		$query  = $this->db->select_sum('loanamt')
			    ->from('tbl_loan')
			    ->get();
		return $query->row();
	}
	public function total_receive_loan()
	{
		$query  = $this->db->select_sum('pay_loan_amt')
			    ->from('tbl_pay')
			    ->get();
		return $query->row();
	}

	public function total_active_loan()
	{
		/*$query  = $this->db->select('*')
			    ->from('tbl_loan')
			    ->where('is_approve',1)
			    // ->where('is_active',0)
			    ->get();
		return $query->count_all_results();*/
		$query = $this->db->where(['is_active'=>0])
							->where(['is_approve'=>1])
								->from("tbl_loan");
		return $query->count_all_results();
	}

	public function total_closed_loan()
	{
		$query = $this->db->where(['is_active'=>1])
							->where(['is_approve'=>1])
								->from("tbl_loan");
		return $query->count_all_results();
	}

	public function cust_active_loan()
	{
		$query = $this->db->where(['id'=> $this->session->userdata('id')])
							->where(['is_active'=>0])
							->where(['is_approve'=>1])
								->from("tbl_loan");
		return $query->count_all_results();
	}
	public function cust_inactive_loan()
	{
		$query = $this->db->where(['id'=> $this->session->userdata('id')])
							->where(['is_active'=>1])
							->where(['is_approve'=>1])
								->from("tbl_loan");
		return $query->count_all_results();
	}
	public function cust_pending_loan()
	{
		$query = $this->db->where(['id'=> $this->session->userdata('id')])
							//->where(['is_active'=>0])
							->where(['is_approve'=>0])
								->from("tbl_loan");
		return $query->count_all_results();
	}

	

	public function cust_details($id)
	{
		$query  = $this->db->select('*')
							  	->from('tbl_reg')
								->where('id',$id)
							  ->get();   
  		return $query->row(); 
	}

	public function update_loan_status($loan_id)
	{
		$this->db->where('loan_id', $loan_id)
					->set('is_active', 1)
					->update('tbl_loan');
	}

	public function lender_all_collection()
	{
		$query  = $this->db->select_sum('lenderamt')
			    ->from('tbl_loan')
			    ->get();
		return $query->row();
	}

	public function get_last_reg_id()
	{
		$get_reg_id_query = $this->db->select(['id'])
						->from('tbl_reg')
						->order_by("id","DESC")
						->limit(1)
						->get();

		return $get_reg_id_query->row('id');
	}

	public function store_image($data)
	{
		return $this->db->insert('tbl_image',$data);
	}
	
	public function reset_pass($id,$pass)
	{
		$updatequery = $this->db->where('id', $id)
								->set('password', $pass)
								->update('tbl_reg');
					
		return $updatequery;
	}
	
	

}

?>