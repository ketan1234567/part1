


<form align="center" action="<?php echo base_url();?>index.php/uploadreport" method="post" enctype="multipart/form-data" >


	<input type="file" name="uploaduni" class="form-control btn">
	<button type="submit" class="btn btn-outline-primary waves-effect waves-light btn-excel" >Upload File</button>
</form>

 
	

  </div>
  <!-- End container-fluid-->

</div><!--End content-wrapper-->


<!-- Bootstrap core JavaScript-->
<script src="<?php echo base_url();?>assets/js/jquery.min.js"></script>
<script src="<?php echo base_url();?>assets/js/popper.min.js"></script>
<script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>

<!-- simplebar js -->
<script src="<?php echo base_url();?>assets/plugins/simplebar/js/simplebar.js"></script>
<!-- waves effect js -->
<script src="<?php echo base_url();?>assets/js/waves.js"></script>
<!-- sidebar-menu js -->
<script src="<?php echo base_url();?>assets/js/sidebar-menu.js"></script>
<!-- Custom scripts -->
<script src="<?php echo base_url();?>assets/js/app-script.js"></script>

<!--Data Tables js-->
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/dataTables.bootstrap4.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/dataTables.buttons.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/buttons.bootstrap4.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/jszip.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/pdfmake.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/vfs_fonts.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/buttons.html5.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/buttons.print.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/buttons.colVis.min.js"></script>

<!--Form Validatin Script--> 
<script src="<?php echo base_url();?>assets/plugins/jquery-validation/js/jquery.validate.min.js"></script>










