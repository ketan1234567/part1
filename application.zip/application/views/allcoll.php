
<div class="row">
  <div class="col-lg-12">
    <div class="card">
      <div class="card-header"><i class="fa fa-table"></i> All Collection </div>
      <div class="card-body">
        <div class="table-responsive">
          <table id="example" class="table table-bordered">
            <thead>
              <tr>
                <th>#</th> 
                <th>Collection Date</th>
                <th>Loan ID</th>
                <th>Payment</th>
                 <th>Action</th>
                
              </tr>
            </thead>
            <tbody>
             <?php $i=1; if(count($allcollection)){ ?>
               <?php foreach ($allcollection as $result) { ?>
                <tr>
                  <td><?= $i ?></td> 
                  <!--<td><?= $result->loandate ?></td>-->
                  <td><?php $yrdata= strtotime($result->loandate);
                          echo date('d-M-Y', $yrdata); ?></td>
                   <td><?= $result->loan_id."-".$result->fname." ".$result->lname ?></td>
                  <td><?= $result->pay_loan_amt ?></td>
                  <td>
                    <a href="#" class="btn btn-outline-success btn-sm waves-effect waves-light m-1" title="Collection" data-toggle="modal" data-target="#payeditmodal" data-index="<?=$result->pay_id;?>" name="payedit"><i class="fa fa-pencil"></i></a>

                    <a href="<?php echo base_url();?>index.php/deletepay/<?= $result->pay_id ?>" class="btn btn-outline-danger btn-sm waves-effect waves-light m-1" title="Delete Amount"><i class="fa fa-trash-o"></i></a>
                   
                  </td>
                  
                </tr>
                <?php $i++;} ?>
                <?php } else { ?>
                  <tr>
                    <td colspan="5">
                      No record found.
                    </td>
                  </tr>

                <?php } ?> 
                <!--<tr>
                  <td><b>Total Collection</b></td>
                  <td></td>
                  <td></td>
                  <td><b>
                    <?php 
                    $sum = 0;
                      for ($i=0; $i < count($allcollection) ; $i++) { 
                        $sum = $sum + $allcollection[$i]->pay_loan_amt;
                      }
                      print_r($sum);
                     ?>
                </b></td>
                </tr>-->
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div><!-- End Row-->

</div>
<!-- End container-fluid-->

</div><!--End content-wrapper-->
<!--Start Back To Top Button-->
<a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
<!--End Back To Top Button-->


  </div><!--End wrapper-->
  <!-- Modal -->
  <div class="modal fade" id="payeditmodal">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title"><i class="fa fa-star"></i> Edit Pay Amount</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <!-- <label>Loan ID</label> -->
          <input type="hidden" class="form-control" id="loan_id" name="loan_id" value="" readonly>
          <!-- <label>Pay ID</label> -->
          <input type="hidden" class="form-control" id="pay_id" name="pay_id" value="" readonly>
          <label>Edit Amount</label>
          <input type="text" name="edit_amount" id="edit_amount" class="form-control" required>
          <label>Edit Amount</label>
          <input type="date" name="edit_loandate" id="edit_loandate" class="form-control" required>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
          <div id="show_hide">
            <button type="button" onclick="pay_amt()" class="btn btn-primary"><i class="fa fa-check-square-o"></i> Save</button>
          </div>
          
        </div>
      </div>
    </div>
  </div>


  <!-- Bootstrap core JavaScript-->
  <script src="<?php echo base_url();?>assets/js/jquery.min.js"></script>
  <script src="<?php echo base_url();?>assets/js/popper.min.js"></script>
  <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>

  <!-- simplebar js -->
  <script src="<?php echo base_url();?>assets/plugins/simplebar/js/simplebar.js"></script>
  <!-- waves effect js -->
  <script src="<?php echo base_url();?>assets/js/waves.js"></script>
  <!-- sidebar-menu js -->
  <script src="<?php echo base_url();?>assets/js/sidebar-menu.js"></script>
  <!-- Custom scripts -->
  <script src="<?php echo base_url();?>assets/js/app-script.js"></script>

  <!--Data Tables js-->
  <script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/jquery.dataTables.min.js"></script>
  <script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/dataTables.bootstrap4.min.js"></script>
  <script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/dataTables.buttons.min.js"></script>
  <script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/buttons.bootstrap4.min.js"></script>
  <script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/jszip.min.js"></script>
  <script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/pdfmake.min.js"></script>
  <script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/vfs_fonts.js"></script>
  <script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/buttons.html5.min.js"></script>
  <script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/buttons.print.min.js"></script>
  <script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/buttons.colVis.min.js"></script>

  <script>
   $(document).ready(function() {
      //Default data table
      $('#default-datatable').DataTable();


      var table = $('#example').DataTable( {
        lengthChange: false,
       buttons: [ 'excel' ]
      } );

      table.buttons().container()
      .appendTo( '#example_wrapper .col-md-6:eq(0)' );
      
    } );

  </script>

</body>
</html>
<script type="text/javascript">

    $("a[name=payedit]").on("click", function () { 
      var pay_id = $(this).data("index"); 
      //$("#collector_id").val(pay_id);
      // alert('pay_id');
      // alert(pay_id);
              $.ajax({
                url: '<?php echo base_url(); ?>index.php/show_loanid',
                type: 'POST',
                data:  { 'pay_id' : pay_id },
                success: function(response,status,xhr) {
                console.info(response);
                var a =jQuery.parseJSON(response);
                $("#pay_id").val(a.pay_id); 
                $("#loan_id").val(a.loan_id);
                $("#edit_amount").val(a.pay_loan_amt);
                $("#edit_loandate").val(a.loandate);  
                    // $("#pay_id").html(str);
                }
              }); 
            });
          </script>
<script type="text/javascript">
  function pay_amt()
    {
         //alert('hi');
          var loan_id = $("#loan_id").val();
          var pay_id = $("#pay_id").val();
          var edit_amt = $("#edit_amount").val();
          var loandate = $("#edit_loandate").val();
          
          //alert(loan_id); alert(pay_id);alert(edit_amt);
          
            $.ajax({
              url: '<?php echo base_url();?>index.php/edit_pay_amount',
              type: 'POST',
              data:  { 'loan_id' : loan_id, 'pay_id' :pay_id,'edit_amt':edit_amt , 'loandate':loandate },
              success: function(response,status,xhr) {
                        console.info(response);
                        //swal("success", "Payment Edited Successfully!");
                        location.reload();
                        //$('#payeditmodal').modal('hide');
                        //window.reload();

                      }
                    });
        }
</script>


