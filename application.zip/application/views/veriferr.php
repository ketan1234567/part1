<style type="text/css">
  label.required { color: red; font-size: 20px; }
</style>
<div class="row">
  <div class="col-lg-12">
    <div class="card">
      <div class="card-header"><i class="fa fa-calculator"></i> Verifer </div>
      <div class="card-body">
        <?php echo form_open('index.php/verifersearch'); ?>
        <div class="form-group row">
          <label  class="col-sm-3 col-form-label">User's</label>
          <div class="form-group col-sm-6">

            <select class="form-control single-select" name="user_id">
             <!--  <option selected >Select User</option> -->
              <?php foreach ($verifer_cust as $result) { ?>
                <option value="<?= $result->id ?>"><?= $result->fname." ".$result->lname ?></option>
              <?php } ?> 
            </select>
          </div>
          <div class="form-group col-sm-3">

            <button type="submit" class="btn btn-outline-primary waves-effect waves-light" ><i class="fa fa-user mr-1"></i> Go</button>
          </div>

        </div>
        <?php echo form_close(); ?>
        <div>
          <label>Good (< 5 )%</label> <span class="badge badge-success m-1">Good</span><br>
          <label>Average (5 > to <= 10)%</label> <span class="badge badge-warning m-1">Average</span><br>
          <label>Poor (> 10 )%</label><span class="badge badge-danger m-1">Danger</span><br>
        </div>



      </div>
    </div>
  </div>
</div><!-- End Row-->

<div class="row">
  <div class="col-lg-12">
    <div class="card">
      <div class="card-header"><i class="fa fa-table"></i> Result </div>
      <div class="card-body">
        <div class="table-responsive">
          <table id="example" class="table table-bordered">
            <thead>
              <tr>
               <!--  <th>#</th> -->
                <th>Name</th>
                <th>Result</th>
               <!--  <th>Collector</th>
                <th>Action</th> -->
                
              </tr>
            </thead>
            <tbody>
            
                <tr>
                  <!-- <td><?= $i ?></td> -->
                  <td><?= $verifersearch_data[0]->fname." ".$verifersearch_data[0]->lname ?></td>
                  <td> <?php if ($final<=5) { ?>
                    <span class="badge badge-success m-1">Good</span>
                    
                    
                  <?php }elseif ($final > 5 && $final <= 10) {  ?>
                    <span class="badge badge-warning m-1">Average</span>

                   <?php }else{ ?>

                    <span class="badge badge-danger m-1">Danger</span>
                   <?php } ?>
                  </td>     


              </tr>
             
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
</div><!-

</div>
<!-- End container-fluid-->

</div><!--End content-wrapper-->
<!--Start Back To Top Button-->
<a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
<!--End Back To Top Button-->


</div>






<!-- Bootstrap core JavaScript-->
<script src="<?php echo base_url();?>assets/js/jquery.min.js"></script>
<script src="<?php echo base_url();?>assets/js/popper.min.js"></script>
<script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>

<!-- simplebar js -->
<script src="<?php echo base_url();?>assets/plugins/simplebar/js/simplebar.js"></script>
<!-- waves effect js -->
<script src="<?php echo base_url();?>assets/js/waves.js"></script>
<!-- sidebar-menu js -->
<script src="<?php echo base_url();?>assets/js/sidebar-menu.js"></script>
<!-- Custom scripts -->
<script src="<?php echo base_url();?>assets/js/app-script.js"></script>
<!--Select Plugins Js-->
<script src="<?php echo base_url();?>assets/plugins/select2/js/select2.min.js"></script>
<!--Multi Select Js-->
<script src="<?php echo base_url();?>assets/plugins/jquery-multi-select/jquery.multi-select.js"></script>
<script src="<?php echo base_url();?>assets/plugins/jquery-multi-select/jquery.quicksearch.js"></script>

<!--Data Tables js-->
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/dataTables.bootstrap4.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/dataTables.buttons.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/buttons.bootstrap4.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/jszip.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/pdfmake.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/vfs_fonts.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/buttons.html5.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/buttons.print.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/buttons.colVis.min.js"></script>


<script>
 $(document).ready(function() {
      //Default data table
      $('#default-datatable').DataTable();


      var table = $('#example').DataTable( {
        lengthChange: false,
        buttons: [ 'excel','colvis' ]
      } );

      table.buttons().container()
      .appendTo( '#example_wrapper .col-md-6:eq(0)' );
      
    } );

  </script>
  <script type="text/javascript">

    $("a[name=changeapprove]").on("click", function () { 
      var id = $(this).data("index"); 
              //alert(id);
              $.ajax({
                url: '<?php echo base_url(); ?>index.php/changeapprove',
                type: 'POST',
                data:  { 'id' : id, 'val': 1 },
                success: function(response,status,xhr) {
                  //console.info(response);
                  //window.location.href="vendorlist";
                  //alert(response);
                  location.relode();

                }
              }); 
            });
    $("a[name=changeapprove1]").on("click", function () { 
      var id = $(this).data("index"); 
              //alert(id);
              $.ajax({
                url: '<?php echo base_url(); ?>index.php/changeapprove',
                type: 'POST',
                data:  { 'id' : id, 'val': 0 },
                success: function(response,status,xhr) {
                  //console.info(response);
                  //window.location.href="vendorlist";
                  //alert(response);
                  location.relode();

                }
              }); 
            });
          </script>

        </body>

        </html>
        

        <script type="text/javascript">
          function calculation()
          {

           var loanamt = $("#loanamt").val();
           var rate1 = $("#rate").val();
           var days = $("#days").val();
           if (loanamt && rate1 && days ) {
            var flag = 1;
          }
          if (flag === 1) {
            var rate = rate1/100;

            var totalamount = (rate*loanamt) + +loanamt ;
            $("#totalamt").val(totalamount);
            $("#totalamt1").text(totalamount);
            var daily1 = totalamount/days;
            var daily = Math.round(daily1);
               //alert(daily);
               $("#dailycoll").val(daily);
               $("#dailycoll1").text(daily);
             }else{
              alert("Please Fill all value !!!")
            }


          }
        </script>
        <script>
          $(document).ready(function() {
            $('.single-select').select2();

            $('.multiple-select').select2();

        //multiselect start

        $('#my_multi_select1').multiSelect();
        $('#my_multi_select2').multiSelect({
          selectableOptgroup: true
        });

        $('#my_multi_select3').multiSelect({
          selectableHeader: "<input type='text' class='form-control search-input' autocomplete='off' placeholder='search...'>",
          selectionHeader: "<input type='text' class='form-control search-input' autocomplete='off' placeholder='search...'>",
          afterInit: function (ms) {
            var that = this,
            $selectableSearch = that.$selectableUl.prev(),
            $selectionSearch = that.$selectionUl.prev(),
            selectableSearchString = '#' + that.$container.attr('id') + ' .ms-elem-selectable:not(.ms-selected)',
            selectionSearchString = '#' + that.$container.attr('id') + ' .ms-elem-selection.ms-selected';

            that.qs1 = $selectableSearch.quicksearch(selectableSearchString)
            .on('keydown', function (e) {
              if (e.which === 40) {
                that.$selectableUl.focus();
                return false;
              }
            });

            that.qs2 = $selectionSearch.quicksearch(selectionSearchString)
            .on('keydown', function (e) {
              if (e.which == 40) {
                that.$selectionUl.focus();
                return false;
              }
            });
          },
          afterSelect: function () {
            this.qs1.cache();
            this.qs2.cache();
          },
          afterDeselect: function () {
            this.qs1.cache();
            this.qs2.cache();
          }
        });

        $('.custom-header').multiSelect({
          selectableHeader: "<div class='custom-header'>Selectable items</div>",
          selectionHeader: "<div class='custom-header'>Selection items</div>",
          selectableFooter: "<div class='custom-header'>Selectable footer</div>",
          selectionFooter: "<div class='custom-header'>Selection footer</div>"
        });



      });

    </script>
