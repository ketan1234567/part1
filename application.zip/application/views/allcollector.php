<!-- Breadcrumb-->
<div class="row pt-2 pb-2">
  <div class="col-sm-9">
    <h4 class="page-title">All Collector</h4>
  </div>
  <div class="col-sm-3">
   <div class="btn-group float-sm-right">
    <button type="button" class="btn btn-outline-primary waves-effect waves-light" data-toggle="modal" data-target="#addcollectoremodal"><i class="fa fa-user mr-1"></i> ADD Collector</button>
  </div>
</div>
</div>
<div class="row">
  <div class="col-lg-12">
    <div class="card">
      <!-- <div class="card-header"><i class="fa fa-table"></i> All Collector </div> -->
      <div class="card-body">
        <div class="table-responsive">
          <table id="example" class="table table-bordered">
            <thead>
              <tr>
                <th>#</th>
                <th>Collector List</th>
                <!-- <th>Status</th> -->
                <th>Action</th>
                
              </tr>
            </thead>
            <tbody>
             <?php $i=1; if(count($allcollector)){ ?>
               <?php foreach ($allcollector as $result) { ?>
                <tr>
                  <td><?= $i ?></td>
                  <td><?= $result->fname ?> <?= $result->lname ?></td>
                  <td><a href="<?php echo base_url();?>index.php/ind_collection/<?= $result->id ?>" class="btn btn-outline-success btn-sm waves-effect waves-light m-1" title="Show Collector Data">Collection</a>
                   
                   <a href="#" class="btn btn-outline-info btn-sm waves-effect waves-light m-1" title="Collection" data-toggle="modal" data-target="#paymodal" data-index="<?=$result->id;?>" name="payamt">PAY</a>
                   <a href="<?php echo base_url();?>index.php/daily_collection/<?= $result->id ?>" class="btn btn-outline-warning btn-sm waves-effect waves-light m-1" title="Show Collector Data">Daily collection</a>
                   </td>
                  
                </tr>
                <?php $i++;} ?>
              <?php } else { ?>
                <tr>
                  <td colspan="4">
                    No record found.
                  </td>
                </tr>

              <?php } ?> 
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div><!-- End Row-->

</div>
<!-- End container-fluid-->

</div><!--End content-wrapper-->
<!--Start Back To Top Button-->
<a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
<!--End Back To Top Button-->

  </div><!--End wrapper-->
  <!-- Modal -->
  <div class="modal fade" id="paymodal">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title"><i class="fa fa-star"></i> Collect Money</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <label>Collector</label>
          <input type="text" class="form-control" id="collector_id" name="collector_id" value="" readonly>
          <label>Loan ID</label>
          <!-- <input type="text" class="form-control col-sm-12" id="loan_id" name="loan_id" readonly="readonly"> -->
          
          <select class="form-control" id="loan_list" onchange="set_loan_amt();">
            <option selected disabled>-Select Loan-</option>
            <?php foreach ($col_assn_loan as $col_assn_loan){ ?>
                            <option value="<?=$col_assn_loan->loan_id; ?>"><?=$col_assn_loan->loan_id; ?></option>
                          <?php } ?>
          </select>
          <label>Loan Amount</label>
          <input type="text" class="form-control col-sm-12" id="loanamt" name="loanamt" readonly="readonly">
          <label>Pay Amount</label>
          <input type="number" class="form-control col-sm-12" id="pay_loan_amt1" name="pay_loan_amt" placeholder="Amount" onchange="showhide()" required="required" >
          <label>Loan Date</label>
          <input type="date" id="loandate" name="loandate" class="form-control col-sm-12" required="required" > 
          <!-- <input type="text" name="loandate" id="autoclose-datepicker" class="form-control" required> -->
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
          <div id="show_hide">
            <button type="button" onclick="pay_amt()" class="btn btn-primary"><i class="fa fa-check-square-o"></i> Save</button>
          </div>
          
        </div>
      </div>
    </div>
  </div>


  <!-- addcollectoremodal Modal -->
<div class="modal fade" id="addcollectoremodal">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title"><i class="fa fa-star"></i> Add Collector</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <?php echo form_open('index.php/insertcollector'); ?>
        <div class="form-group row">
          <label for="input-2" class="col-sm-4 col-form-label">First Name</label>
          <div class="col-sm-8">
           <input type="text" name="fname" id="fname" class="form-control form-control-rounded" placeholder="First Name" required="required">
          </div>
        </div>
        <div class="form-group row">
          <label for="input-2" class="col-sm-4 col-form-label">Last Name</label>
          <div class="col-sm-8">
           <input type="text" name="lname" id="fname" class="form-control form-control-rounded" placeholder="Last Name" required="required">
          </div>
        </div>
        <div class="form-group row">
          <label for="input-2" class="col-sm-4 col-form-label">User Name</label>
          <div class="col-sm-8">
           <input type="text" name="username" id="username" class="form-control form-control-rounded" placeholder="User Name" required="required">
          </div>
        </div>
        <div class="form-group row">
          <label for="input-2" class="col-sm-4 col-form-label">Password</label>
          <div class="col-sm-8">
           <input type="text" name="password" id="password" class="form-control form-control-rounded" placeholder="Password" required="required">
          </div>
        </div>
        <input type="hidden" name="type" value="2">
        
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
        <button type="submit" class="btn btn-primary"><i class="fa fa-check-square-o"></i> Add</button>
      </div>
      <?php echo form_close(); ?>
    </div>
  </div>
</div>


  <!-- Bootstrap core JavaScript-->
  <script src="<?php echo base_url();?>assets/js/jquery.min.js"></script>
  <script src="<?php echo base_url();?>assets/js/popper.min.js"></script>
  <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>

  <!-- simplebar js -->
  <script src="<?php echo base_url();?>assets/plugins/simplebar/js/simplebar.js"></script>
  <!-- waves effect js -->
  <script src="<?php echo base_url();?>assets/js/waves.js"></script>
  <!-- sidebar-menu js -->
  <script src="<?php echo base_url();?>assets/js/sidebar-menu.js"></script>
  <!-- Custom scripts -->
  <script src="<?php echo base_url();?>assets/js/app-script.js"></script>

  <!--Data Tables js-->
  <script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/jquery.dataTables.min.js"></script>
  <script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/dataTables.bootstrap4.min.js"></script>
  <script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/dataTables.buttons.min.js"></script>
  <script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/buttons.bootstrap4.min.js"></script>
  <script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/jszip.min.js"></script>
  <script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/pdfmake.min.js"></script>
  <script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/vfs_fonts.js"></script>
  <script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/buttons.html5.min.js"></script>
  <script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/buttons.print.min.js"></script>
  <script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/buttons.colVis.min.js"></script>

  <script>
   $(document).ready(function() {
      //Default data table
      $('#default-datatable').DataTable();


      var table = $('#example').DataTable( {
        lengthChange: false,
        buttons: [ 'excel' ]
      } );

      table.buttons().container()
      .appendTo( '#example_wrapper .col-md-6:eq(0)' );
      
    } );

  </script>
  <script type="text/javascript">

  $("a[name=changestatus]").on("click", function () { 
      var id = $(this).data("index"); 
              //alert(id);
              $.ajax({
                url: '<?php echo base_url(); ?>index.php/changestatus',
                type: 'POST',
                data:  { 'id' : id, 'val': 1 },
                success: function(response,status,xhr) {
                  //console.info(response);
                  //window.location.href="vendorlist";
                  //alert(response);
                  location.relode();

                }
              }); 
            });
  $("a[name=changestatus1]").on("click", function () { 
      var id = $(this).data("index"); 
              //alert(id);
              $.ajax({
                url: '<?php echo base_url(); ?>index.php/changestatus',
                type: 'POST',
                data:  { 'id' : id, 'val': 0 },
                success: function(response,status,xhr) {
                  //console.info(response);
                  //window.location.href="vendorlist";
                  //alert(response);
                  location.relode();

                }
              }); 
            });
</script>

</body>


</html>
<script type="text/javascript">
  
function showhide()
{
  var given_amt = $("#pay_loan_amt1").val();
  var min_amt = $("#loanamt").val()*1/100;
  /*alert(given_amt);
  alert(min_amt);*/
  if(min_amt == given_amt) {
    $('#show_hide').show();
    
  } else if(min_amt <= given_amt) {
    $('#show_hide').show();
    
  }else{
    $('#show_hide').hide();
  }
}

</script>
 <script type="text/javascript">
  function pay_amt()
    {
        // alert('hi');
          //var loan_id = $("#loan_id").val();
          var loan_id = $("#loan_list").val();
          
          var collector_id = $("#collector_id").val(); 
          var loanamt = $("#loanamt").val();
          var pay_loan_amt = $("#pay_loan_amt1").val();
          var loandate = $("#loandate").val();
          var inpObj = document.getElementById("pay_loan_amt1");
          var inpObj1 = document.getElementById("loandate");
          
          //alert(loan_id);
          if (!inpObj.checkValidity()) {
            alert('Please Enter Amount');
          }
          else if (!inpObj1.checkValidity()) {
            alert('Please Enter date');
          }else if (loan_id==="null") {
            alert('Please Select Loan');
          }  

          else {
            $.ajax({
              url: '<?php echo base_url();?>index.php/collectloanamt',
              type: 'POST',
              data:  { 'loan_id' : loan_id, 'collector_id':collector_id, 'loanamt' :loanamt,'pay_loan_amt':pay_loan_amt,'loandate':loandate },
              success: function(response,status,xhr) {
                        //console.info(response);
                        //window.location.href="vendorlist";
                        //alert(response);
                        //var a =jQuery.parseJSON(response);
                        //location.reload();
                        swal("success", "Payment Added Successfully!");
                        //location.reload();
                        $('#paymodal').modal('hide');
                        //window.reload();
                      }
                    });
          } 

        }
        function set_loan_amt()
        {
          var loan_id = $("#loan_list").val();

          
          //alert(loan_id);
          $.ajax({
                url: '<?php echo base_url(); ?>index.php/showloanamt',
                type: 'POST',
                data:  { 'loan_id' : loan_id },
                success: function(response,status,xhr) {
                //console.info(response);
                  //window.location.href="vendorlist";
                  //alert(response);
                  var a =jQuery.parseJSON(response);
                  var min_amt = a.loanamt*1/100;

                  // //alert(min_amt);
                   if (response) 
                   {
                    $("#loanamt").val(a.loanamt);
                    $("#pay_loan_amt1").val(min_amt);
                   }
                }
              });
        }

  
</script>
  <script type="text/javascript">

    $("a[name=payamt]").on("click", function () { 
      var coll_id = $(this).data("index"); 
      $("#collector_id").val(coll_id);
              // alert('collector');
              // alert(coll_id);
              $.ajax({
                url: '<?php echo base_url(); ?>index.php/showloanid',
                type: 'POST',
                data:  { 'coll_id' : coll_id },
                success: function(response,status,xhr) {
                console.info(response);
                  //window.location.href="vendorlist";
                  //alert(response);
                  var obj = JSON.parse(response);
                  var str='';
                     str +='<option value= null>-Select Loan Id-</option>';
                     for(var i=0; i<obj.length; i++){
                         str +="<option value="+obj[i].loan_id+">"+obj[i].loan_id+"-"+obj[i].fname+" "+obj[i].lname+"</option>";
                     }
                    $("#loan_list").html(str);
                }
              }); location.refresh();
            });
          </script>
