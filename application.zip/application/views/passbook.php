
<div class="row">
  <div class="col-lg-12">
    <div class="card">
      <div class="card-header"><i class="fa fa-table"></i> Pass-Book </div>
      <div class="card-body">
        <div class="table-responsive">
          <table id="example" class="table table-bordered">
            <thead>
              <tr>
                <th>Loan ID</th>
                <th>Loan Ammount</th>
                <th>Loan Date</th>
                <th>Approve</th>
                <th>Status</th>
                <th>Pass-book</th>

              </tr>
            </thead>
            <tbody>
             <?php $i=1; if(count($selfpassbook)){ ?>
               <?php foreach ($selfpassbook as $result) { ?>
                <tr>
                  <td><?= $result->loan_id ?></td>
                  <td><?= $result->loanamt ?></td>
                  <td><?= $result->loandate ?></td>
                  <td><?php if ($result->is_approve==0) 
                    { ?>
                      <span class="badge badge-danger m-1">No</span>
                    <?php }if ($result->is_approve==1) 
                    {
                      ?>
                      <span class="badge badge-success m-1">Yes</span>
                    <?php
                    }  ?>
                  </td>
                  <td>
                    <?php if ($result->is_active==0 && $result->is_approve==1 ) { ?>
                       <h6>Active</h6>
                    <?php }else if ($result->is_active==1 && $result->is_approve==1) { ?>
                      <h6>Closed</h6>
                    <?php }else {  ?>
                      <h6>Pending</h6>
                    <?php } ?>
                  </td>
                    <?php 
                        $encode= $result->loan_id ;
                        $ecode1 = base64_encode($encode);
                        $ecode2= trim($ecode1,'=');
                    ?> 
                  <td>
                    <?php if ($result->is_approve==1) { ?>
                      <a href="<?php echo base_url();?>index.php/showpassbook/<?= $ecode2 ?>" class="btn btn-outline-success btn-sm waves-effect waves-light m-1" title="Edit">Passbook</a>
                    <?php }else{ ?>
                      <span class="badge badge-danger m-1">Not Generate</span>

                    <?php } ?>
                  </td>

                </tr>
                <?php $i++;} ?>
                <?php } else { ?>
                  <tr>
                    <td colspan="5">
                      No record found.
                    </td>
                  </tr>

                <?php } ?> 
              </tbody>
              <!-- <tfoot>
                <tr>
                  <th>Loan ID</th>
                  <th>Loan Ammount</th>
                  <th>Loan Date</th>
                  <th>View</th>

                </tr>
              </tr><
            </tfoot> -->
          </table>
        </div>
      </div>
    </div>
  </div>
</div><!-- End Row-->

</div>
<!-- End container-fluid-->

</div><!--End content-wrapper-->
<!--Start Back To Top Button-->
<a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
<!--End Back To Top Button-->

<!--Start footer-->
	<!-- <footer class="footer">
      <div class="container">
        <div class="text-center">
          Copyright © 2018 Rocker Admin
        </div>
      </div>
    </footer> -->
    <!--End footer-->

  </div><!--End wrapper-->


  <!-- Bootstrap core JavaScript-->
  <script src="<?php echo base_url();?>assets/js/jquery.min.js"></script>
  <script src="<?php echo base_url();?>assets/js/popper.min.js"></script>
  <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>

  <!-- simplebar js -->
  <script src="<?php echo base_url();?>assets/plugins/simplebar/js/simplebar.js"></script>
  <!-- waves effect js -->
  <script src="<?php echo base_url();?>assets/js/waves.js"></script>
  <!-- sidebar-menu js -->
  <script src="<?php echo base_url();?>assets/js/sidebar-menu.js"></script>
  <!-- Custom scripts -->
  <script src="<?php echo base_url();?>assets/js/app-script.js"></script>

  <!--Data Tables js-->
  <script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/jquery.dataTables.min.js"></script>
  <script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/dataTables.bootstrap4.min.js"></script>
  <script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/dataTables.buttons.min.js"></script>
  <script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/buttons.bootstrap4.min.js"></script>
  <script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/jszip.min.js"></script>
  <script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/pdfmake.min.js"></script>
  <script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/vfs_fonts.js"></script>
  <script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/buttons.html5.min.js"></script>
  <script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/buttons.print.min.js"></script>
  <script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/buttons.colVis.min.js"></script>

  <script>
   $(document).ready(function() {
      //Default data table
      $('#default-datatable').DataTable();


      var table = $('#example').DataTable( {
        lengthChange: false,
       buttons: [ 'excel','colvis' ]
      } );

      table.buttons().container()
      .appendTo( '#example_wrapper .col-md-6:eq(0)' );
      
    } );

  </script>

</body>

<!-- Mirrored from codervent.com/rocker/white-version/table-data-tables.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 13 Dec 2018 14:16:37 GMT -->
</html>
