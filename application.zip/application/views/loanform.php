      <div class="row">
        <div class="col-lg-12">
          <div class="card">
            <div class="card-body">
              <!-- <form id="personal-info"> -->
                <?php echo form_open('index.php/storeloan',['id' => 'loan-info']); ?>
                <h4 class="form-header text-uppercase">
                  <i class="fa fa-user-circle-o"></i>
                  Loan Info
                </h4>
                <div class="form-group row">
                  <label for="input-1" class="col-sm-2 col-form-label">User Name</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="input-1" name="fname" value="<?= $this->session->userdata('fname');  ?> <?= $this->session->userdata('lname');  ?>" required>
                  </div>
                  <input type="hidden" name="id" value="<?= $this->session->userdata('id');  ?>">
                </div>
                <div class="form-group row">
                  <label for="input-4" class="col-sm-2 col-form-label">Loan Ammount</label>
                  <div class="col-sm-10">
                    <input type="number" placeholder="Please Insert loan amount" class="form-control" id="loanamt" name="loanamt" required min="10" onchange="lendercount();" >
                    <input type="hidden" class="form-control" id="lenderamt" name="lenderamt">
                  </div>
                </div>
                <div class="form-group row">
                  <label for="input-4" class="col-sm-2 col-form-label">Loan Date</label>
                  <div class="col-sm-10">
                    <input type="text" name="loandate" id="autoclose-datepicker" class="form-control" required>
                  </div>
                </div>

                <div class="form-footer">
                  <button type="reset" class="btn btn-danger"><i class="fa fa-times"></i> CANCEL</button>
                  <button type="submit" class="btn btn-success"><i class="fa fa-check-square-o"></i> SAVE</button>
                </div>
                <?php echo form_close(); ?>
              </div>
            </div>
          </div>
          <div class="col-lg-12">
            <div class="card">
              <div class="col-lg-12">
                <!-- <div class="card"> -->
                  <div class="card-header"><i class="fa fa-table"></i> Pass-Book </div>
                  <div class="card-body">
                    <div class="table-responsive">
                      <table id="example" class="table table-bordered">
                        <thead>
                          <tr>
                            <th>Loan ID</th>
                            <th>Loan Ammount</th>
                            <th>Loan Date</th>
                            <!--  <th>Approve</th> -->
                            <th>Action</th>

                          </tr>
                        </thead>
                        <tbody>
                         <?php $i=1; if(count($selfpassbook)){ ?>
                           <?php foreach ($selfpassbook as $result) { ?>
                            <tr>
                              <td><?= $result->loan_id ?></td>
                              <td><?= $result->loanamt ?></td>
                              <td><?= $result->loandate ?></td>
                              <!-- <td><?php if ($result->is_approve==0) 
                              { ?>
                                <span class="badge gradient-bloody text-white shadow">No</span>
                              <?php }if ($result->is_approve==1) 
                              {
                                ?>
                                <span class="badge gradient-quepal text-white shadow">Yes</span>
                                <?php
                              }  ?>
                            </td> -->
                            <td>
                              <?php if ($result->is_approve==0) { ?>
                                <a href="#" class="btn btn-primary waves-effect waves-light" title="Edit" data-toggle="modal" data-target="#editmodal" data-index="<?=$result->loan_id;?>" name="editamt"> <i class="fa fa-edit" ></i></a>
                              <?php }else{ ?>
                                <h6>Approve Loan</h6>
                              <?php } ?>

                              <!-- <a href="" class="btn btn-danger waves-effect waves-light" title="Edit"> <i class="fa fa-trash"></i></a> -->
                            </td>

                          </tr>
                          <?php $i++;} ?>
                        <?php } else { ?>
                          <tr>
                            <td colspan="5">
                              No record found.
                            </td>
                          </tr>

                        <?php } ?> 
                      </tbody>
              <!-- <tfoot>
                <tr>
                  <th>Loan ID</th>
                  <th>Loan Ammount</th>
                  <th>Loan Date</th>
                  <th>View</th>

                </tr>
              </tr><
            </tfoot> -->
          </table>
        </div>
      </div>
      <!-- </div> -->
    </div>
  </div>
</div>
</div><!--End Row-->
</div>
<!-- End container-fluid-->

</div><!--End content-wrapper-->
<!--Start Back To Top Button-->
<a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
<!--End Back To Top Button-->

<!--Start footer-->
	<!-- <footer class="footer">
      <div class="container">
        <div class="text-center">
          Copyright © 2018 Rocker Admin
        </div>
      </div>
    </footer> -->
    <!--End footer-->

  </div><!--End wrapper-->
  
  <!-- Modal -->
  <div class="modal fade" id="editmodal">
    <div class="modal-dialog modal-sm">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title"><i class="fa fa-star"></i> Edit Amount</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <div class="form-group row">
            <label for="input-4" class="col-sm-4 col-form-label">Loan Ammount</label>
            <input type="hidden" name="loan_id" id="loan_id" >
            <input type="number" class="form-control col-sm-8" id="loanamt1" name="loanamt1" required min="10">

          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
          <button type="submit" onclick="update_amt();" class="btn btn-primary"><i class="fa fa-check-square-o"></i> Update</button>
        </div>
      </div>
    </div>
  </div>


  <!-- Bootstrap core JavaScript-->
  <script src="<?php echo base_url();?>assets/js/jquery.min.js"></script>
  <script src="<?php echo base_url();?>assets/js/popper.min.js"></script>
  <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>

  <!-- simplebar js -->
  <script src="<?php echo base_url();?>assets/plugins/simplebar/js/simplebar.js"></script>
  <!-- waves effect js -->
  <script src="<?php echo base_url();?>assets/js/waves.js"></script>
  <!-- sidebar-menu js -->
  <script src="<?php echo base_url();?>assets/js/sidebar-menu.js"></script>
  <!-- Custom scripts -->
  <script src="<?php echo base_url();?>assets/js/app-script.js"></script>

  <!--Form Validatin Script-->
  <script src="<?php echo base_url();?>assets/plugins/jquery-validation/js/jquery.validate.min.js"></script>
  <!--Bootstrap Datepicker Js-->
  <script src="<?php echo base_url();?>assets/plugins/bootstrap-datepicker/js/bootstrap-datepicker.min.js"></script>
  <!--Data Tables js-->
  <script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/jquery.dataTables.min.js"></script>
  <script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/dataTables.bootstrap4.min.js"></script>
  <script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/dataTables.buttons.min.js"></script>
  <script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/buttons.bootstrap4.min.js"></script>
  <script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/jszip.min.js"></script>
  <script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/pdfmake.min.js"></script>
  <script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/vfs_fonts.js"></script>
  <script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/buttons.html5.min.js"></script>
  <script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/buttons.print.min.js"></script>
  <script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/buttons.colVis.min.js"></script>
  <script>
   $(document).ready(function() {
      //Default data table
      $('#default-datatable').DataTable();


      var table = $('#example').DataTable( {
        lengthChange: false,
        buttons: [ '' ]
      } );

      table.buttons().container()
      .appendTo( '#example_wrapper .col-md-6:eq(0)' );
      
    } );

  </script>
  <script>
    $('#default-datepicker').datepicker({
      todayHighlight: true
    });
    $('#autoclose-datepicker').datepicker({
      autoclose: true,
      todayHighlight: true
    });

    $('#inline-datepicker').datepicker({
     todayHighlight: true
   });

    $('#dateragne-picker .input-daterange').datepicker({
    });

  </script>
  <script>

    $().ready(function() {

      $("#loan-info").validate();

   // validate signup form on keyup and submit
   $("#loan-info").validate({
    rules: {
      fname: "required",
      loandate:"required",
      loanamt: {
        required: true,
        minlength: 4,
        maxlength: 6
      }
    },
    messages: {
      fname: "Please enter your Name",
      loandate:"Please enter date",
      loanamt: "Please enter your loan amount properly"

    }
  });

 });

</script>

</body>

<!-- Mirrored from codervent.com/rocker/white-version/form-validation.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 13 Dec 2018 14:15:49 GMT -->
</html>

<script type="text/javascript">

  $("a[name=editamt]").on("click", function () { 
      var loan_id = $(this).data("index"); 
              //alert(loan_id);
              $.ajax({
                url: '<?php echo base_url(); ?>index.php/editloanamt',
                type: 'POST',
                data:  { 'loan_id' : loan_id },
                success: function(response,status,xhr) {
                  //console.info(response);
                  //window.location.href="vendorlist";
                  //alert(response);
                  var a =jQuery.parseJSON(response);
                  if (response) 
                  {
                    
                    $("#loan_id").val(a.loan_id);
                    $("#loanamt1").val(a.loanamt);
                    location.refresh();
                  }
                  else
                  {
                   

                  }

                }
              }); location.refresh();
            });
</script>
<script type="text/javascript">
  function update_amt()
  {
    
    var loan_id = $("#loan_id").val();
    var loan_amt = $("#loanamt1").val();

    //var la = document.getElementById('loanamt').value; 
    //var loan_amt = parseInt(la);
    var lenderamt = loan_amt*20/100;
    var total = +loan_amt + +lenderamt

    //alert(total);
    //alert(loan_amt);
    $.ajax({
                url: '<?php echo base_url();?>index.php/updateloanamt',
                type: 'POST',
                data:  { 'loan_id' : loan_id, 'loan_amt' :loan_amt,'lenderamt' : total },
                success: function(response,status,xhr) {
                  //console.info(response);
                  //window.location.href="vendorlist";
                  // /alert(response);
                  //var a =jQuery.parseJSON(response);
                  location.reload();
                }
              });
  }

  function lendercount()
  {
    //var la = $("#loanamt").val();
    var la = document.getElementById('loanamt').value; 
    //var loan_amt = parseInt(la);
    var lenderamt = la*20/100;
    var total = +la + +lenderamt
    //alert(total);
    $("#lenderamt").val(total);
  }
</script>