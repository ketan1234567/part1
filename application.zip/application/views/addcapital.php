
<!-- Breadcrumb-->
<div class="row pt-2 pb-2">
  <div class="col-sm-9">
    <h4 class="page-title">Unused Capital (<?php if ($totaladdcapitalamt){ 
      echo $totaladdcapitalamt->total_amount;
    }else{
      echo "0";
    } ?>) </h4>
  </div>
  <div class="col-sm-3">
   <div class="btn-group float-sm-right">
    <!-- <button type="button" class="btn btn-outline-primary waves-effect waves-light" data-toggle="modal" data-target="#largesizemodal"><i class="fa fa-user mr-1"></i> Add Capital</button> -->
  </div>
</div>
</div>
<!-- End Breadcrumb-->
<div class="row">
  <div class="col-lg-12">
    <div class="card">
     <!--  <div class="card-header"><i class="fa fa-table"></i> Data Exporting</div> -->
     <div class="card-body">
      <div class="table-responsive">
        <table id="" class="table table-bordered">
          <thead>
            <tr>
              <th>#</th>
              <!-- <th style="font-size: 11px;">Date</th> -->
              <th style="font-size: 11px;">Amount</th>
              <th style="font-size: 11px;">Action</th>
            </tr>
          </thead>
          <tbody>


            <tr>
              <td style="font-size: 11px;">1</td>
                 <!-- <td style="font-size: 11px;"><?php $yrdata= strtotime($addcapital_data->date);
                 echo date('d-M-Y', $yrdata); ?></td> -->
                 <td style="font-size: 11px;"><?= $totaladdcapitalamt->total_amount ?></td>
                 <td style="font-size: 11px;">
                   <!-- <a href="<?php echo base_url();?>index.php/deladdcapital/<?= $addcapital_data->id ?>" class="btn btn-outline-danger btn-sm waves-effect waves-light m-1" title="Delet"><i class="fa fa-trash"></i></a> -->
                   <button type="button" class="btn btn-outline-primary waves-effect waves-light" data-toggle="modal" data-target="#largesizemodal"><i class="fa fa-user mr-1"></i> Add Capital</button>
                 </td>
               </tr>

             </tbody>
           </table>
         </div>
       </div>
     </div>
   </div>
 </div><!-- End Row-->

 <div class="row">
  <div class="col-lg-12">
    <div class="card">
     <!--  <div class="card-header"><i class="fa fa-table"></i> Data Exporting</div> -->
     <div class="card-body">
      <div class="table-responsive">
        <table id="example" class="table table-bordered">
          <thead>
            <tr>
              <th>#</th>
              <th style="font-size: 11px;">Date</th>
              <th style="font-size: 11px;">Amount</th>
              <th style="font-size: 11px;">Action</th>
            </tr>
          </thead>
          <tbody>
            <?php $i=1; if(count($addcapital)): ?>
            <?php foreach ($addcapital as $addcapital_data): ?>
              <tr>
                <td style="font-size: 11px;"><?= $i ?></td>
                <td style="font-size: 11px;"><?php $yrdata= strtotime($addcapital_data->date);
                echo date('d-M-Y', $yrdata); ?></td>
                <td style="font-size: 11px;"><?= $addcapital_data->amount ?></td>
                <td style="font-size: 11px;">
                 <a href="<?php echo base_url();?>index.php/deladdcapital/<?= $addcapital_data->id ?>" class="btn btn-outline-danger btn-sm waves-effect waves-light m-1" title="Delet"><i class="fa fa-trash"></i></a>
               </td>
             </tr>
             <?php $i++;endforeach; ?>
             <?php else: ?>
              <tr>
                <td colspan="9">
                  No record found.
                </td>
              </tr>

            <?php endif; ?> 
            <tr>
              <td><b>Added Capital</b></td>
              <td></td>
              <td><b>
                <?php 
                $sum = 0;
                for ($i=0; $i < count($addcapital) ; $i++) { 
                  $sum = $sum + $addcapital[$i]->amount;
                }
                print_r($sum);
                ?>
              </b></td>
              <td></td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
</div><!-- End Row-->

</div>
<!-- End container-fluid-->

</div><!--End content-wrapper-->
</div><!--End wrapper-->
<!-- Modal -->
<div class="modal fade" id="largesizemodal">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title"><i class="fa fa-star"></i> Add Capital</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <?php echo form_open('index.php/insertaddcapital'); ?>
        
        <div class="form-group row">
          <label for="input-2" class="col-sm-4 col-form-label">Amount</label>
          <div class="col-sm-8">
            <input type="text" class="form-control" pattern="[0-9]+" id="amount" name="amount" required placeholder="Please Enter Valid Amount" title="Number Only" required>
          </div>
        </div>
        <div class="form-group row">
          <label for="input-2" class="col-sm-4 col-form-label">Date</label>
          <div class="col-sm-8">
            <input type="date" class="form-control" id="date" name="date" required  >
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
        <button type="submit" class="btn btn-primary"><i class="fa fa-check-square-o"></i> Add</button>
      </div>
      <?php echo form_close(); ?>
    </div>
  </div>
</div>


<!-- Bootstrap core JavaScript-->
<script src="<?php echo base_url();?>assets/js/jquery.min.js"></script>
<script src="<?php echo base_url();?>assets/js/popper.min.js"></script>
<script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>

<!-- simplebar js -->
<script src="<?php echo base_url();?>assets/plugins/simplebar/js/simplebar.js"></script>
<!-- waves effect js -->
<script src="<?php echo base_url();?>assets/js/waves.js"></script>
<!-- sidebar-menu js -->
<script src="<?php echo base_url();?>assets/js/sidebar-menu.js"></script>
<!-- Custom scripts -->
<script src="<?php echo base_url();?>assets/js/app-script.js"></script>

<!--Data Tables js-->
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/dataTables.bootstrap4.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/dataTables.buttons.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/buttons.bootstrap4.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/jszip.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/pdfmake.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/vfs_fonts.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/buttons.html5.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/buttons.print.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/buttons.colVis.min.js"></script>

<script>
 $(document).ready(function() {
      //Default data table
      $('#default-datatable').DataTable();


      var table = $('#example').DataTable( {
        lengthChange: false,
        buttons: [ 'excel','print', ]
        //buttons: [ 'copy', 'excel', 'pdf', 'print', 'colvis' ]
      } );

      table.buttons().container()
      .appendTo( '#example_wrapper .col-md-6:eq(0)' );
      
    } );

  </script>
  


