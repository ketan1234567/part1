
<div class="row">
  <div class="col-lg-12">
    <div class="card">
      <div class="card-header"><i class="fa fa-table"></i> Customer List </div>
      <div class="card-body">
        <div class="table-responsive">
          <table id="example" class="table table-bordered">
            <thead>
              <tr>
                <th>#</th>
                <th>Customers Name</th>
                <th>Loan ID</th>
                <th>Loan Amount - Remaning   </th>
                <!-- <th>Approve</th> -->
                <th>Action</th>

              </tr>
            </thead>
            <tbody>
             <?php $i=1; if(count($app_cust)){ ?>
               <?php foreach ($app_cust as $result) { ?>
                <tr>
                  <td><?= $i ?></td>
                  <td><?= $result->fname ?> <?= $result->lname ?></td>
                  <td><?= $result->loan_id ?></td>
                  <?php 
                  $subtotal_amt = $this->Regmodel->show_subtotal_data($result->loan_id);
                  $lender_amt = $this->Regmodel->lender_amt($result->loan_id);
                  //echo "<pre>"; print_r($lender_amt);
                  ?>
                  <?php 
                  $encode= $result->loan_id ;
                  $ecode1 = base64_encode($encode);
                  $ecode2= trim($ecode1,'=');
                  ?> 
                  <td><?= $result->loanamt ?> - <span class="badge badge-danger m-1"><?= $lender_amt->lenderamt - $subtotal_amt->pay_loan_amt  ?></span></td>
                  <td>
                    <?php if ($lender_amt->lenderamt - $subtotal_amt->pay_loan_amt != 0): ?>
                      <a href="#" class="btn btn-success waves-effect waves-light" title="Collection" data-toggle="modal" data-target="#paymodal" data-index="<?=$result->loan_id;?>" name="payamt">PAY</a>
                    <?php endif ?>
                    <a href="<?php echo base_url();?>index.php/showpassbook/<?= $ecode2 ?>" class="btn btn-outline-success btn-sm waves-effect waves-light m-1" title="Edit">Passbook</a>
                  </td>

                </tr>
                <?php $i++;} ?>
              <?php } else { ?>
                <tr>
                  <td colspan="5">
                    No record found.
                  </td>
                </tr>

              <?php } ?> 
            </tbody>
              <!-- <tfoot>
                <tr>
                  <th>Loan ID</th>
                  <th>Loan Ammount</th>
                  <th>Loan Date</th>
                  <th>View</th>

                </tr>
              </tr><
            </tfoot> -->
          </table>
        </div>
      </div>
    </div>
  </div>
</div><!-- End Row-->

</div>
<!-- End container-fluid-->

</div><!--End content-wrapper-->
<!--Start Back To Top Button-->
<a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
<!--End Back To Top Button-->

<!--Start footer-->
	<!-- <footer class="footer">
      <div class="container">
        <div class="text-center">
          Copyright © 2018 Rocker Admin
        </div>
      </div>
    </footer> -->
    <!--End footer-->

  </div><!--End wrapper-->
  <!-- Modal -->
  <div class="modal fade" id="paymodal">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title"><i class="fa fa-star"></i> Collect Money</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <label>Loan ID</label>
          <input type="text" class="form-control col-sm-12" id="loan_id" name="loan_id" readonly="readonly">
          <input type="hidden" id="collector_id" name="collector_id" value="<?= $this->session->userdata('id');  ?>">
          <label>Loan Amount</label>
          <input type="text" class="form-control col-sm-12" id="loanamt" name="loanamt" readonly="readonly">
          <label>Pay Amount</label>
          <input type="number" class="form-control col-sm-12" id="pay_loan_amt1" name="pay_loan_amt" placeholder="Amount" onchange="showhide()" required="required"  >
          <label>Loan Date</label>
          <input type="date" id="loandate" name="loandate" class="form-control col-sm-12" required="required" > 
          <!-- <input type="text" name="loandate" id="autoclose-datepicker" class="form-control" required> -->
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
          <div id="show_hide">
            <button type="button" onclick="pay_amt()" class="btn btn-primary"><i class="fa fa-check-square-o"></i> Save</button>
          </div>
          
        </div>
      </div>
    </div>
  </div>


  <!-- Bootstrap core JavaScript-->
  <script src="<?php echo base_url();?>assets/js/jquery.min.js"></script>
  <script src="<?php echo base_url();?>assets/js/popper.min.js"></script>
  <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>

  <!-- simplebar js -->
  <script src="<?php echo base_url();?>assets/plugins/simplebar/js/simplebar.js"></script>
  <!-- waves effect js -->
  <script src="<?php echo base_url();?>assets/js/waves.js"></script>
  <!-- sidebar-menu js -->
  <script src="<?php echo base_url();?>assets/js/sidebar-menu.js"></script>
  <!-- Custom scripts -->
  <script src="<?php echo base_url();?>assets/js/app-script.js"></script>
  <!--Bootstrap Datepicker Js-->
  <script src="<?php echo base_url();?>assets/plugins/bootstrap-datepicker/js/bootstrap-datepicker.min.js"></script>


  <!--Data Tables js-->
  <script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/jquery.dataTables.min.js"></script>
  <script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/dataTables.bootstrap4.min.js"></script>
  <script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/dataTables.buttons.min.js"></script>
  <script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/buttons.bootstrap4.min.js"></script>
  <script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/jszip.min.js"></script>
  <script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/pdfmake.min.js"></script>
  <script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/vfs_fonts.js"></script>
  <script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/buttons.html5.min.js"></script>
  <script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/buttons.print.min.js"></script>
  <script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/buttons.colVis.min.js"></script>

  <script>
   $(document).ready(function() {
      //Default data table
      $('#default-datatable').DataTable();


      var table = $('#example').DataTable( {
        lengthChange: false,
        buttons: [ 'excel','colvis' ]
      } );

      table.buttons().container()
      .appendTo( '#example_wrapper .col-md-6:eq(0)' );
      
    } );

  </script>
  <script>
    $('#default-datepicker').datepicker({
      todayHighlight: true
    });
    $('#autoclose-datepicker').datepicker({
      autoclose: true,
      todayHighlight: true
    });

    $('#inline-datepicker').datepicker({
     todayHighlight: true
   });

    $('#dateragne-picker .input-daterange').datepicker({
    });

  </script>
  <script type="text/javascript">

    $("a[name=payamt]").on("click", function () { 
      var loan_id = $(this).data("index"); 
              //alert(loan_id);
              $.ajax({
                url: '<?php echo base_url(); ?>index.php/editloanamt',
                type: 'POST',
                data:  { 'loan_id' : loan_id },
                success: function(response,status,xhr) {
                  //console.info(response);
                  //window.location.href="vendorlist";
                  //alert(response);
                  var a =jQuery.parseJSON(response);
                  var min_amt = a.loanamt*1/100;

                  //alert(min_amt);
                  if (response) 
                  {
                    $("#loan_id").val(a.loan_id);
                    $("#loanamt").val(a.loanamt);
                    $("#pay_loan_amt1").val(min_amt);
                    location.refresh();
                  }
                  else
                  {


                  }

                }
              }); location.refresh();
            });
          </script>
          <script type="text/javascript">
            function pay_amt()
            {
    //alert('hi');
    var loan_id = $("#loan_id").val();
    var collector_id = $("#collector_id").val(); 
    var loanamt = $("#loanamt").val();
    var pay_loan_amt = $("#pay_loan_amt1").val();
    var loandate = $("#loandate").val();
    //var loandate = $("#autoclose-datepicker").val();
    //alert(loandate);
    var inpObj = document.getElementById("pay_loan_amt1");
    var inpObj1 = document.getElementById("loandate");
    //alert(inpObj);
    /*if (!loandate.checkValidity()) {
      alert('Please Select Date');
    }*/
    if (!inpObj.checkValidity()) {
      alert('Please Enter Amount');
    }
    else if (!inpObj1.checkValidity()) {
      alert('Please Enter date');
    } 

    else {
      $.ajax({
        url: '<?php echo base_url();?>index.php/collectloanamt',
        type: 'POST',
        data:  { 'loan_id' : loan_id, 'collector_id':collector_id, 'loanamt' :loanamt,'pay_loan_amt':pay_loan_amt,'loandate':loandate },
        success: function(response,status,xhr) {
                  //console.info(response);
                  //window.location.href="vendorlist";
                  //alert(response);
                  //var a =jQuery.parseJSON(response);
                  location.reload();
                }
              });
    } 
    

  }

  
</script>
<script type="text/javascript">
  
function showhide()
{
  var given_amt = $("#pay_loan_amt1").val();
  var min_amt = $("#loanamt").val()*1/100;
  /*alert(given_amt);
  alert(min_amt);*/
  if(min_amt == given_amt) {
    $('#show_hide').show();
    
  } else if(min_amt <= given_amt) {
    $('#show_hide').show();
    
  }else{
    $('#show_hide').hide();
  }
}

</script>

</body>


</html>
