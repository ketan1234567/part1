
<div class="card">
  <div class="card-body">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h3>
        Loan ID
        <small># <?= $loan_data->loan_id ?></span></small>
      </h3>
      <h5>
        Loan Amount
        <small>#<span class="badge badge-warning m-1"><?= $loan_data->loanamt ?></span></small>
      </h5>
      <h5>
        Lender Amount
        <small>#<span class="badge badge-success m-1"><?= $loan_data->lenderamt ?></span></small>
      </h5>
      <h5>
        Remaining Amount
        <small ># <span class="badge badge-danger m-1"><?= $loan_data->lenderamt - $subtotal_amt->pay_loan_amt  ?></span></small>
      </h5>
    </section>

    <!-- Main content -->
    <section class="invoice">
      <!-- title row -->
      <div class="row mt-3">
        <div class="col-lg-6">
          <h5><i class="fa fa-globe"></i> Pass Book</h5>  
        </div>
        <div class="col-lg-6">
          <!--<h5 class="float-sm-right">Date: <?= $loan_data->loandate ?></h5>-->
           <h5 class="float-sm-right">Date: <?php $yrdata= strtotime($loan_data->loandate);
                          echo date('d-M-Y', $yrdata); ?></h5>
        </div>
      </div>

      <hr>

      <!-- Table row -->
      <div class="row">
        <div class="col-12 table-responsive">
          <table class="table table-striped">
            <thead>
              <tr>
                <th>#</th>
                <th>Date</th>
                <th>Collector ID & Name</th>
                <th>Pay Amount</th>
                <!-- <th>Subtotal</th> -->
              </tr>
            </thead>
            <tbody>
              <?php $j=1;  $sum = 0; if(count($pass_entry)){ ?>
               <?php foreach ($pass_entry as $result) { ?>
                <tr>
                  <td><?= $j ?></td>
                  <!--<td><?= $result->loandate ?></td>-->
                  <td><?php $yrdata= strtotime($result->loandate);
                          echo date('d-M-Y', $yrdata); ?></td>
                  <td><?= $result->collector_id ?> -
                    <?php
                    $ct = count($collector_data);
                    for ($i=0; $i < $ct; $i++) { 
                      if ($result->collector_id==$collector_data[$i]->id) {
                        // /print_r($collector_data[$i]->fname); print_r($collector_data[$i]->fname);
                        echo $collector_data[$i]->fname; echo " "; echo $collector_data[$i]->lname ;
                      }
                    }
                    ?></td>
                    <td><?= $result->pay_loan_amt ?></td>
                  </tr>
                  <?php $j++;} ?>
                <?php } else { ?>
                  <tr>
                    <td colspan="4">
                      No record found.
                    </td>
                  </tr>

                <?php } ?> 
              </tbody>
            </table>
          </div><!-- /.col -->
        </div><!-- /.row -->

        <div class="row">
          <!-- accepted payments column -->
          <div class="col-lg-6 payment-icons">
          </div><!-- /.col -->
          <div class="col-lg-6">
            <!-- <p class="lead">Amount Due 2/22/2014</p> -->
            <div class="table-responsive">
              <table class="table">
                <tbody>
                 <tr>
                  <th style="width:50%">Subtotal:</th>
                  <td><span class="badge badge-success m-1"><?= $subtotal_amt->pay_loan_amt ?></span></td>
                </tr>
                <tr>
                  <th>Total Remaning:</th>
                  <td><span class="badge badge-danger m-1"><?= $loan_data->lenderamt - $subtotal_amt->pay_loan_amt  ?>
                    <?php if ($loan_data->lenderamt - $subtotal_amt->pay_loan_amt <= 0) {
                      $this->Regmodel->update_loan_status($loan_data->loan_id);
                    } ?>
                  </span></td>
                </tr>
              </tbody>
            </table>
          </div>
        </div><!-- /.col -->
      </div><!-- /.row -->

      <!-- this row will not appear when printing -->
      <hr>
      <div class="row no-print">
        <div class="col-lg-3">
          <a href="javascript:window.print();" target="_blank" class="btn btn-outline-secondary m-1"><i class="fa fa-print"></i> Print</a>
        </div>
        <div class="col-lg-9">
          <div class="float-sm-right">
        <!--  <button class="btn btn-success m-1"><i class="fa fa-credit-card"></i> Submit Payment</button>
         <button class="btn btn-primary m-1"><i class="fa fa-download"></i> Generate PDF</button> -->
       </div>
     </div>
   </div>
 </section><!-- /.content -->
</div>
</div>

</div>
<!-- End container-fluid-->

</div><!--End content-wrapper-->
<!--Start Back To Top Button-->
<a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
<!--End Back To Top Button-->

<!--Start footer-->
<!-- <footer class="footer">
  <div class="container">
    <div class="text-center">
      Copyright © 2018 Rocker Admin
    </div>
  </div>
</footer> -->
<!--End footer-->

</div><!--End wrapper-->


<!-- Bootstrap core JavaScript-->
<script src="<?php echo base_url();?>assets/js/jquery.min.js"></script>
<script src="<?php echo base_url();?>assets/js/popper.min.js"></script>
<script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>

<!-- simplebar js -->
<script src="<?php echo base_url();?>assets/plugins/simplebar/js/simplebar.js"></script>
<!-- waves effect js -->
<script src="<?php echo base_url();?>assets/js/waves.js"></script>
<!-- sidebar-menu js -->
<script src="<?php echo base_url();?>assets/js/sidebar-menu.js"></script>
<!-- Custom scripts -->
<script src="<?php echo base_url();?>assets/js/app-script.js"></script>

</body>

<!-- Mirrored from codervent.com/rocker/white-version/pages-invoice.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 13 Dec 2018 14:18:54 GMT -->
</html>
