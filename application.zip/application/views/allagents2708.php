
<div class="row">
  <div class="col-lg-12">
    <div class="card">
      <div class="card-header"><i class="fa fa-table"></i> All Agents </div>
      <div class="card-body">
        <div class="table-responsive">
          <table id="example" class="table table-bordered">
            <thead>
              <tr>
                <th>#</th>
                <th>Agents List</th>
                <th>Status</th>
                <th>Action</th>
                
              </tr>
            </thead>
            <tbody>
             <?php $i=1; if(count($allagents)){ ?>
               <?php foreach ($allagents as $result) { ?>
                <tr>
                  <td><?= $i ?></td>
                  <td><?= $result->fname ?> <?= $result->lname ?></td>
                  <td>
                    <?php if ($result->is_active==1) { ?>
                      <span class="badge badge-success m-1">Active</span>
                    <?php }elseif($result->is_active==0){ ?>
                     <span class="badge badge-danger m-1">Deactive</span>
                   <?php } ?>
                 </td>
                 <?php 
                        $encode= $result->id ;
                        $encode1 = base64_encode($encode);
                        $encode2= trim($encode1,'=');
                    ?> 
                 <td>
                  <?php if ($result->is_active==0) { ?>
                    <a href="" class="btn btn-outline-warning btn-sm waves-effect waves-light m-1" title="change status" data-index="<?=$result->id;?>" name="changestatus">Active / Inactive</a>
                  <?php }elseif($result->is_active==1){ ?>
                    <a href="" class="btn btn-outline-warning btn-sm waves-effect waves-light m-1" title="change status" data-index="<?=$result->id;?>" name="changestatus1">Active/Inactive</a>
                  <?php } ?>
                  <!-- <a href="" class="btn btn-outline-warning btn-sm waves-effect waves-light m-1" title="User Details" data-index="<?=$result->id;?>" name="user_details" data-toggle="modal" data-target="#agentsdetails">Details</a>
                  <a href="" class="btn btn-outline-warning btn-sm waves-effect waves-light m-1" title="User Details" data-index="<?=$result->id;?>" name="loan_details" data-toggle="modal" data-target="#loandetails">Loan Details</a> -->
                  <a href="<?php echo base_url();?>index.php/custdetails/<?= $encode2 ?>" class="btn btn-outline-warning btn-sm waves-effect waves-light m-1" title="User Details" data-index="<?=$result->id;?>" name="custdetails" >Cust Details</a>
                  <a href="" class="btn btn-outline-info btn-sm waves-effect waves-light m-1" title="Reset Password" data-index="<?=$result->id;?>" name="reset_pass" data-toggle="modal" data-target="#resetpass" >Reset Password</a>
                </td>

              </tr>
              <?php $i++;} ?>
            <?php } else { ?>
              <tr>
                <td colspan="4">
                  No record found.
                </td>
              </tr>

            <?php } ?> 
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
</div><!-- End Row-->

</div>
<!-- End container-fluid-->

</div><!--End content-wrapper-->
<!--Start Back To Top Button-->
<a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
<!--End Back To Top Button-->
<!-- resetpass Modal -->
<div class="modal fade" id="resetpass">
<div class="modal-dialog">
<div class="modal-content">
<div class="modal-header">
<h5 class="modal-title"><i class="fa fa-star"></i> Reset Password </h5>
<button type="button" class="close" data-dismiss="modal" aria-label="Close">
<span aria-hidden="true">&times;</span>
</button>
</div>
<div class="modal-body">
<?php echo form_open('index.php/resetpass'); ?>
<div class="form-group row">
<input type="hidden" name="agents_id" id="agents_id" class="form-control">
<label for="input-4" class="col-sm-4 col-form-label">Reset Password</label>
<div class="col-sm-8">
<input type="text" name="reset_pass" id="reset_pass" class="form-control" required>
</div>
</div>

</div>
<div class="modal-footer">
<button type="button" class="btn btn-secondary" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
<button type="submit" class="btn btn-primary"><i class="fa fa-check-square-o"></i> Update</button>
</div>
<?php echo form_close(); ?>
</div>
</div>
</div>
<!--Start footer-->
	<!-- <footer class="footer">
      <div class="container">
        <div class="text-center">
          Copyright © 2018 Rocker Admin
        </div>
      </div>
    </footer> -->
    <!--End footer-->

  </div><!--End wrapper-->


  <!-- Bootstrap core JavaScript-->
  <script src="<?php echo base_url();?>assets/js/jquery.min.js"></script>
  <script src="<?php echo base_url();?>assets/js/popper.min.js"></script>
  <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>

  <!-- simplebar js -->
  <script src="<?php echo base_url();?>assets/plugins/simplebar/js/simplebar.js"></script>
  <!-- waves effect js -->
  <script src="<?php echo base_url();?>assets/js/waves.js"></script>
  <!-- sidebar-menu js -->
  <script src="<?php echo base_url();?>assets/js/sidebar-menu.js"></script>
  <!-- Custom scripts -->
  <script src="<?php echo base_url();?>assets/js/app-script.js"></script>

  <!--Data Tables js-->
  <script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/jquery.dataTables.min.js"></script>
  <script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/dataTables.bootstrap4.min.js"></script>
  <script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/dataTables.buttons.min.js"></script>
  <script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/buttons.bootstrap4.min.js"></script>
  <script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/jszip.min.js"></script>
  <script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/pdfmake.min.js"></script>
  <script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/vfs_fonts.js"></script>
  <script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/buttons.html5.min.js"></script>
  <script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/buttons.print.min.js"></script>
  <script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/buttons.colVis.min.js"></script>

  <script>
   $(document).ready(function() {
      //Default data table
      $('#default-datatable').DataTable();


      var table = $('#example').DataTable( {
        lengthChange: false,
        buttons: [ 'excel','colvis' ]
      } );

      table.buttons().container()
      .appendTo( '#example_wrapper .col-md-6:eq(0)' );
      
    } );

  </script>
  <script type="text/javascript">

    $("a[name=changestatus]").on("click", function () { 
      var id = $(this).data("index"); 
              //alert(id);
              $.ajax({
                url: '<?php echo base_url(); ?>index.php/changestatus',
                type: 'POST',
                data:  { 'id' : id, 'val': 1 },
                success: function(response,status,xhr) {
                  //console.info(response);
                  //window.location.href="vendorlist";
                  //alert(response);
                  location.relode();

                }
              }); 
            });
    $("a[name=changestatus1]").on("click", function () { 
      var id = $(this).data("index"); 
              //alert(id);
              $.ajax({
                url: '<?php echo base_url(); ?>index.php/changestatus',
                type: 'POST',
                data:  { 'id' : id, 'val': 0 },
                success: function(response,status,xhr) {
                  //console.info(response);
                  //window.location.href="vendorlist";
                  //alert(response);
                  location.relode();

                }
              }); 
            });

    $("a[name=user_details]").on("click", function () { 
      var id = $(this).data("index"); 

      $.ajax({
        url: '<?php echo base_url(); ?>index.php/agentdetails',
        type: 'POST',
        data:  { 'id' : id },
        success: function(response,status,xhr) {
                  //alert(response);
                  var a =jQuery.parseJSON(response);

                  if (response) 
                  {
                    $("#agent_fname").text(a.fname);
                    $("#agent_lname").text(a.lname);
                    $("#contact").text(a.contact);
                    $("#address").text(a.address);
                    $("#state").text(a.state);
                    $("#gender").text(a.gender);
                    $("#emailid").text(a.email);
                    location.refresh();
                  }
                  else
                  {


                  }

                }
              }); 
    });
    
     $("a[name=reset_pass]").on("click", function () { 
      var id = $(this).data("index"); 
      $("#agents_id").val(id);
      
    });

   
  </script>

</body>

<!-- Mirrored from codervent.com/rocker/white-version/table-data-tables.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 13 Dec 2018 14:16:37 GMT -->
</html>
