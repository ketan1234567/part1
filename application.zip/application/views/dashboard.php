<?php 
$loandate = array('');
$amount = array('');
$month = array();
$amount_monthwise= array();
for ($i=count($grp_by_date)-1; $i >= 0 ; $i--) { 
  $loandate[] .= $grp_by_date[$i]['loandate'];
  $amount[] .= $grp_by_date[$i]['amount'];
}

//echo "<pre>"; print_r($grp_by_month); exit();
for ($j=0; $j < count($grp_by_month) ; $j++) { 
  //  $month[] .= $grp_by_month[$j]['month'];
  // $amount_monthwise[] .= $grp_by_month[$j]['tot_amt'];
  if ($grp_by_month[$j]['month']=='1') 
  {
    $month[] .= 'Jan'.$grp_by_month[$j]['year'];
    $amount_monthwise[] .= $grp_by_month[$j]['tot_amt'];
    
  }
  if ($grp_by_month[$j]['month']=='2') 
  {
   $month[] .= 'Feb'.$grp_by_month[$j]['year'];
   $amount_monthwise[] .= $grp_by_month[$j]['tot_amt'];
 }
 if ($grp_by_month[$j]['month']=='3') 
 {
   $month[] .= 'Mar'.$grp_by_month[$j]['year'];
   $amount_monthwise[] .= $grp_by_month[$j]['tot_amt'];
 }
 if ($grp_by_month[$j]['month']=='4') 
 {
   $month[] .= 'Apr'.$grp_by_month[$j]['year'];
   $amount_monthwise[] .= $grp_by_month[$j]['tot_amt'];
 }
 if ($grp_by_month[$j]['month']=='5') 
 {
   $month[] .= 'May'.$grp_by_month[$j]['year'];
   $amount_monthwise[] .= $grp_by_month[$j]['tot_amt'];
 }
 if ($grp_by_month[$j]['month']=='6') 
 {
   $month[] .= 'Jun'.$grp_by_month[$j]['year'];
   $amount_monthwise[] .= $grp_by_month[$j]['tot_amt'];
 }
 if ($grp_by_month[$j]['month']=='7') 
 {
   $month[] .= 'Jul'.$grp_by_month[$j]['year'];
   $amount_monthwise[] .= $grp_by_month[$j]['tot_amt'];
 }
 if ($grp_by_month[$j]['month']=='8') 
 {
  $month[] .= 'Aug'.$grp_by_month[$j]['year'];
  $amount_monthwise[] .= $grp_by_month[$j]['tot_amt'];
}
if ($grp_by_month[$j]['month']=='9') 
{
 $month[] .= 'Sep'.$grp_by_month[$j]['year'];
 $amount_monthwise[] .= $grp_by_month[$j]['tot_amt'];
}
if ($grp_by_month[$j]['month']=='10') 
{
 $month[] .= 'Oct'.$grp_by_month[$j]['year'];
 $amount_monthwise[] .= $grp_by_month[$j]['tot_amt'];
}
if ($grp_by_month[$j]['month']=='11') 
{
 $month[] .= 'Nov'.$grp_by_month[$j]['year'];
 $amount_monthwise[] .= $grp_by_month[$j]['tot_amt'];
}
if ($grp_by_month[$j]['month']=='12') 
{
 $month[] .= 'Dec'.$grp_by_month[$j]['year'];
 $amount_monthwise[] .= $grp_by_month[$j]['tot_amt'];
}
}


//echo "<pre>"; print_r($month);print_r($amount_monthwise); exit();



?>
<?php    

/*function get_client_ip()
{
    $ipaddress = '';
    if (isset($_SERVER['HTTP_CLIENT_IP'])) {
        $ipaddress = $_SERVER['HTTP_CLIENT_IP'];
    } else if (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
    } else if (isset($_SERVER['HTTP_X_FORWARDED'])) {
        $ipaddress = $_SERVER['HTTP_X_FORWARDED'];
    } else if (isset($_SERVER['HTTP_FORWARDED_FOR'])) {
        $ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
    } else if (isset($_SERVER['HTTP_FORWARDED'])) {
        $ipaddress = $_SERVER['HTTP_FORWARDED'];
    } else if (isset($_SERVER['REMOTE_ADDR'])) {
        $ipaddress = $_SERVER['REMOTE_ADDR'];
    } else {
        $ipaddress = 'UNKNOWN';
    }

    return $ipaddress;
}
//$PublicIP = get_client_ip();
$PublicIP = '182.73.64.55';
$json     = file_get_contents("http://ipinfo.io/$PublicIP/geo");
$json     = json_decode($json, true);
// $country  = $json['country'];
// $region   = $json['region'];
// $city     = $json['city'];
echo "<pre>"; print_r($json);*/
?>
<div class="row mt-3">
  <!-- For Admin --> 
  <?php if ($this->session->userdata('type')==1) { ?> 
    <div class="col-12 col-lg-6 col-xl-4">
      <div class="card border-info border-left-sm">
        <div class="card-body">
          <div class="media">
            <div class="media-body text-left">
              <h4 class="text-info"><?= $total_given_loan->loanamt ?></h4>
              <span>Total Loan</span>
            </div>
            <div class="align-self-center w-circle-icon rounded-circle gradient-scooter">
              <i class="fa fa-inr text-white"></i></div>
            </div>
          </div>
        </div>
      </div>
      <div class="col-12 col-lg-6 col-xl-4">
        <div class="card border-info border-left-sm">
          <div class="card-body">
            <div class="media">
              <div class="media-body text-left">
                <h4 class="text-info"><?= $total_receive_loan->pay_loan_amt ?></h4>
                <span>Total Collection </span>
              </div>
              <div class="align-self-center w-circle-icon rounded-circle gradient-scooter">
                <i class="fa fa-inr text-white"></i></div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-12 col-lg-6 col-xl-4">
          <div class="card border-info border-left-sm">
            <div class="card-body">
              <div class="media">
                <div class="media-body text-left">
                  <h4 class="text-info"><?= $lender_all_collection->lenderamt-$total_given_loan->loanamt ?></h4>
                  <span>Interest</span>
                </div>
                <div class="align-self-center w-circle-icon rounded-circle gradient-scooter">
                  <i class="fa fa-inr text-white"></i></div>
                </div>
              </div>
            </div>
          </div>
        <!-- <div class="col-12 col-lg-6 col-xl-4">
        <div class="card border-info border-left-sm">
          <div class="card-body">
            <div class="media">
              <div class="media-body text-left">
                <h4 class="text-info"><?= $lender_all_collection->lenderamt ?></h4>
                <span>Lender Loan</span>
              </div>
              <div class="align-self-center w-circle-icon rounded-circle gradient-scooter">
                <i class="fa fa-inr text-white"></i></div>
              </div>
            </div>
          </div>
        </div> -->
        <!-- <div class="col-12 col-lg-6 col-xl-4">
            <div class="card border-warning border-left-sm">
              <div class="card-body">
                <div class="media">
                  <div class="media-body text-left">
                    <h4 class="text-warning"><?= $remaining_collection ?></h4>
                    <span>Remaining</span>
                  </div>
                  <div class="align-self-center w-circle-icon rounded-circle gradient-blooker">
                    <i class="fa fa-inr text-white"></i></div>
                  </div>
                </div>
              </div>
            </div>  -->
            <div class="col-12 col-lg-6 col-xl-4">
              <div class="card border-warning border-left-sm">
                <div class="card-body">
                  <div class="media">
                    <div class="media-body text-left">
                      <h4 class="text-warning"><?= $remaining_collection   ?></h4>
                      <span>Cash In Market</span>
                    </div>
                    <div class="align-self-center w-circle-icon rounded-circle gradient-blooker">
                      <i class="fa fa-inr text-white"></i></div>
                    </div>
                  </div>
                </div>
              </div> 
              <div class="col-12 col-lg-6 col-xl-4">
                <div class="card border-warning border-left-sm">
                  <div class="card-body">
                    <div class="media">
                      <div class="media-body text-left">
                        <h4 class="text-warning"><?= $capital->capital_amt + $capital_exp->amount   ?></h4>
                        <span>Total Capital</span>
                      </div>
                      <div class="align-self-center w-circle-icon rounded-circle gradient-blooker">
                        <i class="fa fa-inr text-white"></i></div>
                      </div>
                    </div>
                  </div>
                </div> 
                <div class="col-12 col-lg-6 col-xl-4">
                  <div class="card border-warning border-left-sm">
                    <div class="card-body">
                      <div class="media">
                        <div class="media-body text-left">
                          <h4 class="text-warning"><?php if ($total_unusedaddcapital->amount){ 
                            echo $total_unusedaddcapital->amount;
                          }else{
                            echo "0";
                          } ?></h4>
                          <span>Total Unused Capital</span>
                        </div>
                        <div class="align-self-center w-circle-icon rounded-circle gradient-blooker">
                          <i class="fa fa-inr text-white"></i></div>
                        </div>
                      </div>
                    </div>
                  </div> 
                  <div class="col-12 col-lg-6 col-xl-4">
                    <div class="card border-warning border-left-sm">
                      <div class="card-body">
                        <div class="media">
                          <div class="media-body text-left">
                            <h4 class="text-warning"><?php if ($addcapital->total_amount){ 
                              echo $addcapital->total_amount;
                            }else{
                              echo "0";
                            } ?></h4>
                            <span>Unused Capital</span>
                          </div>
                          <div class="align-self-center w-circle-icon rounded-circle gradient-blooker">
                            <i class="fa fa-inr text-white"></i></div>
                          </div>
                        </div>
                      </div>
                    </div> 
                    <div class="col-12 col-lg-6 col-xl-4">
                      <div class="card border-warning border-left-sm">
                        <div class="card-body">
                          <div class="media">
                            <div class="media-body text-left">
                              <h4 class="text-warning"><?php if (!empty($re_invest->reinvest_amt)) {
                                echo $re_invest->reinvest_amt;
                              }else{
                                echo "0";
                              }    ?></h4>
                              <span>Re-Invest</span>
                            </div>
                            <div class="align-self-center w-circle-icon rounded-circle gradient-blooker">
                              <i class="fa fa-inr text-white"></i></div>
                            </div>
                          </div>
                        </div>
                      </div> 
                      <div class="col-12 col-lg-6 col-xl-4">
                        <div class="card border-warning border-left-sm">
                          <div class="card-body">
                            <div class="media">
                              <div class="media-body text-left">
                                <h4 class="text-warning"><?php if (!empty($expenses->amount)) {
                                  echo $expenses->amount;
                                }else{
                                  echo "0";
                                }    ?></h4>
                                <span>Expenses</span>
                              </div>
                              <div class="align-self-center w-circle-icon rounded-circle gradient-blooker">
                                <i class="fa fa-inr text-white"></i></div>
                              </div>
                            </div>
                          </div>
                        </div> 
                        <div class="col-12 col-lg-6 col-xl-4">
                          <div class="card border-danger border-left-sm">
                            <div class="card-body">
                              <div class="media">
                               <div class="media-body text-left">
                                <h4 class="text-danger"> <?= $cashinbank->cashinbank ?></h4>
                                <span>Cash In bank</span>
                              </div>
                              <div class="align-self-center w-circle-icon rounded-circle gradient-bloody">
                                <i class="fa fa-bar-chart text-white"></i></div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div class="col-12 col-lg-6 col-xl-4">
                          <div class="card border-danger border-left-sm">
                            <div class="card-body">
                              <div class="media">
                               <div class="media-body text-left">
                                <h4 class="text-danger"> <?= $lender_all_collection->lenderamt-$total_given_loan->loanamt - $expenses->amount  ?></h4>
                                <span>Profit And Loss</span>
                              </div>
                              <div class="align-self-center w-circle-icon rounded-circle gradient-bloody">
                                <i class="fa fa-bar-chart text-white"></i></div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div class="col-12 col-lg-6 col-xl-4">
                          <div class="card border-danger border-left-sm">
                            <div class="card-body">
                              <div class="media">
                               <div class="media-body text-left">
                                <h4 class="text-danger"> <?= $total_active_loan ?></h4>
                                <span>Active Loan</span>
                              </div>
                              <div class="align-self-center w-circle-icon rounded-circle gradient-bloody">
                                <i class="fa fa-bar-chart text-white"></i></div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div class="col-12 col-lg-6 col-xl-4">
                          <div class="card border-success border-left-sm">
                            <div class="card-body">
                              <div class="media">
                                <div class="media-body text-left">
                                  <h4 class="text-success"><?= $total_closed_loan?></h4>
                                  <span>Closed Loan</span>
                                </div>
                                <div class="align-self-center w-circle-icon rounded-circle gradient-quepal">
                                  <i class="fa fa-bar-chart text-white"></i></div>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div class="col-12 col-lg-6 col-xl-4">
                            <div class="card border-success border-left-sm">
                              <div class="card-body">
                                <div class="media">
                                  <div class="media-body text-left">
                                    <h4 class="text-success"><?php $yrdata= strtotime($projected_date->project_2);
                                    echo date('d-M-Y', $yrdata); ?></h4>

                                    <span>Projected Date</span>
                                  </div>
                                  <div class="align-self-center w-circle-icon rounded-circle gradient-quepal">
                                    <i class="fa fa-bar-chart text-white"></i></div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div class="col-12 col-lg-6 col-xl-4">
                              <div class="card border-success border-left-sm">
                                <div class="card-body">
                                  <div class="media">
                                    <div class="media-body text-left">
                                      <h4 class="text-success"><?php if (!empty($fines->amount)) {
                                        echo $fines->amount;
                                      }else{
                                        echo "0";
                                      }    ?></h4>

                                      <span>Total Fines</span>
                                    </div>
                                    <div class="align-self-center w-circle-icon rounded-circle gradient-quepal">
                                      <i class="fa fa-bar-chart text-white"></i></div>
                                    </div>
                                  </div>
                                </div>
                              </div>

                              <div class="col-12 col-lg-6 col-xl-4">
                                <div class="card border-danger border-left-sm">
                                  <div class="card-body">
                                    <div class="media">
                                     <div class="media-body text-left">
                                      <h4 class="text-danger"> <?= $cashinbank->cashinbank + $fines->amount ?></h4>
                                      <span>Cash In bank + Fines</span>
                                    </div>
                                    <div class="align-self-center w-circle-icon rounded-circle gradient-bloody">
                                      <i class="fa fa-bar-chart text-white"></i></div>
                                    </div>
                                  </div>
                                </div>
                              </div>

                              <div class="col-12 col-lg-12 col-xl-12">
                                <div class="card border-success border-left-sm">
                                  <div class="card-body">
                                    <div class="media">
                                      <div class="media-body ">
                                        <div class="row" >
                                  <!-- <div class="col-4 col-lg-4 col-xl-3">
                                    <h4 class="text-warning"><?= $current_month_avg->month_avg ; ?></h4>

                                    <span>Current Month Average</span>
                                  </div> -->
                                  <div class="col-3 col-lg-3 col-xl-3">
                                    <h4 class="text-danger"><?php if ($current_month_avg->month_avg != 0) {
                                      $cash_in_bank = $total_receive_loan->pay_loan_amt - $re_invest->reinvest_amt - $expenses->amount;
                                      $test = (20000 - $cashinbank->cashinbank ) / $current_month_avg->month_avg; 
                                      $test1 = round($test);
                                      $curr_date = date('Y-m-d');
                                      $f_value = date('Y-m-d', strtotime($curr_date.'+'. $test1.'days'));
                                      $yrdata= strtotime($f_value);
                                      echo date('d-M-Y', $yrdata);
                                    }else{
                                      echo "No record ";
                                    }  ?></h4>
                                    
                                    <span>20000</span>
                                  </div>
                                  <div class="col-3 col-lg-3 col-xl-3">
                                    <h4 class="text-danger"><?php if ($current_month_avg->month_avg != 0) {
                                      $cash_in_bank = $total_receive_loan->pay_loan_amt - $re_invest->reinvest_amt - $expenses->amount; $test = (30000 - $cashinbank->cashinbank ) / $current_month_avg->month_avg; $test1 = round($test); $curr_date = date('Y-m-d'); $f_value = date('Y-m-d', strtotime($curr_date.'+'. $test1.'days')); $yrdata= strtotime($f_value);
                                      echo date('d-M-Y', $yrdata);
                                    }else{
                                      echo "No record ";
                                    } 
                                    ?></h4>
                                    
                                    <span>30000</span>
                                  </div>
                                  <div class="col-3 col-lg-3 col-xl-3">
                                    <h4 class="text-danger"><?php if ($current_month_avg->month_avg != 0) {
                                      $cash_in_bank = $total_receive_loan->pay_loan_amt - $re_invest->reinvest_amt - $expenses->amount; $test = (50000 - $cashinbank->cashinbank ) / $current_month_avg->month_avg; $test1 = round($test); $curr_date = date('Y-m-d'); $f_value = date('Y-m-d', strtotime($curr_date.'+'. $test1.'days')); $yrdata= strtotime($f_value);
                                      echo date('d-M-Y', $yrdata);
                                    }else{
                                      echo "No record ";
                                    }   ?></h4>
                                    
                                    <span>50000</span>
                                  </div>
                                  <div class="col-3 col-lg-3 col-xl-3">
                                    <h4 class="text-danger"><?php if ($current_month_avg->month_avg != 0) {
                                      $cash_in_bank = $total_receive_loan->pay_loan_amt - $re_invest->reinvest_amt - $expenses->amount; $test = (100000 - $cashinbank->cashinbank ) / $current_month_avg->month_avg; $test1 = round($test); $curr_date = date('Y-m-d'); $f_value = date('Y-m-d', strtotime($curr_date.'+'. $test1.'days')); $yrdata= strtotime($f_value);
                                      echo date('d-M-Y', $yrdata);
                                    }else{
                                      echo "No record ";
                                    }   ?></h4>
                                    
                                    <span>100000</span>
                                  </div>
                                </div>
                              </div>

                            </div>
                          </div>
                        </div>
                      </div>

                    <?php } ?> 


                    <!-- For collector -->
                    <?php if ($this->session->userdata('type')==2) { ?> 
                      <div class="col-12 col-lg-6 col-xl-4">
                        <div class="card border-warning border-left-sm">
                          <div class="card-body">
                            <div class="media">
                              <div class="media-body text-left">
                                <h4 class="text-warning"><?= $collector_daily_collection->pay_loan_amt?></h4>
                                <span>Today's collction</span>
                              </div>
                              <div class="align-self-center w-circle-icon rounded-circle gradient-blooker">
                                <i class="fa fa-inr text-white"></i></div>
                              </div>
                            </div>
                          </div>
                        </div> 

                        <div class="col-12 col-lg-6 col-xl-4">
                          <div class="card border-warning border-left-sm">
                            <div class="card-body">
                              <div class="media">
                                <div class="media-body text-left">
                                  <h4 class="text-warning"><?= $collector_all_collection->pay_loan_amt?></h4>
                                  <span>All collction</span>
                                </div>
                                <div class="align-self-center w-circle-icon rounded-circle gradient-blooker">
                                  <i class="fa fa-inr text-white"></i></div>
                                </div>
                              </div>
                            </div>
                          </div> 

                        <?php } ?>

                        <!-- For Customer -->
                        <?php if ($this->session->userdata('type')==3) { ?> 
                          <div class="col-12 col-lg-6 col-xl-4">
                            <div class="card border-warning border-left-sm">
                              <div class="card-body">
                                <div class="media">
                                  <div class="media-body text-left">
                                    <h4 class="text-warning"><?= $cust_active_loan + $cust_inactive_loan + $cust_pending_loan?></h4>
                                    <span>Total Loan</span>
                                  </div>
                                  <div class="align-self-center w-circle-icon rounded-circle gradient-blooker">
                                    <i class="fa fa-inr text-white"></i></div>
                                  </div>
                                </div>
                              </div>
                            </div> 
                            <div class="col-12 col-lg-6 col-xl-4">
                              <div class="card border-warning border-left-sm">
                                <div class="card-body">
                                  <div class="media">
                                    <div class="media-body text-left">
                                      <h4 class="text-warning"><?= $cust_active_loan?></h4>
                                      <span>Active Loan</span>
                                    </div>
                                    <div class="align-self-center w-circle-icon rounded-circle gradient-blooker">
                                      <i class="fa fa-inr text-white"></i></div>
                                    </div>
                                  </div>
                                </div>
                              </div> 
                              <div class="col-12 col-lg-6 col-xl-4">
                                <div class="card border-warning border-left-sm">
                                  <div class="card-body">
                                    <div class="media">
                                      <div class="media-body text-left">
                                        <h4 class="text-warning"><?= $cust_inactive_loan ?></h4>
                                        <span>Closed Loan</span>
                                      </div>
                                      <div class="align-self-center w-circle-icon rounded-circle gradient-blooker">
                                        <i class="fa fa-inr text-white"></i></div>
                                      </div>
                                    </div>
                                  </div>
                                </div> 
                                <div class="col-12 col-lg-6 col-xl-4">
                                  <div class="card border-warning border-left-sm">
                                    <div class="card-body">
                                      <div class="media">
                                        <div class="media-body text-left">
                                          <h4 class="text-warning"><?= $cust_pending_loan ?></h4>
                                          <span>Pending Loan</span>
                                        </div>
                                        <div class="align-self-center w-circle-icon rounded-circle gradient-blooker">
                                          <i class="fa fa-inr text-white"></i></div>
                                        </div>
                                      </div>
                                    </div>
                                  </div> 

                                <?php } ?>

                                


                              </div><!--End Row-->
                              <!-- Charts -->
                              <div class="col-lg-12">
                                <div class="card">
                                  <div class="card-header text-uppercase">Last 7 Days Collection Chart</div>
                                  <div class="card-body">
                                   <canvas id="AreaChart1" style="height:300px;width:1000px"></canvas>
                                 </div>
                               </div>
                             </div>

                             <!-- <div class="col-lg-12">
                              <div class="card">
                                <div class="card-header text-uppercase">Month Wise Collection</div>
                                <div class="card-body">
                                  <div class="float-chart-container">
                                    <div id="column-chart1" class="float-chart"></div>
                                  </div>
                                </div>
                              </div>
                            </div>  -->

                            <div class="col-lg-12">
                              <div class="card">
                                <div class="card-header text-uppercase">Month Wise Collection</div>
                                <div class="card-body">
                                  <canvas id="barChart1" height="110"></canvas>
                                </div>
                              </div>
                            </div>

                          </div><!--End Row-->


                          <!--End Dashboard Content-->

                        </div>
                        <!-- End container-fluid-->

                      </div><!--End content-wrapper-->
                      <!--Start Back To Top Button-->
                      <a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
                      <!--End Back To Top Button-->



                    </div><!--End wrapper-->

                    <!-- Bootstrap core JavaScript-->
                    <script src="<?php echo base_url();?>assets/js/jquery.min.js"></script>
                    <script src="<?php echo base_url();?>assets/js/popper.min.js"></script>
                    <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>

                    <!-- simplebar js -->
                    <script src="<?php echo base_url();?>assets/plugins/simplebar/js/simplebar.js"></script>
                    <!-- waves effect js -->
                    <script src="<?php echo base_url();?>assets/js/waves.js"></script>
                    <!-- sidebar-menu js -->
                    <script src="<?php echo base_url();?>assets/js/sidebar-menu.js"></script>
                    <!-- Custom scripts -->
                    <script src="<?php echo base_url();?>assets/js/app-script.js"></script>

                    <!-- Vector map JavaScript -->
                    <script src="<?php echo base_url();?>assets/plugins/vectormap/jquery-jvectormap-2.0.2.min.js"></script>
                    <script src="<?php echo base_url();?>assets/plugins/vectormap/jquery-jvectormap-world-mill-en.js"></script>
                    <!-- Chart js -->
                    <script src="<?php echo base_url();?>assets/plugins/Chart.js/Chart.min.js"></script>
                    <script src="<?php echo base_url();?>assets/plugins/Chart.js/chartjs-script.js"></script>
                    <!-- Index js -->
                    <script src="<?php echo base_url();?>assets/js/index.js"></script>

                    <!-- Flot Chart JS -->
                    <script src="<?php echo base_url();?>assets/plugins/flot/jquery.flot.js"></script>
                    <script src="<?php echo base_url();?>assets/plugins/flot/jquery.flot.resize.js"></script>
                    <script src="<?php echo base_url();?>assets/plugins/flot/jquery.flot.categories.js"></script>
                    <script src="<?php echo base_url();?>assets/plugins/flot/jquery.flot.fillbetween.js"></script>
                    <script src="<?php echo base_url();?>assets/plugins/flot/jquery.flot.stack.js"></script>
                    <script src="<?php echo base_url();?>assets/plugins/flot/jquery.flot.pie.js"></script>
                    <script src="<?php echo base_url();?>assets/plugins/flot/float-chart.js"></script>


                  </body>


                  </html>

                  <script>
                    if ($('#AreaChart1').length) {
                     var ctx = document.getElementById('AreaChart1').getContext('2d');
                     var obj = <?php echo json_encode($loandate); ?>;
                     var obj1 = <?php echo json_encode($amount); ?>;

                     var myChart = new Chart(ctx, {
                      type: 'line',
                      data: {
          //labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
          labels: obj,
          datasets: [{
            label: 'CashProIndia',
            //data: [50, 30, 60, 25, 60, 25, 50, 10, 60, 30, 80, 0],
            data: obj1,
            backgroundColor: "rgba(0, 140, 255, 0.77)",
            borderColor: "#008cff",
            borderWidth: 1
          },]
        }
      });
                   }
                 </script>

                 <!--<script >
                  var data = <?php echo  json_encode($amount_month); ?>;

                  if($("#column-chart1").length) {
                    $.plot("#column-chart1", [data], {
                      series: {
                        bars: {
                          show: true,
                          barWidth: 0.6,
                          align: "center"
                        }
                      },
                      xaxis: {
                        mode: "categories",
                        tickLength: 0
                      },

                      grid: {
                        borderWidth: 0,
                        labelMargin: 10,
                        hoverable: true,
                        clickable: true,
                        mouseActiveRadius: 6,
                      }

                    });
                  }
                </script>-->
                <script >
                  if ($('#barChart1').length) {
                    var ctx = document.getElementById("barChart1").getContext('2d');
                    var obj = <?php echo json_encode($month); ?>;
                    var obj1 = <?php echo json_encode($amount_monthwise); ?>;
                    var myChart = new Chart(ctx, {
                      type: 'bar',
                      data: {
                        // labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
                        labels: obj,
                        datasets: [ {
                          label: 'Collection',
                          //data: [28, 48, 40, 19,28, 48, 40, 19,40, 19,28, 48],
                          data: obj1,
                          backgroundColor: "#0dceec"
                        }]
                      }, options: {
                        scales: {
                          xAxes: [{ 
                            barPercentage: .5
                          }]
                        }
                      }
                    });
                  }
                </script>

