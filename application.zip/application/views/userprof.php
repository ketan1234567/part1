      <!-- Breadcrumb-->
      <div class="row pt-2 pb-2">
        <div class="col-sm-9">
          <h4 class="page-title">User Details</h4>
        </div>
        <div class="col-sm-3">
         <div class="btn-group float-sm-right">
         </div>
       </div>
     </div>
     <!-- End Breadcrumb-->
     <div class="row">
      <!-- <div class="col-lg-4">
       <div class="profile-card-3">
        <div class="card">
          <div class="user-fullimage">
            <img src="<?php echo base_url();?>assets/images/avatars/avatar-22.png" alt="user avatar" class="card-img-top">
            <div class="details">
             <h5 class="mb-1 text-white ml-3"><?=$cust_detail->fname?> <?=$cust_detail->lname?></h5>
               <h6 class="text-white ml-3">Senior Designer</h6>
             </div>
           </div>
           <div class="card-body text-center">
            <h5 class="mb-1 text-black ml-3"><?=$cust_detail->fname?> <?=$cust_detail->lname?></h5>
            <hr>

          </div>
        </div>
      </div>
    </div> -->
    <div class="col-lg-12">
     <div class="card">
      <div class="card-body">
        <ul class="nav nav-tabs nav-tabs-primary top-icon nav-justified">
          <li class="nav-item">
            <a href="javascript:void();" data-target="#profile" data-toggle="pill" class="nav-link active"><i class="icon-user"></i> <span class="hidden-xs">Profile</span></a>
          </li>
          <li class="nav-item">
            <a href="javascript:void();" data-target="#loan_detail" data-toggle="pill" class="nav-link"><i class="icon-envelope-open"></i> <span class="hidden-xs">Loan Details</span></a>
          </li>
          <li class="nav-item">
            <a href="javascript:void();" data-target="#doc_detail" data-toggle="pill" class="nav-link"><i class="icon-envelope-open"></i> <span class="hidden-xs">Upload Document</span></a>
          </li>
        </ul>
        <div class="tab-content p-3">
          <div class="tab-pane active" id="profile">
            <button class="btn btn-outline-warning btn-sm waves-effect waves-light m-1" data-toggle="modal" data-target="#edit_profile" > Edit Profile</button>
            <h5 class="mb-3">User Profile</h5>
            <div class="row">
              <div class="col-md-12">

                <h6>Name</h6>
                <p>
                  <?=$cust_detail->fname?> <?=$cust_detail->lname?>
                </p>
                <h6>Contact</h6>
                <p>
                  <?=$cust_detail->contact?>
                </p>
                <h6>Address</h6>
                <p>
                  <?=$cust_detail->address?>
                </p>
                <h6>State</h6>
                <p>
                  <?=$cust_detail->state?>
                </p>
                <h6>Gender</h6>
                <p>
                  <?=$cust_detail->gender?>
                </p>
                <h6>Mail</h6>
                <p>
                  <?=$cust_detail->email?>
                </p>
                <h6>User Name</h6>
                <p>
                  <?=$cust_detail->username ?>
                </p>
                <h6>Password</h6>
                <p>
                  <?= hex2bin($cust_detail->password)?> <br>
                  <!-- <?=$cust_detail->password?> -->
                </p>

              </div>
            </div>
            <!--/row-->
          </div>
          <div class="tab-pane" id="loan_detail">
            <div class="alert alert-info alert-dismissible" role="alert">
             <button type="button" class="close" data-dismiss="alert">&times;</button>
          </div>
          <div class="table-responsive">
          <table id="example" class="table table-bordered">
            <thead>
              <tr>
                <th>#</th>
                <th>Loan Id</th>
                <th>Loan Amount</th>
                <th>Loan Status</th>
                
              </tr>
            </thead>
            <tbody>
              
             <?php $i=1; if(count($cust_loan_detail)){ ?>
               <?php foreach ($cust_loan_detail as $result) { ?>
                <tr>
                  <td><?= $i ?></td>
                  <td><?= $result->loan_id ?></td>
                  <td><?= $result->loanamt ?> </td>
                  <td><?php if ($result->is_active==0) {
                    echo "Active";
                  }else{
                    echo "Closed";
                  } ?>
                  <?php 
                        $encode= $result->loan_id ;
                        $ecode1 = base64_encode($encode);
                        $ecode2= trim($ecode1,'=');
                    ?> 

                  <a href="<?php echo base_url();?>index.php/showpassbook/<?= $ecode2 ?>" class="btn btn-outline-success btn-sm waves-effect waves-light m-1" title="Edit">Passbook</a>
                    
                  </td>
                </tr>
                <?php $i++;} ?>
              <?php } else { ?>
                <tr>
                  <td colspan="4">
                    No record found.
                  </td>
                </tr>

              <?php } ?> 
            </tbody>
          </table>
        </div>
        <!-- loan -->
        <div class="col-lg-12">
          <div class="card">
            <div class="card-body">
              <!-- <form id="personal-info"> -->
                <?php echo form_open('index.php/storeloan1',['id' => 'loan-info']); ?>
                <h4 class="form-header text-uppercase">
                  <i class="fa fa-user-circle-o"></i>
                  Loan Info
                </h4>
                <div class="form-group row">
                  <label for="input-1" class="col-sm-2 col-form-label">User Name</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="input-1" name="fname" value="<?= $cust_detail->fname." ". $cust_detail->lname  ?>" required>
                  </div>
                  <input type="hidden" name="id" value="<?= $cust_detail->id  ?>">
                </div>
                <div class="form-group row">
                  <label for="input-4" class="col-sm-2 col-form-label">Loan Ammount</label>
                  <div class="col-sm-10">
                    <input type="number" placeholder="Please Insert loan amount" class="form-control" id="loanamt" name="loanamt" required min="10" onchange="lendercount();" >
                    <input type="hidden" class="form-control" id="lenderamt" name="lenderamt">
                  </div>
                </div>
                <div class="form-group row">
                  <label for="input-4" class="col-sm-2 col-form-label">Loan Date</label>
                  <div class="col-sm-10">
                    <input type="text" name="loandate" id="autoclose-datepicker" class="form-control" required>
                  </div>
                </div>

                <div class="form-footer">
                  <button type="reset" class="btn btn-danger"><i class="fa fa-times"></i> CANCEL</button>
                  <button type="submit" class="btn btn-success"><i class="fa fa-check-square-o"></i> SAVE</button>
                </div>
                <?php echo form_close(); ?>
              </div>
            </div>
          </div>
</div>

<!-- doc Details -->
            <div class="tab-pane" id="doc_detail">
            
          <div class="row">
        <div class="col-12">
          <button class="btn btn-outline-warning btn-sm waves-effect waves-light m-1" data-toggle="modal" data-target="#add_document" > Add Document</button>
          <!-- <div class="card"> -->
            
            <div class="card-body">
              <div class="row">
              <?php if(count($cust_upload_doc)){ ?>
               <?php foreach ($cust_upload_doc as $cust_upload_doc) { ?>
                <div class="col-md-6 col-lg-3 col-xl-3">
                  <!-- <a href="<?php echo base_url();?>assets/upload/<?= $cust_upload_doc->cust_img_path; ?>" data-fancybox="group2">
                  <img src="<?php echo base_url();?>assets/upload/<?= $cust_upload_doc->cust_img_path; ?>" alt="<?= $cust_upload_doc->cust_img_path; ?>" class="lightbox-thumb img-thumbnail">

                </a> -->
                <a href="<?php echo base_url();?>assets/upload/<?= $cust_upload_doc->cust_img_path; ?>" target="_blank">link</a>
                <a href="<?php echo base_url();?>index.php/delete/<?= $cust_upload_doc->imgid; ?>" class="btn btn-outline-danger btn-sm waves-effect waves-light m-1">Delete</a>
                </div>
                <?php } ?>
              <?php } else { ?>
                <label>No Document Uploaded</label>

              <?php } ?> 
                
              </div>
            </div>
          <!-- </div> -->
        </div>
      </div>
</div>

</div>
</div>
</div>
</div>

</div>

</div>
<!-- End container-fluid-->
</div><!--End content-wrapper-->
<!--Start Back To Top Button-->
<a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>

  </div><!--End wrapper-->

  <!-- Modal for Edit profile -->
  <div class="modal fade" id="edit_profile">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title"><i class="fa fa-star"></i> Edit Profile </h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <?php echo form_open('index.php/updateprof'); ?>
          <div class="form-group row">
            <input type="hidden" name="agents_id" id="agents_id" class="form-control" value="<?= $cust_detail->id ?>">
              <label class="col-sm-4 col-form-label">First Name :-</label>
                <div class="col-sm-8">
                  <input type="text" class="form-control" name="edit_name" value=" <?=$cust_detail->fname?>">
                </div>
          </div>
          <div class="form-group row">
              <label class="col-sm-4 col-form-label">Last Name :-</label>
                <div class="col-sm-8">
                  <input type="text" class="form-control" name="edit_lname" value=" <?=$cust_detail->lname?>">
                </div>
          </div>
          <div class="form-group row">
            
              <label class="col-sm-4 col-form-label">Contact :-</label>
                <div class="col-sm-8">
                  <input type="text" class="form-control" name="edit_contact" value=" <?=$cust_detail->contact?>">
                </div>
          </div>
          <div class="form-group row">
            
              <label class="col-sm-4 col-form-label">Address :-</label>
                <div class="col-sm-8">
                  <input type="text" class="form-control" name="edit_address" value=" <?=$cust_detail->address?>">
                </div>
          </div>
          <div class="form-group row">
            
              <label class="col-sm-4 col-form-label">State :-</label>
                <div class="col-sm-8">
                  <input type="text" class="form-control" name="edit_state" value=" <?=$cust_detail->state?>">
                </div>
          </div>
          <div class="form-group row">
            
              <label class="col-sm-4 col-form-label">Gender :-</label>
                <div class="col-sm-8">
                  <input type="text" class="form-control" name="edit_gender" value=" <?=$cust_detail->gender?>">
                </div>
          </div>
          <div class="form-group row">
            
              <label class="col-sm-4 col-form-label">Mail :-</label>
                <div class="col-sm-8">
                  <input type="text" class="form-control" name="edit_email" value=" <?=$cust_detail->email?>">
                </div>
          </div>
          <div class="form-group row">
            
              <label class="col-sm-4 col-form-label">Username :-</label>
                <div class="col-sm-8">
                  <input type="text" class="form-control" name="edit_username" value=" <?=$cust_detail->username?>">
                </div>
          </div>
          <div class="form-group row">
            
              <label class="col-sm-4 col-form-label">Password :-</label>
                <div class="col-sm-8">
                  <input type="password" class="form-control" name="edit_password" value=" <?= hex2bin($cust_detail->password)?>">
                </div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
          <button type="submit" class="btn btn-primary"><i class="fa fa-check-square-o"></i> Update</button>
        </div>
        <?php echo form_close(); ?>
      </div>
    </div>
  </div>

  <!-- Modal for Add Document -->
  <div class="modal fade" id="add_document">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title"><i class="fa fa-star"></i> Add Document </h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <?php echo form_open_multipart('index.php/addphoto'); ?>
          <div class="form-group row">
            <input type="hidden" name="agents_id" id="agents_id" class="form-control" value="<?= $cust_detail->id ?>">
              <label class="col-sm-4 col-form-label">Insert Photo :-</label>
                <div class="col-sm-8">
                  <input type="file" class="form-control"  name="cust_img_path" required >
                </div>
          </div>
          
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
          <button type="submit" class="btn btn-primary"><i class="fa fa-check-square-o"></i> Update</button>
        </div>
        <?php echo form_close(); ?>
      </div>
    </div>
  </div>


  <!-- Bootstrap core JavaScript-->
  <script src="<?php echo base_url();?>assets/js/jquery.min.js"></script>
  <script src="<?php echo base_url();?>assets/js/popper.min.js"></script>
  <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>

  <!-- simplebar js -->
  <script src="<?php echo base_url();?>assets/plugins/simplebar/js/simplebar.js"></script>
  <!-- waves effect js -->
  <script src="<?php echo base_url();?>assets/js/waves.js"></script>
  <!-- sidebar-menu js -->
  <script src="<?php echo base_url();?>assets/js/sidebar-menu.js"></script>
  <!-- Custom scripts -->
  <script src="<?php echo base_url();?>assets/js/app-script.js"></script>
  <!--Bootstrap Datepicker Js-->
  <script src="<?php echo base_url();?>assets/plugins/bootstrap-datepicker/js/bootstrap-datepicker.min.js"></script>
  <!--Data Tables js-->
  <script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/jquery.dataTables.min.js"></script>
  <script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/dataTables.bootstrap4.min.js"></script>
  <script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/dataTables.buttons.min.js"></script>
  <script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/buttons.bootstrap4.min.js"></script>
  <script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/jszip.min.js"></script>
  <script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/pdfmake.min.js"></script>
  <script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/vfs_fonts.js"></script>
  <script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/buttons.html5.min.js"></script>
  <script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/buttons.print.min.js"></script>
  <script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/buttons.colVis.min.js"></script>

  <!--Lightbox-->
  <script src="<?php echo base_url();?>assets/plugins/fancybox/js/jquery.fancybox.min.js"></script>

  <script>
   $(document).ready(function() {
      //Default data table
      $('#default-datatable').DataTable();


      var table = $('#example').DataTable( {
        lengthChange: false,
       buttons: [ 'excel','colvis' ]
      } );

      table.buttons().container()
      .appendTo( '#example_wrapper .col-md-6:eq(0)' );
      
    } );

  </script>

</body>

</html>
<script type="text/javascript">
  function lendercount()
  {
    //var la = $("#loanamt").val();
    var la = document.getElementById('loanamt').value; 
    //var loan_amt = parseInt(la);
    var lenderamt = la*20/100;
    var total = +la + +lenderamt
    //alert(total);
    $("#lenderamt").val(total);
  }
</script>
<script>
    $('#default-datepicker').datepicker({
      todayHighlight: true
    });
    $('#autoclose-datepicker').datepicker({
      autoclose: true,
      todayHighlight: true
    });

    $('#inline-datepicker').datepicker({
     todayHighlight: true
   });

    $('#dateragne-picker .input-daterange').datepicker({
    });

  </script>
