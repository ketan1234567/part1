
<!-- Breadcrumb-->
<div class="row pt-2 pb-2">
  <div class="col-sm-9">
    <h4 class="page-title">Expenenses Type</h4>
  </div>
  <div class="col-sm-3">
   <div class="btn-group float-sm-right">
    <button type="button" class="btn btn-outline-primary waves-effect waves-light" data-toggle="modal" data-target="#largesizemodal"><i class="fa fa-user mr-1"></i> Exp Type</button>
  </div>
</div>
</div>
<!-- End Breadcrumb-->
<div class="row">
  <div class="col-lg-12">
    <div class="card">
     <!--  <div class="card-header"><i class="fa fa-table"></i> Data Exporting</div> -->
     <div class="card-body">
      <div class="table-responsive">
        <table id="example" class="table table-bordered">
          <thead>
            <tr>
              <th>#</th>
              <th>Expenses Type</th>
              <!-- <th>Description</th>
              <th>Date</th>
              <th>Amount</th> -->
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <?php $i=1; if(count($expenceses_type)): ?>
            <?php foreach ($expenceses_type as $expenceses_type): ?>
              <tr>
                <td><?= $i ?></td>
                <!-- <td><?= $expenceses_data->exp_type ?></td>
                  <td><?= $expenceses_data->remark ?></td> -->
                  <td><?= $expenceses_type->exp_type ?></td> 
                  <!-- <td><?php $yrdata= strtotime($expenceses_data->date);
                  echo date('d-M-Y', $yrdata); ?></td> -->
                  <!-- <td><?= $expenceses_data->amount ?></td> -->
                  <td>

                   <!--  <a href="<?php echo base_url();?>viewcustomer/<?= $expenceses_data->id ?>" class="btn btn-outline-info btn-sm waves-effect waves-light m-1"><i class="fa fa-rupee"></i></a> -->
                   <!-- <a href="<?php echo base_url();?>viewemployee/<?= $expenceses_data->tbl_employee_id ?>" class="btn btn-outline-success btn-sm waves-effect waves-light m-1"><i class="fa fa-eye"></i></a> -->
                   <!-- <a href="<?php echo base_url();?>index.php/edit_exp_type/<?= $expenceses_type->id ?>" class="btn btn-outline-success btn-sm waves-effect waves-light m-1" data-toggle="modal" data-target="#largesizemodal"><i class="fa fa-pencil"></i></a> -->
                   <a href="#" class="btn btn-outline-success btn-sm waves-effect waves-light m-1" title="Edit Exp Type" data-toggle="modal" data-target="#exptypeeditmodal" data-index="<?=$expenceses_type->id?>" name="exptypeedit"><i class="fa fa-pencil"></i></a>
                   <a href="<?php echo base_url();?>index.php/del_exp_type/<?= $expenceses_type->id ?>" class="btn btn-outline-danger btn-sm waves-effect waves-light m-1"><i class="fa fa-trash"></i></a>
                 </td>
               </tr>
               <?php $i++;endforeach; ?>
               <?php else: ?>
                <tr>
                  <td colspan="9">
                    No record found.
                  </td>
                </tr>

              <?php endif; ?> 
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div><!-- End Row-->

</div>
<!-- End container-fluid-->

</div><!--End content-wrapper-->
</div><!--End wrapper-->
<!-- Modal -->
<div class="modal fade" id="largesizemodal">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title"><i class="fa fa-star"></i> Add Expenses Type</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <?php echo form_open('index.php/insertexptype'); ?>
        <div class="form-group row">
          <label for="input-6" class="col-sm-4 col-form-label">Expenses Type</label>
          <div class="col-sm-8">
            <input type="text" class="form-control"  id="exp_type" name="exp_type" required placeholder="Please Enter Expenses Type" >
          </div>

        </div> 

        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
          <button type="submit" class="btn btn-primary"><i class="fa fa-check-square-o"></i> Add</button>
        </div>
        <?php echo form_close(); ?>
      </div>
    </div>
  </div>
</div>

<!-- exptypeeditmodal Modal -->
<div class="modal fade" id="exptypeeditmodal">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title"><i class="fa fa-star"></i> Edit Expenses Type</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <?php echo form_open('index.php/editexptype'); ?>
        <input type="hidden" name="id" id="exp_type_id">
        <div class="form-group row">
          <label for="input-6" class="col-sm-4 col-form-label">Expenses Type</label>
          <div class="col-sm-8">
            <input type="text" class="form-control"  id="exp_type1" name="exp_type" required placeholder="Please Enter Expenses Type" >
          </div>

        </div> 

        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
          <button type="submit" class="btn btn-primary"><i class="fa fa-check-square-o"></i>Update</button>
        </div>
        <?php echo form_close(); ?>
      </div>
    </div>
  </div>
</div>


<!-- Bootstrap core JavaScript-->
<script src="<?php echo base_url();?>assets/js/jquery.min.js"></script>
<script src="<?php echo base_url();?>assets/js/popper.min.js"></script>
<script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>

<!-- simplebar js -->
<script src="<?php echo base_url();?>assets/plugins/simplebar/js/simplebar.js"></script>
<!-- waves effect js -->
<script src="<?php echo base_url();?>assets/js/waves.js"></script>
<!-- sidebar-menu js -->
<script src="<?php echo base_url();?>assets/js/sidebar-menu.js"></script>
<!-- Custom scripts -->
<script src="<?php echo base_url();?>assets/js/app-script.js"></script>

<!--Data Tables js-->
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/dataTables.bootstrap4.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/dataTables.buttons.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/buttons.bootstrap4.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/jszip.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/pdfmake.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/vfs_fonts.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/buttons.html5.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/buttons.print.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/buttons.colVis.min.js"></script>

<script>
 $(document).ready(function() {
      //Default data table
      $('#default-datatable').DataTable();


      var table = $('#example').DataTable( {
        lengthChange: false,
        buttons: [ 'excel','print', ]
        //buttons: [ 'copy', 'excel', 'pdf', 'print', 'colvis' ]
      } );

      table.buttons().container()
      .appendTo( '#example_wrapper .col-md-6:eq(0)' );
      
    } );

  </script>
  <script type="text/javascript">

    $("a[name=exptypeedit]").on("click", function () { 
      var exp_type_id = $(this).data("index"); 
      $("#exp_type_id").val(exp_type_id);
      // alert(exp_type_id);
      // alert(pay_id);
      $.ajax({
        url: '<?php echo base_url(); ?>index.php/show_exp_type_id',
        type: 'POST',
        data:  { 'exp_type_id' : exp_type_id },
        success: function(response,status,xhr) {
          console.info(response);
          var a =jQuery.parseJSON(response);
          $("#exp_type1").val(a.exp_type); 
        }
      }); 
    });
  </script>
  


