<style type="text/css">
  label.required { color: red; font-size: 20px; }
</style>
<div class="row">
  <div class="col-lg-12">
    <div class="card">
      <div class="card-header"><i class="fa fa-calculator"></i> Calculation </div>
      <div class="card-body">
        <div class="row"> 
          <div class="col-lg-6">
            <div class="form-group row">
              <label  class="col-sm-4 col-form-label">Loan Amount</label>
              <div class="col-sm-8">
                <input type="number" name="loanamt" id="loanamt" class="form-control" id="loanamt" placeholder="Amount" required>
              </div>
            </div>
            <div class="form-group row">
              <label  class="col-sm-4 col-form-label">Rate</label>
              <div class="col-sm-8">
                <input type="number" name="rate" id="rate" class="form-control" id="loanamt" placeholder="Percent (%)" required>
              </div>
            </div>
            <div class="form-group row">
              <label  class="col-sm-4 col-form-label">Days</label>
              <div class="col-sm-8">
                <input type="number" name="days" id="days" class="form-control" id="loanamt" placeholder="days (60-90-120)" required>
              </div>
            </div>
          </div>
          <!-- OutPut -->
          <div class="col-lg-6">
             <div class="form-group row">
              <label  class="col-sm-4 col-form-label">Daily Collection</label>
              <label  class="col-sm-4 col-form-label required" id="dailycoll1" ></label>
              <!-- <div class="col-sm-8">
                <input name="dailycoll" id="dailycoll" class="form-control" readonly >
              </div> -->
            </div>
            <div class="form-group row">
              <label  class="col-sm-4 col-form-label">Total Amount</label>
               <label  class="col-sm-4 col-form-label required" id="totalamt1"></label>
              <!-- <div class="col-sm-8">
                <input name="totalamt" id="totalamt" class="form-control" readonly >
              </div> -->
            </div>
           
            <div class="form-group row">
              <div class="col-sm-8">
                <button type="button" class="btn btn-primary" onclick="calculation()"> Calculation </button>
              </div>
              
            </div>
             
          </div>
        </div>
        
        
      </div>
    </div>
  </div>
</div><!-- End Row-->

</div>
<!-- End container-fluid-->

</div><!--End content-wrapper-->
<!--Start Back To Top Button-->
<a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
<!--End Back To Top Button-->


</div>






<!-- Bootstrap core JavaScript-->
<script src="<?php echo base_url();?>assets/js/jquery.min.js"></script>
<script src="<?php echo base_url();?>assets/js/popper.min.js"></script>
<script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>

<!-- simplebar js -->
<script src="<?php echo base_url();?>assets/plugins/simplebar/js/simplebar.js"></script>
<!-- waves effect js -->
<script src="<?php echo base_url();?>assets/js/waves.js"></script>
<!-- sidebar-menu js -->
<script src="<?php echo base_url();?>assets/js/sidebar-menu.js"></script>
<!-- Custom scripts -->
<script src="<?php echo base_url();?>assets/js/app-script.js"></script>

<!--Data Tables js-->
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/dataTables.bootstrap4.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/dataTables.buttons.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/buttons.bootstrap4.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/jszip.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/pdfmake.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/vfs_fonts.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/buttons.html5.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/buttons.print.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/buttons.colVis.min.js"></script>

<script>
 $(document).ready(function() {
      //Default data table
      $('#default-datatable').DataTable();


      var table = $('#example').DataTable( {
        lengthChange: false,
        buttons: [ 'excel','colvis' ]
      } );

      table.buttons().container()
      .appendTo( '#example_wrapper .col-md-6:eq(0)' );
      
    } );

  </script>
  <script type="text/javascript">

    $("a[name=changeapprove]").on("click", function () { 
      var id = $(this).data("index"); 
              //alert(id);
              $.ajax({
                url: '<?php echo base_url(); ?>index.php/changeapprove',
                type: 'POST',
                data:  { 'id' : id, 'val': 1 },
                success: function(response,status,xhr) {
                  //console.info(response);
                  //window.location.href="vendorlist";
                  //alert(response);
                  location.relode();

                }
              }); 
            });
    $("a[name=changeapprove1]").on("click", function () { 
      var id = $(this).data("index"); 
              //alert(id);
              $.ajax({
                url: '<?php echo base_url(); ?>index.php/changeapprove',
                type: 'POST',
                data:  { 'id' : id, 'val': 0 },
                success: function(response,status,xhr) {
                  //console.info(response);
                  //window.location.href="vendorlist";
                  //alert(response);
                  location.relode();

                }
              }); 
            });
          </script>

        </body>

        </html>
        

        <script type="text/javascript">
          function calculation()
          {
           
           var loanamt = $("#loanamt").val();
           var rate1 = $("#rate").val();
           var days = $("#days").val();
            if (loanamt && rate1 && days ) {
                var flag = 1;
            }
            if (flag === 1) {
                var rate = rate1/100;

               var totalamount = (rate*loanamt) + +loanamt ;
               $("#totalamt").val(totalamount);
               $("#totalamt1").text(totalamount);
               var daily1 = totalamount/days;
               var daily = Math.round(daily1);
               //alert(daily);
               $("#dailycoll").val(daily);
               $("#dailycoll1").text(daily);
            }else{
              alert("Please Fill all value !!!")
            }

           
          }
        </script>
