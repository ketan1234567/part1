
<div class="row">
  <div class="col-lg-12">
    <div class="card">
      <div class="card-header"><i class="fa fa-table"></i> Daily Collection </div>
      <div class="card-body">
        <div class="table-responsive">
          <table  class="table table-bordered">
            <thead>
              <tr>
                <th>#</th>
                <th>Collection Date</th>
                <th>Enter Date</th>
                <th>Loan ID</th>
                <th>Payment</th>
                
              </tr>
            </thead>
            <tbody>
             <?php $i=1; if(count($dailycollection)){ ?>
               <?php foreach ($dailycollection as $result) { ?>
                <tr>
                  <td><?= $i ?></td>
                  <td><?= $result->timestamp ?></td>
                  <td><?= $result->loandate ?></td>
                  <td><?= $result->loan_id."-".$result->fname." ".$result->lname ?></td>
                  <td><?= $result->pay_loan_amt ?></td>
                  
                </tr>
                <?php $i++;} ?>
              <?php } else { ?>
                <tr>
                  <td colspan="5">
                    No record found.
                  </td>
                </tr>

              <?php } ?> 
              <tr>
                <td><b>Total Collection</b></td>
                <td></td>
                <td></td>
                <td></td>
                <td><b>
                  <?php 
                  $sum = 0;
                  for ($i=0; $i < count($dailycollection) ; $i++) { 
                    $sum = $sum + $dailycollection[$i]->pay_loan_amt;
                  }
                  print_r($sum);
                  ?>
                </b></td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div><!-- End Row-->

</div>
<!-- End container-fluid-->

</div><!--End content-wrapper-->
<!--Start Back To Top Button-->
<a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
<!--End Back To Top Button-->


</div><!--End wrapper-->


<!-- Bootstrap core JavaScript-->
<script src="<?php echo base_url();?>assets/js/jquery.min.js"></script>
<script src="<?php echo base_url();?>assets/js/popper.min.js"></script>
<script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>

<!-- simplebar js -->
<script src="<?php echo base_url();?>assets/plugins/simplebar/js/simplebar.js"></script>
<!-- waves effect js -->
<script src="<?php echo base_url();?>assets/js/waves.js"></script>
<!-- sidebar-menu js -->
<script src="<?php echo base_url();?>assets/js/sidebar-menu.js"></script>
<!-- Custom scripts -->
<script src="<?php echo base_url();?>assets/js/app-script.js"></script>

<!--Data Tables js-->
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/dataTables.bootstrap4.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/dataTables.buttons.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/buttons.bootstrap4.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/jszip.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/pdfmake.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/vfs_fonts.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/buttons.html5.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/buttons.print.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/buttons.colVis.min.js"></script>

<script>
 $(document).ready(function() {
      //Default data table
      $('#default-datatable').DataTable();


      var table = $('#example').DataTable( {
        lengthChange: false,
        buttons: [ 'excel','colvis' ]
      } );

      table.buttons().container()
      .appendTo( '#example_wrapper .col-md-6:eq(0)' );
      
    } );

  </script>

</body>


</html>
