<!DOCTYPE html>
<html lang="en">
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  
  <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"/>
  <meta name="description" content=""/>
  <meta name="author" content=""/>
  <title>cashproindia</title>
  <!--favicon-->
  <link rel="icon" href="<?php echo base_url();?>assets/images/favicon.ico" type="image/x-icon">
  <!-- Vector CSS -->
  <link href="<?php echo base_url();?>assets/plugins/vectormap/jquery-jvectormap-2.0.2.css" rel="stylesheet" />
  <!--Lightbox Css-->
  <link href="<?php echo base_url();?>assets/plugins/fancybox/css/jquery.fancybox.min.css" rel="stylesheet" type="text/css"/>
  <!-- simplebar CSS-->
  <link href="<?php echo base_url();?>assets/plugins/simplebar/css/simplebar.css" rel="stylesheet"/>
  <!--Select Plugins-->
  <link href="<?php echo base_url();?>assets/plugins/select2/css/select2.min.css" rel="stylesheet" />
  <!--multi select-->
  <link href="<?php echo base_url();?>assets/plugins/jquery-multi-select/multi-select.css" rel="stylesheet" type="text/css">
  <!-- Bootstrap core CSS-->
  <link href="<?php echo base_url();?>assets/css/bootstrap.min.css" rel="stylesheet"/>
  <!--Data Tables -->
  <link href="<?php echo base_url();?>assets/plugins/bootstrap-datatable/css/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css">
  <!-- animate CSS-->
  <link href="<?php echo base_url();?>assets/css/animate.css" rel="stylesheet" type="text/css"/>
  <!-- Icons CSS-->
  <link href="<?php echo base_url();?>assets/css/icons.css" rel="stylesheet" type="text/css"/>
  <!-- Sidebar CSS-->
  <link href="<?php echo base_url();?>assets/css/sidebar-menu.css" rel="stylesheet"/>
  <!-- Custom Style-->
  <link href="<?php echo base_url();?>assets/css/app-style.css" rel="stylesheet"/>
  <!--Bootstrap Datepicker-->
  <link href="<?php echo base_url();?>assets/plugins/bootstrap-datepicker/css/bootstrap-datepicker.min.css" rel="stylesheet" type="text/css">
  
</head>

<body>

  <!-- Start wrapper-->
  <div id="wrapper">

    <!--Start sidebar-wrapper-->
    <div id="sidebar-wrapper" data-simplebar="" data-simplebar-auto-hide="true">
     <div class="brand-logo">
      <a href="<?php echo base_url();?>index.php/dashboard">
       <img src="<?php echo base_url();?>assets/images/logo-icon.png" class="logo-icon" alt="logo icon">
       <h5 class="logo-text"><?= $this->session->userdata('fname');  ?></h5>
     </a>
   </div>
   <ul class="sidebar-menu do-nicescrol">
     
    <li>
      <a href="<?php echo base_url();?>index.php/dashboard" class="waves-effect">
        <i class="icon-home"></i> <span>Dashboard</span> 
      </a>
    </li>
    
    <?php if ($this->session->userdata('type')==1) { ?> 
      <li>
        <a href="<?php echo base_url();?>index.php/agents" class="waves-effect">
          <i class="fa fa-group"></i> <span>Customer List</span> 
        </a>
      </li>
      <li>
        <a href="<?php echo base_url();?>index.php/loanlist" class="waves-effect">
          <i class="fa fa-bar-chart"></i> <span>Loan List</span> 
        </a>
      </li>
      <li>
        <a href="<?php echo base_url();?>index.php/closedloan" class="waves-effect">
          <i class="fa fa-bullseye"></i> <span>Closed Loan List</span> 
        </a>
      </li>
      <li>
        <a href="<?php echo base_url();?>index.php/collector" class="waves-effect">
          <i class="fa fa-user-o"></i> <span>Collector List</span> 
        </a>
      </li>
    <?php } ?> 

    <?php if ($this->session->userdata('type')==2) { ?> 
      <li>
        <a href="<?php echo base_url();?>index.php/customers" class="waves-effect">
          <i class="fa fa-inr"></i> <span>Customer Payment</span> 
        </a>
      </li>
      <li>
        <a href="<?php echo base_url();?>index.php/closedloan" class="waves-effect">
          <i class="fa fa-inr"></i> <span>Closed Loan</span> 
        </a>
      </li>
      <li>
        <a href="<?php echo base_url();?>index.php/daily" class="waves-effect">
          <i class="fa fa-check"></i> <span>Daily Collection</span> 
        </a>
      </li>
      <li>
        <a href="<?php echo base_url();?>index.php/all" class="waves-effect">
          <i class="fa fa-check-square-o"></i> <span>All Collection</span> 
        </a>
      </li>
    <?php } ?> 
    <?php if ($this->session->userdata('type')==3) { ?> 
      <li>
        <a href="<?php echo base_url();?>index.php/loan" class="waves-effect">
          <i class="zmdi zmdi-assignment"></i> <span>Loan Form</span> 
        </a>
      </li>
      <li>
        <a href="<?php echo base_url();?>index.php/passbook" class="waves-effect">
          <i class="zmdi zmdi-view-web"></i> <span>Pass-Book</span> 
        </a>
      </li>
    <?php } ?> 
    <?php if ($this->session->userdata('type')==1) { ?> 
      <li>
        <a href="<?php echo base_url();?>index.php/addcapital" class="waves-effect">
          <i class="fa fa-inr"></i> <span>Add Capital</span> 
        </a>
      </li>
      <li>
        <a href="#" class="waves-effect">
          <i class="fa fa-inr"></i> <span>Fine</span> <i class="fa fa-angle-left pull-right"></i>
        </a>
        <ul class="sidebar-submenu">
         
          <li><a href="<?php echo base_url();?>index.php/addfine"><i class="fa fa-circle-o"></i> Add Fine</a></li>
        </ul>
      </li>
       <li>
        <a href="#" class="waves-effect">
          <i class="zmdi zmdi-shopping-basket"></i> <span>Expenses</span> <i class="fa fa-angle-left pull-right"></i>
        </a>
        <ul class="sidebar-submenu">
         
          <li><a href="<?php echo base_url();?>index.php/expenceses"><i class="fa fa-circle-o"></i> Add Expenses</a></li>
          <li><a href="<?php echo base_url();?>index.php/expenceses_type"><i class="fa fa-circle-o"></i> Expenses Type</a></li>
         
        </ul>
      </li>
      <li>
        <a href="#" class="waves-effect">
          <i class="fa fa-file-text-o"></i> <span>All Report</span> <i class="fa fa-angle-left pull-right"></i>
        </a>
        <ul class="sidebar-submenu">
         
          <li><a href="<?php echo base_url();?>index.php/datewisereport"><i class="fa fa-circle-o"></i> Date Wise Report</a></li>
          <li><a href="<?php echo base_url();?>index.php/custperfreport"><i class="fa fa-circle-o"></i> Customer Performance</a></li>
          <li><a href="<?php echo base_url();?>index.php/enddateprojreport"><i class="fa fa-circle-o"></i> End Date Projection</a></li>
          <li><a href="<?php echo base_url();?>index.php/upreport"><i class="fa fa-circle-o"></i> Business Forecast</a></li>
           <li><a href="<?php echo base_url();?>index.php/report"><i class="fa fa-circle-o"></i> Loan Breakup</a></li>
        </ul>
      </li>
      <li>
      <a href="<?php echo base_url();?>index.php/calculator" class="waves-effect">
        <i class="fa fa-calculator"></i> <span>Calculator</span> 
      </a>
    </li>
    <li>
      <a href="<?php echo base_url();?>index.php/verifer" class="waves-effect">
        <i class="zmdi zmdi-vimeo"></i> <span>Verifer</span> 
      </a>
    </li>
    <li>
      <a href="<?php echo base_url();?>index.php/smsportal" class="waves-effect">
        <i class="fa fa-mobile"></i> <span>SMS</span> 
      </a>
    </li>
    

    <!-- <li>
      <a href="<?php echo base_url();?>index.php/report" class="waves-effect">
        <i class="fa fa-file"></i> <span>Report</span> 
      </a>
    </li>
    <li>
      <a href="<?php echo base_url();?>index.php/upreport" class="waves-effect">
        <i class="fa fa-file"></i> <span>Upcomming Report</span> 
      </a>
    </li> -->
  <?php } ?> 
  
  <?php if ($this->session->userdata('username')=="superadmin") { ?> 
  
     <li>
      <a href="<?php echo base_url();?>index.php/dbbackup" class="waves-effect">
        <i class="zmdi zmdi-view-web"></i> <span>DB-Backup</span> 
      </a>
    </li>

    <li>
      <a href="<?php echo base_url();?>index.php/extra" class="waves-effect">
        <i class="zmdi zmdi-view-web"></i> <span>Extra</span> 
      </a>
    </li>
  <?php } ?> 


</ul>

</div>
<!--End sidebar-wrapper-->

<!--Start topbar header-->
<header class="topbar-nav">
 <nav class="navbar navbar-expand fixed-top bg-white">
  <ul class="navbar-nav mr-auto align-items-center">
    <li class="nav-item">
      <a class="nav-link toggle-menu" href="javascript:void();">
       <i class="icon-menu menu-icon"></i>
     </a>
   </li>

 </ul>
 
 <div style="font-size:14px;">
        <h4 class='format'></h4>
        <b><p id='demo' class="text-center cal-container"></p></b>
      </div>

 <ul class="navbar-nav align-items-center right-nav-link">
  <li class="nav-item">
    <a class="nav-link dropdown-toggle dropdown-toggle-nocaret" href="<?php echo base_url();?>index.php/logout">
      <span class="user-profile"><i class="icon-power mr-2"></i></span>
    </a>
  </li>
</ul>
</nav>
</header>
<!--End topbar header-->

<div class="clearfix"></div>

<div class="content-wrapper">
  <div class="container-fluid">
      
      
 <?php
  $date = new DateTime();
  $current_timestamp = $date->getTimestamp();
?>

<script>
  flag_time = true;
  timer = '';
  setInterval(function(){phpJavascriptClock();},1000);
  
  function phpJavascriptClock()
  {
    if ( flag_time ) {
    timer = <?php echo $current_timestamp;?>*1000;
    }
    var d = new Date(timer);
    months = new Array('Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sept', 'Oct', 'Nov', 'Dec');
    
    month_array = new Array('January', 'Febuary', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December');
    
    day_array = new Array( 'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday');
    
    currentYear = d.getFullYear();
    month = d.getMonth();
    var currentMonth = months[month];
    var currentMonth1 = month_array[month];
    var currentDate = d.getDate();
    currentDate = currentDate < 10 ? '0'+currentDate : currentDate;
    
    var day = d.getDay();
    current_day = day_array[day];
    var hours = d.getHours();
    var minutes = d.getMinutes();
    var seconds = d.getSeconds();
    
    var ampm = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12;
    hours = hours ? hours : 12; // the hour ’0′ should be ’12′
    minutes = minutes < 10 ? '0'+minutes : minutes;
    seconds = seconds < 10 ? '0'+seconds : seconds;
    var strTime = hours + ':' + minutes+ ':' + seconds + ' ' + ampm;
    timer = timer + 1000;
    document.getElementById("demo").innerHTML= currentDate+' ' + currentMonth1+' , ' + currentYear + ' ' + strTime + ' ( ' + current_day + ' ) ';
    
    
    flag_time = false;
  }
</script>   
      
