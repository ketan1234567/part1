
<!--Sweet Alerts -->
  <script src="<?php echo base_url();?>assets/plugins/alerts-boxes/js/sweetalert.min.js"></script>
  <script src="<?php echo base_url();?>assets/plugins/alerts-boxes/js/sweet-alert-script.js"></script>

<?php
  if($error = $this->session->flashdata('success')) {
    ?>
    <script>
      
      swal("Good job!", "<?php echo $this->session->flashdata('success'); ?>", "success");

    </script>
    <?php
  }
  ?>
  <?php
      if($error = $this->session->flashdata('success1')) {
          ?>
          <script>
              swal({

                  title: 'Good job!',
                  text: '<?php echo $this->session->flashdata('success1'); ?>',
                  timer: 2000

              })

          </script>
          <?php
      }
  ?>


  <?php
  if($error = $this->session->flashdata('warning')) {
    ?>
    <script>
      swal("Warning!", "<?php echo $this->session->flashdata('warning'); ?>", "error");

    </script>
    <?php
  }
  ?>
