<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from codervent.com/rocker/white-version/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 13 Dec 2018 13:55:44 GMT -->
<head>
  <meta charset="utf-8"/>
  <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"/>
  <meta name="description" content=""/>
  <meta name="author" content=""/>
  <title>cashproindia</title>
  <!--favicon-->
  <link rel="icon" href="<?php echo base_url();?>assets/images/favicon.ico" type="image/x-icon">
  <!-- Vector CSS -->
  <link href="<?php echo base_url();?>assets/plugins/vectormap/jquery-jvectormap-2.0.2.css" rel="stylesheet" />
  <!-- simplebar CSS-->
  <link href="<?php echo base_url();?>assets/plugins/simplebar/css/simplebar.css" rel="stylesheet"/>
  <!-- Bootstrap core CSS-->
  <link href="<?php echo base_url();?>assets/css/bootstrap.min.css" rel="stylesheet"/>
  <!--Data Tables -->
  <link href="<?php echo base_url();?>assets/plugins/bootstrap-datatable/css/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css">
  <!-- animate CSS-->
  <link href="<?php echo base_url();?>assets/css/animate.css" rel="stylesheet" type="text/css"/>
  <!-- Icons CSS-->
  <link href="<?php echo base_url();?>assets/css/icons.css" rel="stylesheet" type="text/css"/>
  <!-- Sidebar CSS-->
  <link href="<?php echo base_url();?>assets/css/sidebar-menu.css" rel="stylesheet"/>
  <!-- Custom Style-->
  <link href="<?php echo base_url();?>assets/css/app-style.css" rel="stylesheet"/>
  <!--Bootstrap Datepicker-->
  <link href="<?php echo base_url();?>assets/plugins/bootstrap-datepicker/css/bootstrap-datepicker.min.css" rel="stylesheet" type="text/css">
  
</head>

<body>

  <!-- Start wrapper-->
  <div id="wrapper">

    <!--Start sidebar-wrapper-->
    <div id="sidebar-wrapper" data-simplebar="" data-simplebar-auto-hide="true">
     <div class="brand-logo">
      <a href="<?php echo base_url();?>index.php/dashboard">
       <img src="<?php echo base_url();?>assets/images/logo-icon.png" class="logo-icon" alt="logo icon">
       <h5 class="logo-text"><?= $this->session->userdata('fname');  ?></h5>
     </a>
   </div>
   <ul class="sidebar-menu do-nicescrol">
   
    <li>
      <a href="<?php echo base_url();?>index.php/dashboard" class="waves-effect">
        <i class="icon-home"></i> <span>Dashboard</span> 
      </a>
    </li>
    
    <?php if ($this->session->userdata('type')==1) { ?> 
    <li>
      <a href="<?php echo base_url();?>index.php/agents" class="waves-effect">
        <i class="fa fa-group"></i> <span>Customer List</span> 
      </a>
    </li>
    <li>
      <a href="<?php echo base_url();?>index.php/loanlist" class="waves-effect">
        <i class="fa fa-bar-chart"></i> <span>Loan List</span> 
      </a>
    </li>
    <li>
        <a href="<?php echo base_url();?>index.php/closedloan" class="waves-effect">
          <i class="fa fa-inr"></i> <span>Closed Loan List</span> 
        </a>
      </li>
    <li>
      <a href="<?php echo base_url();?>index.php/collector" class="waves-effect">
        <i class="fa fa-user-o"></i> <span>Collector List</span> 
      </a>
    </li>
    <?php } ?> 

    <?php if ($this->session->userdata('type')==2) { ?> 
      <li>
        <a href="<?php echo base_url();?>index.php/customers" class="waves-effect">
          <i class="fa fa-inr"></i> <span>Agents Pay</span> 
        </a>
      </li>
      <li>
        <a href="<?php echo base_url();?>index.php/closedloan" class="waves-effect">
          <i class="fa fa-inr"></i> <span>Closed Loan</span> 
        </a>
      </li>
      <li>
        <a href="<?php echo base_url();?>index.php/daily" class="waves-effect">
          <i class="fa fa-check"></i> <span>Daily Collection</span> 
        </a>
      </li>
      <li>
        <a href="<?php echo base_url();?>index.php/all" class="waves-effect">
          <i class="fa fa-check-square-o"></i> <span>All Collection</span> 
        </a>
      </li>
    <?php } ?> 
    <?php if ($this->session->userdata('type')==3) { ?> 
    <li>
      <a href="<?php echo base_url();?>index.php/loan" class="waves-effect">
        <i class="zmdi zmdi-assignment"></i> <span>Loan Form</span> 
      </a>
    </li>
    <li>
      <a href="<?php echo base_url();?>index.php/passbook" class="waves-effect">
        <i class="zmdi zmdi-view-web"></i> <span>Pass-Book</span> 
      </a>
    </li>
    <?php } ?> 

    <!-- <li>
      <a href="<?php echo base_url();?>index.php/extra" class="waves-effect">
        <i class="zmdi zmdi-view-web"></i> <span>Extra</span> 
      </a>
    </li> -->


  </ul>

</div>
<!--End sidebar-wrapper-->

<!--Start topbar header-->
<header class="topbar-nav">
 <nav class="navbar navbar-expand fixed-top bg-white">
  <ul class="navbar-nav mr-auto align-items-center">
    <li class="nav-item">
      <a class="nav-link toggle-menu" href="javascript:void();">
       <i class="icon-menu menu-icon"></i>
     </a>
   </li>

 </ul>

 <ul class="navbar-nav align-items-center right-nav-link">
  <li class="nav-item">
    <a class="nav-link dropdown-toggle dropdown-toggle-nocaret" href="<?php echo base_url();?>index.php/logout">
      <span class="user-profile"><i class="icon-power mr-2"></i></span>
    </a>
  </li>
</ul>
</nav>
</header>
<!--End topbar header-->

<div class="clearfix"></div>

<div class="content-wrapper">
  <div class="container-fluid">
