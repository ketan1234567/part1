
<!-- Breadcrumb-->
<div class="row pt-2 pb-2">
  <div class="col-sm-9">
    <h4 class="page-title">Fines</h4>
  </div>
  <div class="col-sm-3">
   <div class="btn-group float-sm-right">
    <button type="button" class="btn btn-outline-primary waves-effect waves-light" data-toggle="modal" data-target="#fineModal"><i class="fa fa-user mr-1"></i> Add fine</button>
  </div>
</div>
</div>
<!-- End Breadcrumb-->
<div class="row">
  <div class="col-lg-12">
    <div class="card">
     <!--  <div class="card-header"><i class="fa fa-table"></i> Data Exporting</div> -->
     <div class="card-body">
      <div class="table-responsive">
        <table id="example" class="table table-bordered">
          <thead>
            <tr>
              <th>#</th>
              <th>Description</th>
              <th>Date</th>
              <th>Amount</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <?php $i=1; if(count($fines)): ?>
            <?php foreach ($fines as $data): ?>
              <tr>
                <td><?= $i ?></td>
                <!-- <td><?= $data->remark ?></td> -->
                <td><?= wordwrap($data->remark,40,"<br>\n"); ?></td>
                <td><?php $yrdata= strtotime($data->date);
                echo date('d-M-Y', $yrdata); ?></td>
                <td><?= $data->amount ?></td>
                <td>
                 <a href="<?php echo base_url();?>index.php/del_fines/<?= $data->tbl_fines_id ?>" class="btn btn-outline-danger btn-sm waves-effect waves-light m-1"><i class="fa fa-trash"></i></a>
               </td>
             </tr>
             <?php $i++;endforeach; ?>
             <?php else: ?>
              <tr>
                <td colspan="9">
                  No record found.
                </td>
              </tr>

            <?php endif; ?> 
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
</div><!-- End Row-->

</div>
<!-- End container-fluid-->

</div><!--End content-wrapper-->
</div><!--End wrapper-->
<!-- Modal -->
<div class="modal fade" id="fineModal">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title"><i class="fa fa-star"></i> Add Fine</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <?php echo form_open('index.php/insertfine'); ?>
        <!-- <div class="form-group row">
          <label for="input-6" class="col-sm-4 col-form-label">Expenses Type</label>
          <div class="col-sm-8">
            <select class="form-control" id="exp_type" name="exp_type" required>
              <option selected  disabled="disabled" >---Select Expenses---</option>
              <?php foreach ($expenceses_type as $expenceses_type){ ?>
                <option value="<?=$expenceses_type->exp_type ?>"><?=$expenceses_type->exp_type ?></option>
              <?php } ?>
              
            </select>
            <br>
            <a href="<?php echo base_url();?>index.php/expenceses_type">(+) Add Expenses Type</a>
          </div>
        </div>  -->

        <div class="form-group row">
          <label for="input-4" class="col-sm-4 col-form-label">Remark</label>
          <div class="col-sm-8">
            <textarea class="form-control" name="remark" id="remark" rows="2" required placeholder="Remark"></textarea>
          </div>
        </div>
        
        <div class="form-group row">
          <label for="input-2" class="col-sm-4 col-form-label">Amount</label>
          <div class="col-sm-8">
            <input type="text" class="form-control" pattern="[0-9]+" id="amount" name="amount" required placeholder="Please Enter Valid Amount" title="Number Only" required>
          </div>
        </div>
        <div class="form-group row">
          <label for="input-2" class="col-sm-4 col-form-label">Date</label>
          <div class="col-sm-8">
            <input type="date" class="form-control" id="date" name="date" required placeholder="" >
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
        <button type="submit" class="btn btn-primary"><i class="fa fa-check-square-o"></i> Fine</button>
      </div>
      <?php echo form_close(); ?>
    </div>
  </div>
</div>


<!-- Bootstrap core JavaScript-->
<script src="<?php echo base_url();?>assets/js/jquery.min.js"></script>
<script src="<?php echo base_url();?>assets/js/popper.min.js"></script>
<script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>

<!-- simplebar js -->
<script src="<?php echo base_url();?>assets/plugins/simplebar/js/simplebar.js"></script>
<!-- waves effect js -->
<script src="<?php echo base_url();?>assets/js/waves.js"></script>
<!-- sidebar-menu js -->
<script src="<?php echo base_url();?>assets/js/sidebar-menu.js"></script>
<!-- Custom scripts -->
<script src="<?php echo base_url();?>assets/js/app-script.js"></script>

<!--Data Tables js-->
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/dataTables.bootstrap4.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/dataTables.buttons.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/buttons.bootstrap4.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/jszip.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/pdfmake.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/vfs_fonts.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/buttons.html5.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/buttons.print.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/buttons.colVis.min.js"></script>

<script>
 $(document).ready(function() {
      //Default data table
      $('#default-datatable').DataTable();


      var table = $('#example').DataTable( {
        lengthChange: false,
        buttons: [ 'excel','print', ]
        //buttons: [ 'copy', 'excel', 'pdf', 'print', 'colvis' ]
      } );

      table.buttons().container()
      .appendTo( '#example_wrapper .col-md-6:eq(0)' );
      
    } );

  </script>
  


