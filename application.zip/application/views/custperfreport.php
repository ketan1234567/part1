
<!-- Breadcrumb-->
<div class="row pt-2 pb-2">
  <div class="col-sm-9">
    <h4 class="page-title">Customer Performance Report</h4>
  </div>
  <div class="col-sm-3">
   <div class="btn-group float-sm-right">
    <!-- <button type="button" class="btn btn-outline-primary waves-effect waves-light" data-toggle="modal" data-target="#largesizemodal"><i class="fa fa-user mr-1"></i> ADD Exp</button> -->
  </div>
</div>
</div>
<!-- End Breadcrumb-->
<div class="row">
  <div class="col-lg-12">
    <div class="card">
     <!--  <div class="card-header"><i class="fa fa-table"></i> Data Exporting</div> -->
     <div class="card-body">
      <div class="table-responsive">
        <table id="example" class="table table-bordered" >
          <!-- Simple.waribk2@gmail.com == Summer@00 -->
          <col width="25">
          <thead>
            <tr>
              <th>Loan<br>Detail</th>
              <th>Loan<br>Amount</th>
              <th>Amount<br>to collect</th>
              <th>First<br>Date</th>
              <th>Collected<br>Amount</th>
              <th>Daily<br>Target</th>
              <th>Days<br>left</th>
              <th>Target</th>
              <th>Achieved</th>
              <th>Defaulted</th>
              <th>Perfromance</th>
            </tr>
          </thead>
          <tbody>
            <?php $i=1; if(count($custperfreport)): ?>
            <?php foreach ($custperfreport as $upcoming_report_data): ?>
              <tr>
                <!-- <td style="font-size: 11px;"><?= $i ?></td> -->
                <td style="font-size: 11px;"><?= $upcoming_report_data->loan_id."-".$upcoming_report_data->customer_name ?></td>
                <td style="font-size: 11px;"><?= $upcoming_report_data->loan_amount   ?></td>
                <td style="font-size: 11px;"><?= $upcoming_report_data->loan_amount + $upcoming_report_data->interest?></td>
                <td style="font-size: 11px;"><?php $yrdata= strtotime($upcoming_report_data->date);
                echo date('d-M-Y', $yrdata); ?></td>
                <td style="font-size: 11px;"><?= $upcoming_report_data->collected_amount   ?></td>
              <!--   <td style="font-size: 11px;"><?= $upcoming_report_data->remaining_amount   ?></td> -->
                <td style="font-size: 11px;"><?= $upcoming_report_data->daily_target ?></td>
                <td style="font-size: 11px;"><?= $upcoming_report_data->days_left ?></td>


                <td style="font-size: 11px;"><?php 
                $now = time(); // or your date as well
                $your_date = strtotime($upcoming_report_data->date);
                $datediff = $now - $your_date;

                $target = round($datediff / (60 * 60 * 24)); echo $target; ?></td>
                <td style="font-size: 11px;"><?php $achive = $upcoming_report_data->collected_amount / $upcoming_report_data->daily_target; echo $achive; ?></td>
                <td style="font-size: 11px;"><?php $defaulted = $target - $achive; echo $defaulted;  ?></td>
                <td style="font-size: 11px;"><?php $performance = $defaulted/$target; $perfromance1 = round($performance, 2);  echo str_replace("0.","",$perfromance1);?>%</td>
                
                  <!-- <td style="font-size: 11px;">test</td> -->
                </tr>
                <?php $i++;endforeach; ?>
                <?php else: ?>
                  <tr>
                    <td colspan="15">
                      No record found.
                    </td>
                  </tr>

                <?php endif; ?> 
          </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div><!-- End Row-->

</div>
<!-- End container-fluid-->

</div><!--End content-wrapper-->
</div><!--End wrapper-->


<!-- Bootstrap core JavaScript-->
<script src="<?php echo base_url();?>assets/js/jquery.min.js"></script>
<script src="<?php echo base_url();?>assets/js/popper.min.js"></script>
<script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>

<!-- simplebar js -->
<script src="<?php echo base_url();?>assets/plugins/simplebar/js/simplebar.js"></script>
<!-- waves effect js -->
<script src="<?php echo base_url();?>assets/js/waves.js"></script>
<!-- sidebar-menu js -->
<script src="<?php echo base_url();?>assets/js/sidebar-menu.js"></script>
<!-- Custom scripts -->
<script src="<?php echo base_url();?>assets/js/app-script.js"></script>

<!--Data Tables js-->
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/dataTables.bootstrap4.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/dataTables.buttons.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/buttons.bootstrap4.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/jszip.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/pdfmake.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/vfs_fonts.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/buttons.html5.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/buttons.print.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/buttons.colVis.min.js"></script>

<script>
 $(document).ready(function() {
      //Default data table
      $('#default-datatable').DataTable();


      var table = $('#example').DataTable( {
        lengthChange: false,
        order : [ 10, 'desc' ],
        buttons: [ 'excel','print', ]
        //buttons: [ 'copy', 'excel', 'pdf', 'print', 'colvis' ]
      } );

      table.buttons().container()
      .appendTo( '#example_wrapper .col-md-6:eq(0)' );
      
    } );

  </script>
  


