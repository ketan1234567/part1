
<!-- Breadcrumb-->
<div class="row pt-2 pb-2">
  <div class="col-sm-9">
    <h4 class="page-title">SMS Portal</h4>
  </div>
  <div class="col-sm-3">
   <div class="btn-group float-sm-right">
    <!-- <button type="button" class="btn btn-outline-primary waves-effect waves-light" data-toggle="modal" data-target="#largesizemodal"><i class="fa fa-user mr-1"></i> New Complaint</button> -->
  </div>
</div>
</div>
<!-- End Breadcrumb-->
<div class="row">
  <div class="col-lg-12">
    <div class="card">
     <!--  <div class="card-header"><i class="fa fa-table"></i> Data Exporting</div> -->
     <div class="card-body">
      <div class="table-responsive">
       <button type="button" class="btn btn-outline-primary waves-effect waves-light" data-toggle="modal" data-target="#sendonesmsmodal"><i class="fa fa-user mr-1"></i>Send Single SMS</button>
       <button type="button" class="btn btn-outline-primary waves-effect waves-light" data-toggle="modal" data-target="#sendselectedsmsmodal"><i class="fa fa-user mr-1"></i>Send Selected SMS</button>
       <!-- <br><br> -->
       <button type="button" class="btn btn-outline-primary waves-effect waves-light" data-toggle="modal" data-target="#sendtoallsmsmodal"><i class="fa fa-users mr-1"></i>Send To All </button>
       <button type="button" class="btn btn-outline-primary waves-effect waves-light" data-toggle="modal" data-target="#sendonesmstoanyonemodal"><i class="fa fa-user mr-1"></i>Send Single SMS Anyone</button>
     </div>
   </div>
 </div>
</div>
</div><!-- End Row-->

</div>
<!-- End container-fluid-->

</div><!--End content-wrapper-->
</div><!--End wrapper-->
<!-- sendonesmsmodal Modal -->
<div class="modal fade" id="sendonesmsmodal">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title"><i class="fa fa-star"></i> Send One SMS</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <?php echo form_open('index.php/sendonesms'); ?>
        <div class="form-group row">
          <label for="input-2" class="col-sm-4 col-form-label">Mobile Number</label>
          <div class="col-sm-8">
            <select class="form-control single-select" name="contact">
              <?php foreach ($contact as $contact_data){ ?>
                <option value="<?= $contact_data->contact  ?>"><?= $contact_data->fname.'-'.$contact_data->lname  ?></option>
              <?php } ?>
            </select>
        </div>
      </div>
        <div class="form-group row">
          <label for="input-4" class="col-sm-4 col-form-label">Text Message</label>
          <div class="col-sm-8">
            <textarea class="form-control" maxlength="150" name="text_msg" id="text_msg" rows="4" required placeholder="150 character Only"></textarea>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
        <button type="submit" class="btn btn-primary"><i class="fa fa-check-square-o"></i> Send</button>
      </div>
      <?php echo form_close(); ?>
    </div>
  </div>
</div>

<!-- sendonesmsmodal anyone Modal -->
<div class="modal fade" id="sendonesmstoanyonemodal">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title"><i class="fa fa-star"></i> Send Anyone SMS</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <?php echo form_open('index.php/sendonesmstoanyone'); ?>
        <div class="form-group row">
          <label for="input-2" class="col-sm-4 col-form-label">Mobile Number</label>
          <div class="col-sm-8">

            <input type="text" name="contact" class="form-control" >
            
          </div>
        </div>
        <div class="form-group row">
          <label for="input-4" class="col-sm-4 col-form-label">Text Message</label>
          <div class="col-sm-8">
            <textarea class="form-control" maxlength="150" name="text_msg" id="text_msg" rows="4" required placeholder="150 character Only"></textarea>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
        <button type="submit" class="btn btn-primary"><i class="fa fa-check-square-o"></i> Send</button>
      </div>
      <?php echo form_close(); ?>
    </div>
  </div>
</div>
<!-- sendselectedsmsmodal Modal -->
<div class="modal fade" id="sendselectedsmsmodal">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title"><i class="fa fa-star"></i> Send Selected SMS</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <?php echo form_open('index.php/sendmultiplesms'); ?>
        <div class="form-group row">
          <label for="input-2" class="col-sm-4 col-form-label">Mobile Number</label>
          <div class="col-sm-8">
            <select class="form-control multiple-select" multiple="multiple" name="contact_multiple[]">
              <?php foreach ($contact as $contact_data){ ?>
                <option value="<?= $contact_data->contact  ?>"><?= $contact_data->fname.'-'.$contact_data->lname  ?></option>
              <?php } ?>
            </select>
          </div>
        </div>
        <div class="form-group row">
          <label for="input-4" class="col-sm-4 col-form-label">Text Message</label>
          <div class="col-sm-8">
            <textarea class="form-control" maxlength="150" name="text_msg" id="text_msg" rows="4" required placeholder="150 character Only"></textarea>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
        <button type="submit" class="btn btn-primary"><i class="fa fa-check-square-o"></i> Send</button>
      </div>
      <?php echo form_close(); ?>
    </div>
  </div>
</div>
<!-- sendtoallsmsmodal Modal -->
<div class="modal fade" id="sendtoallsmsmodal">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title"><i class="fa fa-star"></i> Send To ALL</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <?php echo form_open('index.php/sendtoallsms'); ?>
        <div class="form-group row">
          <label for="input-4" class="col-sm-4 col-form-label">Text Message</label>
          <div class="col-sm-8">
            <textarea class="form-control" maxlength="150" name="text_msg" id="text_msg" rows="4" required placeholder="150 character Only"></textarea>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
        <button type="submit" class="btn btn-primary"><i class="fa fa-check-square-o"></i> Send To All</button>
      </div>
      <?php echo form_close(); ?>
    </div>
  </div>
</div>


<!-- Bootstrap core JavaScript-->
<script src="<?php echo base_url();?>assets/js/jquery.min.js"></script>
<script src="<?php echo base_url();?>assets/js/popper.min.js"></script>
<script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>

<!-- simplebar js -->
<script src="<?php echo base_url();?>assets/plugins/simplebar/js/simplebar.js"></script>
<!-- waves effect js -->
<script src="<?php echo base_url();?>assets/js/waves.js"></script>
<!-- sidebar-menu js -->
<script src="<?php echo base_url();?>assets/js/sidebar-menu.js"></script>
<!-- Custom scripts -->
<script src="<?php echo base_url();?>assets/js/app-script.js"></script>
<!--Select Plugins Js-->
<script src="<?php echo base_url();?>assets/plugins/select2/js/select2.min.js"></script>

<!--Data Tables js-->
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/dataTables.bootstrap4.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/dataTables.buttons.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/buttons.bootstrap4.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/jszip.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/pdfmake.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/vfs_fonts.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/buttons.html5.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/buttons.print.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/buttons.colVis.min.js"></script>


<script>
 $(document).ready(function() {
      //Default data table
      $('#default-datatable').DataTable();


      var table = $('#example').DataTable( {
        lengthChange: false,
        buttons: [ 'excel','print', ]
        //buttons: [ 'copy', 'excel', 'pdf', 'print', 'colvis' ]
      } );

      table.buttons().container()
      .appendTo( '#example_wrapper .col-md-6:eq(0)' );
      
    } );

  </script>
  <!--Multi Select Js-->
    <script src="<?php echo base_url();?>assets/plugins/jquery-multi-select/jquery.multi-select.js"></script>
    <script src="<?php echo base_url();?>assets/plugins/jquery-multi-select/jquery.quicksearch.js"></script>
    
    
    <script>
        $(document).ready(function() {
            $('.single-select').select2();
      
            $('.multiple-select').select2();

        //multiselect start

            $('#my_multi_select1').multiSelect();
            $('#my_multi_select2').multiSelect({
                selectableOptgroup: true
            });

            $('#my_multi_select3').multiSelect({
                selectableHeader: "<input type='text' class='form-control search-input' autocomplete='off' placeholder='search...'>",
                selectionHeader: "<input type='text' class='form-control search-input' autocomplete='off' placeholder='search...'>",
                afterInit: function (ms) {
                    var that = this,
                        $selectableSearch = that.$selectableUl.prev(),
                        $selectionSearch = that.$selectionUl.prev(),
                        selectableSearchString = '#' + that.$container.attr('id') + ' .ms-elem-selectable:not(.ms-selected)',
                        selectionSearchString = '#' + that.$container.attr('id') + ' .ms-elem-selection.ms-selected';

                    that.qs1 = $selectableSearch.quicksearch(selectableSearchString)
                        .on('keydown', function (e) {
                            if (e.which === 40) {
                                that.$selectableUl.focus();
                                return false;
                            }
                        });

                    that.qs2 = $selectionSearch.quicksearch(selectionSearchString)
                        .on('keydown', function (e) {
                            if (e.which == 40) {
                                that.$selectionUl.focus();
                                return false;
                            }
                        });
                },
                afterSelect: function () {
                    this.qs1.cache();
                    this.qs2.cache();
                },
                afterDeselect: function () {
                    this.qs1.cache();
                    this.qs2.cache();
                }
            });

         $('.custom-header').multiSelect({
              selectableHeader: "<div class='custom-header'>Selectable items</div>",
              selectionHeader: "<div class='custom-header'>Selection items</div>",
              selectableFooter: "<div class='custom-header'>Selectable footer</div>",
              selectionFooter: "<div class='custom-header'>Selection footer</div>"
            });



          });

    </script>
  