
<div class="row">
  <div class="col-lg-12">
    <div class="card">
      <div class="card-header"><i class="fa fa-table"></i> All Loans </div>
      <div class="card-body">
        <div class="table-responsive">
          <font size="2" >
            <table id="example" class="table table-bordered">
              <thead>
                <!--<tr>-->
                  <!--  <th>#</th> -->
                  <!--  <th>Loan Details</th>-->
                  <!--  <th>Loan Amount</th>-->
                  <!--  <th>Loan Breakup</th>-->
                  <!--  <th>Loan Status</th>-->
                  <!--  <th>Loan Type</th>-->
                  <!--  <th>Approval</th>-->

                  <!--</tr>-->
                  <tr>
                    <th width="10%">#</th> 
                    <th width="25%">Details</th>
                    <th width="10%">Amount</th>
                    <th width="10%">Breakup</th>
                    <th width="10%">Status</th>
                    <th width="10%">Type</th>
                    <th width="25%">Approval</th>

                  </tr>
                </thead>
                <tbody>

                 <?php $i=1; if(count($allloan)){ ?>
                   <?php foreach ($allloan as $result) { ?>
                    <tr>
                      <td><?= $i ?></td> 
                      <td> <a href="" title="Loan Details" data-index="<?=$result->loan_id;?>" name="chart" data-toggle="modal" data-target="#chart">(+)</a>
                        <?= $result->loan_id ?> -
                        <?php for ($j=0; $j < count($allagents); $j++) { 
                     //echo "string";
                     //print_r($allagents[$j]->id);
                         if ($result->id==$allagents[$j]->id) {
                          echo $allagents[$j]->fname; echo " "; echo $allagents[$j]->lname ;
                        }
                      } ?> 
                    </td>
                    <td><?= $result->loanamt ?> </td>
                    <td>Capital :- <?= $result->capital_amt ?> <br> Re-invest :- <?= $result->reinvest_amt ?></td> <!-- New 25-09-2019 -->
                    <td>
                      <?php if ($result->is_approve==1) { ?>
                        <span class="badge badge-success m-1">Yes</span>
                      <?php }elseif($result->is_approve==0){ ?>
                       <span class="badge badge-danger m-1">No</span>
                     <?php } ?>
                   </td>
                   <td><?php if ($result->loan_Type==1) { ?>
                    <span class="badge badge-warning m-1" >Capital</span>
                  <?php }elseif($result->loan_Type==2){ ?>
                   <span class="badge badge-warning m-1" >Re-invest</span>
                   <?php }elseif($result->loan_Type==3){ ?> <!-- New 25-09-2019 -->
                   <span class="badge badge-warning m-1" >Cap/Re-inv</span>
                 <?php }else{ ?>
                  <span >Not assign</span>
                <?php } ?>
              </td>
              <?php 
              $encode= $result->loan_id ;
              $ecode1 = base64_encode($encode);
              $ecode2= trim($ecode1,'=');
              ?> 
              <td>
                   <!--  <?php if ($result->is_approve==0) { ?>
                    <a href="" class="btn btn-outline-warning btn-sm waves-effect waves-light m-1" title="change status" data-index="<?=$result->loan_id;?>" name="changeapprove">Active/Inactive</a>
                    <?php }elseif($result->is_approve==1){ ?>
                    <a href="" class="btn btn-outline-warning btn-sm waves-effect waves-light m-1" title="change status" data-index="<?=$result->loan_id;?>" name="changeapprove1">Active/Inactive</a>
                    <?php } ?> -->
                    <a href="" class="btn btn-outline-info btn-sm waves-effect waves-light m-1" title="Assign" data-index="<?=$result->loan_id;?>" name="assign" data-toggle="modal" data-target="#assign" >A</a>
                    <?php if ($result->is_approve==1) { ?>
                      <a href="<?php echo base_url();?>index.php/showpassbook/<?= $ecode2 ?>" class="btn btn-outline-success btn-sm waves-effect waves-light m-1" title="Passbook">P</a>
                    <?php }else{ ?>
                      <span class="badge badge-danger m-1">Not Generate</span>

                    <?php } ?>
                    <a href="" class="btn btn-outline-warning btn-sm waves-effect waves-light m-1" title="Edit" data-index="<?=$result->loan_id;?>" name="loan_breakup" data-toggle="modal" data-target="#loan_breakup" >E</a>
                  </td>
                  
                </tr>
                <?php $i++;} ?>
              <?php } else { ?>
                <tr>
                  <td colspan="4">
                    No record found.
                  </td>
                </tr>

              <?php } ?> 
            </tbody>
          </table>
        </font>
      </div>
    </div>
  </div>
</div>
</div><!-- End Row-->

</div>
<!-- End container-fluid-->

</div><!--End content-wrapper-->
<!--Start Back To Top Button-->
<a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
<!--End Back To Top Button-->


</div>

<!-- Assign Modal -->
<div class="modal fade" id="assign">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title"><i class="fa fa-star"></i> Assign </h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <?php echo form_open('index.php/assignloan'); ?>

        <div class="form-group row">
          <input type="hidden" name="loan_id" id="loan_id" class="form-control">
          <label for="input-4" class="col-sm-4 col-form-label">Active/Inactive</label>
          <div class="col-sm-8">
            <select class="form-control" id="is_active" name="is_active">
              <option disabled>Select Status</option>
              <option value="1">Active</option>
              <option value="0">De-active</option>
            </select>
          </div>
        </div>

        <div class="form-group row">
          <label for="input-4" class="col-sm-4 col-form-label">Loan Type</label>
          <div class="col-sm-8">
            <select class="form-control" id="loan_Type" name="loan_Type" onchange="changetextbox();">
              <option >-----Select Loan Type-----</option>
              <option value="1">Capital</option>
              <option value="2">Re-Invest</option>
              <option value="3">Capital/Re-Invest</option>
            </select>
          </div>
        </div>
        <div class="form-group row" id="amt">
          <label for="input-4" class="col-sm-4 col-form-label">Amount</label>
          <div class="col-sm-8">
            <input type="text" class="form-control" name="capital_amt" placeholder="Capital" value="0" id="capital_amt" style="display:none" title="Capital">
            <input type="text" class="form-control" name="reinvest_amt" placeholder="Re-invest" value="0" id="reinvest_amt" style="display:none" title="Re-invest">
          </div>
        </div>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
        <button type="submit" class="btn btn-primary"><i class="fa fa-check-square-o"></i> Update</button>
      </div>
      <?php echo form_close(); ?>
    </div>
  </div>
</div>

<!-- Chartmodel -->
<div class="modal fade" id="chart">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title"><i class="fa fa-star"></i> Collected Amount </h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <!-- <input type="text" id="chart1"> -->


       <div class="row ">
        <div class="col-lg-12">
          <!-- <div id="easyPieChart" class="chart easy-pie-chart-1" data-percent="">
            <span class="percent"></span>
          </div>
          <div id="testchart">
         </div>
         <div  class="chart easy-pie-chart-2" data-percent="35">
          <span class="percent"></span>
        </div> -->
        <h6 class="text-info">Total Amount : -</h6>
        <label id="total_amount" ></label>
        <h6 class="text-warning">Collected Amount : -</h6>
        <label id="collected_amount" ></label>
        <!-- <label>Collection Percentage : - </label>
        <label id="collection_percentage" ></label>% -->
        <!-- <p>Collection Percentage : -</p> -->
        <h6 class="text-primary">Collection Percentage : -</h6>
        <label id="collection_percentage" ></label>%
        <div class="progress">
          <div id="pbar" class="progress-bar" style=""></div>
        </div>
      </div>

    </div><!--End Row-->

  </div>
  <div class="modal-footer">

  </div>

</div>
</div>
</div>

<!-- loan_breakup Modal -->
<div class="modal fade" id="loan_breakup">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title"><i class="fa fa-star"></i> Loan Breakup </h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <?php echo form_open('index.php/loan_breakup'); ?>

        <input type="hidden" name="loan_id1" id="loan_id1">
        <div class="form-group row">
          <label for="input-4" class="col-sm-4 col-form-label">Loan Type</label>
          <div class="col-sm-8">
            <select class="form-control" id="loan_Type" name="loan_Type">
              <option>-----Select Loan Type-----</option>
              <option value="1">Capital</option>
              <option value="2">Re-Invest</option>
              <option value="3">Capital/Re-Invest</option>
            </select>
          </div>
        </div>
        <div class="form-group row" id="amt">
          <label for="input-4" class="col-sm-4 col-form-label">Amount</label>
          <div class="col-sm-8">
            <input type="number" class="form-control" name="capital_amt" placeholder="Capital" value="0" id="capital_amt" title="Capital">
            <input type="number" class="form-control" name="reinvest_amt" placeholder="Re-invest" value="0" id="reinvest_amt" title="Re-invest">
          </div>
        </div>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
        <button type="submit" class="btn btn-primary"><i class="fa fa-check-square-o"></i> Update</button>
      </div>
      <?php echo form_close(); ?>
    </div>
  </div>
</div>


<!-- Bootstrap core JavaScript-->
<script src="<?php echo base_url();?>assets/js/jquery.min.js"></script>
<script src="<?php echo base_url();?>assets/js/popper.min.js"></script>
<script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>

<!-- simplebar js -->
<script src="<?php echo base_url();?>assets/plugins/simplebar/js/simplebar.js"></script>
<!-- waves effect js -->
<script src="<?php echo base_url();?>assets/js/waves.js"></script>
<!-- sidebar-menu js -->
<script src="<?php echo base_url();?>assets/js/sidebar-menu.js"></script>
<!-- Custom scripts -->
<script src="<?php echo base_url();?>assets/js/app-script.js"></script>

<!--Data Tables js-->
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/dataTables.bootstrap4.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/dataTables.buttons.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/buttons.bootstrap4.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/jszip.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/pdfmake.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/vfs_fonts.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/buttons.html5.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/buttons.print.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/bootstrap-datatable/js/buttons.colVis.min.js"></script>

<!-- Easy Pie Chart JS -->
<script src="<?php echo base_url();?>assets/plugins/jquery.easy-pie-chart/jquery.easypiechart.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/jquery.easy-pie-chart/easy-pie-chart.init.js"></script>
<!-- <script src="http://rendro.github.io/easy-pie-chart/javascripts/jquery.easy-pie-chart.js" cross></script>
-->

<script>
 $(document).ready(function() {
      //Default data table
      $('#default-datatable').DataTable();


      var table = $('#example').DataTable( {
        lengthChange: false,
        buttons: [ 'excel','colvis' ]
      } );

      table.buttons().container()
      .appendTo( '#example_wrapper .col-md-6:eq(0)' );
      
    } );

  </script>
  <script type="text/javascript">

    $("a[name=changeapprove]").on("click", function () { 
      var id = $(this).data("index"); 
              //alert(id);
              $.ajax({
                url: '<?php echo base_url(); ?>index.php/changeapprove',
                type: 'POST',
                data:  { 'id' : id, 'val': 1 },
                success: function(response,status,xhr) {
                  //console.info(response);
                  //window.location.href="vendorlist";
                  //alert(response);
                  location.relode();

                }
              }); 
            });
    $("a[name=changeapprove1]").on("click", function () { 
      var id = $(this).data("index"); 
              //alert(id);
              $.ajax({
                url: '<?php echo base_url(); ?>index.php/changeapprove',
                type: 'POST',
                data:  { 'id' : id, 'val': 0 },
                success: function(response,status,xhr) {
                  //console.info(response);
                  //window.location.href="vendorlist";
                  //alert(response);
                  location.relode();

                }
              }); 
            });
    $("a[name=chart]").on("click", function () {
      var $chart = $("#easyPieChart");
      $chart.data('easyPieChart', null); 
      var loanid = $(this).data("index"); 
              //alert(loanid);
              $.ajax({
                url: '<?php echo base_url(); ?>index.php/chartdata/'+loanid,
                type: 'POST',
                data:  { 'loanid' : loanid },
                success: function(response,status,xhr) {
                  console.info(response);
                 // alert(response);
                 var a =jQuery.parseJSON(response);
                 //var lamt = a.loanamt;
                 var lamt = a.lenderamt
                 var camt = a.coll_amt;
                  //alert(camt);
                  var per1 = camt * 100 / lamt;
                   var per = per1.toFixed(2);
                  //alert(per);
                  $("#chart1").val(per); 
                  //$("#chart1").text(per);
                  $("#total_amount").text(lamt);
                  $("#collected_amount").text(camt);
                  $("#collection_percentage").text(per);
                  $("#tt").text(lamt);
                  $("#pbar1").text(per);
                   $("#pbar").css("width",per+'%');

                  // $('#easyPieChart').attr('data-percent',per);


                  /*var str='';
                  str +='<div class="chart easy-pie-chart-1" data-percent="25">';
                  str +='<span class="percent"></span>';
                  str +='<canvas height="110" width="110"></canvas>';
                  str +='</div>';

                  $("#testchart").html(str);
*/


                  //$('div.data-percent').text(per);
                  //$("ch_id").data("percent",per);
                 // $("#ch_id").attr("data-percent", per.toString());
                 // $("#ch_id").attr('data-percent',per.toString());
                  //$('#ch_id').attr('data-percent', 50);
                  //window.location.href="vendorlist";
                  //$('.chart easy-pie-chart-2').data('percent',50);//.update(50);
                  //$('#easyPieChart').data('percent',50);//.update(50);
                  $chart.data('percent', per); 
                  $chart.easyPieChart({
                   percent:per,
                   barColor: '#f00'
                 });
                  console.log(per);
                  console.log($('#easyPieChart').data());
                  

                  //location.relode();

                }
              }); 
            });

    
          </script>

        </body>

        </html>
        <script type="text/javascript">
          $("a[name=assign]").on("click", function () { 
            var id = $(this).data("index"); 
            $("#loan_id").val(id);

          });
        </script>

        <script type="text/javascript">
          $("a[name=loan_breakup]").on("click", function () { 
            var id = $(this).data("index"); 
            $("#loan_id1").val(id);

          });
        </script>

        <script type="text/javascript">
          function changetextbox()
          {
            if (document.getElementById("loan_Type").value == 1 ) {
              document.getElementById("capital_amt").style.display='block';
              document.getElementById("reinvest_amt").style.display='none';
            }  if (document.getElementById("loan_Type").value == 2 ) {
              document.getElementById("reinvest_amt").style.display='block';
              document.getElementById("capital_amt").style.display='none';
            } if (document.getElementById("loan_Type").value == 3 ) {
              document.getElementById("reinvest_amt").style.display='block';
              document.getElementById("capital_amt").style.display='block';
            }
          }
        </script>
