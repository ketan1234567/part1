<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	https://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/
$route['default_controller'] = 'Main';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

$route['signup'] = "Main/signup";
$route['registration'] = "Main/registration";
$route['login'] = "Main/login";
$route['logout'] = "Main/logout";
$route['dashboard'] = "Main/dashboard";
$route['loan'] = "Main/loan";
$route['passbook'] = "Main/passbook";
$route['storeloan'] = "Main/storeloan";
$route['editloanamt'] = "Main/editloanamt";
$route['updateloanamt'] = "Main/updateloanamt";
$route['customers'] = "Main/customers";
$route['closedloan'] = "Main/closedloan";
$route['collectloanamt'] = "Main/collectloanamt";
$route['showpassbook/(:any)'] = "Main/showpassbook/$1";
$route['daily'] = "Main/daily";
$route['all'] = "Main/all";
$route['agents'] = "Main/agents";
$route['changestatus'] = "Main/changestatus";
$route['loanlist'] = "Main/loanlist";
$route['changeapprove'] = "Main/changeapprove";
$route['collector'] = "Main/collector";
$route['ind_collection/(:any)'] = "Main/ind_collection/$1";
$route['agentdetails'] = "Main/agentdetails";
$route['loandetails'] = "Main/loandetails";
$route['custdetails/(:any)'] = "Main/custdetails/$1";
//new
$route['resetpass'] = "Main/resetpass";




$route['extra'] = "Main/extra";
$route['uploadreport'] = "Main/uploadreport";



