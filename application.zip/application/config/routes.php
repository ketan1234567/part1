<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	https://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/
$route['default_controller'] = 'Main';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

$route['signup'] = "Main/signup";
$route['registration'] = "Main/registration";
$route['login'] = "Main/login";
$route['logout'] = "Main/logout";
$route['dashboard'] = "Main/dashboard";
$route['loan'] = "Main/loan";
$route['passbook'] = "Main/passbook";
$route['storeloan'] = "Main/storeloan";
$route['storeloan1'] = "Main/storeloan1";
$route['editloanamt'] = "Main/editloanamt";
$route['updateloanamt'] = "Main/updateloanamt";
$route['customers'] = "Main/customers";
$route['closedloan'] = "Main/closedloan";
$route['collectloanamt'] = "Main/collectloanamt";
$route['showpassbook/(:any)'] = "Main/showpassbook/$1";
$route['daily'] = "Main/daily";
$route['all'] = "Main/all";
$route['agents'] = "Main/agents";
$route['changestatus'] = "Main/changestatus";
$route['loanlist'] = "Main/loanlist";
$route['changeapprove'] = "Main/changeapprove";
$route['collector'] = "Main/collector";
$route['ind_collection/(:any)'] = "Main/ind_collection/$1";
$route['agentdetails'] = "Main/agentdetails";
$route['loandetails'] = "Main/loandetails";
$route['custdetails/(:any)'] = "Main/custdetails/$1";
//new
$route['resetpass'] = "Main/resetpass";
$route['assigncoll'] = "Main/assigncoll";
$route['updateprof'] = "Main/updateprof";
$route['addphoto'] = "Main/addphoto";
$route['delete/(:any)'] = "Main/delete/$1";
$route['assignloan'] = "Main/assignloan";

$route['expenceses'] = "Main/expenceses";
$route['insertexp'] = "Main/insertexp";
$route['del_exp/(:any)'] = "Main/del_exp/$1";

$route['showloanid'] = "Main/showloanid";
$route['showloanamt'] = "Main/showloanamt";

$route['report'] = "Main/report";
$route['daily_collection/(:any)'] = "Main/daily_collection/$1";

////20-09-2019
$route['deletepay/(:any)'] = "Main/deletepay/$1";
$route['show_loanid'] = "Main/show_loanid";
$route['edit_pay_amount'] = "Main/edit_pay_amount";

////25-09-2019
$route['loan_breakup'] = "Main/loan_breakup";

////30-09-2019
$route['upreport'] = "Main/upreport";

////07-11-2019
$route['datewisereport'] = "Main/datewisereport";
$route['custperfreport'] = "Main/custperfreport";
$route['enddateprojreport'] = "Main/enddateprojreport";

///27-11-2019
$route['insertcollector'] = "Main/insertcollector";
$route['calculator'] = "Main/calculator";
$route['verifer'] = "Main/verifer";
$route['verifersearch'] = "Main/verifersearch";

//03-12-2019
$route['addcapital'] = "Main/addcapital";
$route['insertaddcapital'] = "Main/insertaddcapital";
$route['deladdcapital/(:any)'] = "Main/deladdcapital/$1";

//17-12-2019
$route['expenceses_type'] = "Main/expenceses_type";
$route['insertexptype'] = "Main/insertexptype";
$route['show_exp_type_id'] = "Main/show_exp_type_id";
$route['editexptype'] = "Main/editexptype";
$route['del_exp_type/(:any)'] = "Main/del_exp_type/$1";

//18-12-2019
$route['smsportal'] = "Main/smsportal";
$route['sendonesms'] = "Main/sendonesms";
$route['sendmultiplesms'] = "Main/sendmultiplesms";
$route['sendtoallsms'] = "Main/sendtoallsms";
$route['sendonesmstoanyone'] = "Main/sendonesmstoanyone";

//19-12-2019
$route['deleteagent/(:any)'] = "Main/deleteagent/$1";

//03-01-2020
$route['chartdata/(:any)'] = "Main/chartdata/$1";

//16-04-2021
$route['addfine'] = "Main/addfine";
$route['insertfine'] = "Main/insertfine";
$route['del_fines/(:any)'] = "Main/del_fines/$1";

////My Work
$route['database'] = "Main/database";
$route['extra'] = "Main/extra";
$route['dbbackup'] = "Main/dbbackup";



